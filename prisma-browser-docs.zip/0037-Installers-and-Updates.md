---
title: "Installers and Updates"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/prisma-access-browser-update-mechanics"
depth: 2
breadcrumbs: "Home > Prisma Browser > Installers and Updates"
updated: "Tue Feb 10 06:48:28 PST 2026"
---

# Installers and Updates
Learn about the Prisma Browser update mechanics.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

### Self Service Installation

You can direct users to the self-service installer. They will need to sign in using their SSO credentials. The self service installer is found at [http://getpabrowser.com](https://get.pabrowser.com/)

This option is available for both Windows and macOS devices.

### Installers

The Prisma Browser supports online and offline installers for Windows, macOS, and Linux devices. Select the operating system to search for the most appropriate installer:cx

-   [Windows](/content/techdocs/en_US/prisma-access-browser/deployment/prisma-access-browser-update-mechanics/windows-deployment.html#windows-deployment)
-   [macOS](/content/techdocs/en_US/prisma-access-browser/deployment/prisma-access-browser-update-mechanics/macos-deployment.html#macos-deployment)
-   [IGEL](/content/techdocs/en_US/prisma-access-browser/deployment/prisma-access-browser-update-mechanics/igel-deployment.html#igel-deployment)
-   [Linux](/content/techdocs/en_US/prisma-access-browser/deployment/prisma-access-browser-update-mechanics/linux-deployment.html#linux-deployment)

## Windows Deployment

These are the Windows deployment methods

The following deployment methods are available for Windows devices:

**Online installer** is a stub lightweight stub installer that automatically retrieves the latest version of the browser from either the Default channel or Long-Term Support (LTS) channel, depending on the type of installer downloaded.

**Offline installer** consists of a standalone installation file that enables browser installation on systems without an internet connection.

| **Architecture** | **Online Installers (MSI)** | **Offline Installers (MSI)** |
| --- | --- | --- |
| **x64** | [Latest](https://installer.talon-sec.com/8c502beb44024f8582ed89b2a25501a6/PAB?os=windowsMsi) | [Latest LTS](https://installer.talon-sec.com/8c502beb44024f8582ed89b2a25501a6/PAB?os=windowsLtsMsi) | [Latest](https://releases.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=win&architecture=x64&channel=packaged&redirect=true) | [Version Feed](https://releases.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=win&architecture=x64&channel=packaged) |
| **ARM64** | [Latest](https://installer.talon-sec.com/8c502beb44024f8582ed89b2a25501a6/PAB?os=windowsArmMsi) | [Latest LTS](https://installer.talon-sec.com/8c502beb44024f8582ed89b2a25501a6/PAB?os=windowsArmLtsMsi) | [Latest](https://releases.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=win&architecture=arm64&channel=packaged&redirect=true) | [Version Feed](https://releases.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=win&architecture=arm64&channel=packaged) |

### Browser Updates

The browser follows a weekly update schedule aligned with Chrome’s release cycle, which includes weekly security patches and a major version update with new features approximately every month.

Administrators can select between two release channels through the **deployment** policy:

-   **Default Channel**: Receives weekly updates that include both new features and security patches.
-   **Long-Term Support (LTS) Channel**: Receives weekly security patches and new Prisma Access Browser and Chromium features only during the monthly major version updates.

The **Deployment** policy in the management console allows customization of the deployment delay for new features and configuration of the update enforcement schedule.

Updates downloaded during the update process are applied at the next browser start or restart. Active browser sessions will display a notification prompting users to restart their browsers to apply the update.

**WINDOWS - Windows Installations with Auto-Update**

Windows installations configured with auto-update include both the browser and an updater service agent. This agent operates independently of the browser and is triggered by a system-level scheduled task.

-   **Background Updates**: When the machine is powered on, the scheduled task periodically checks for new browser versions, even if no user is logged in.
-   **Manual Update Check**: Users can manually trigger an update check by navigating to the **About** page at prisma://settings/help. If an update is available, the update service will notify the user and provide the option to install it.

# macOS Deployment

These are the macOS deployment methods

Prisma Browser supports two installation variations for macOS environments. Both variations can be installed offline, and include a self-updating component.

| File Type | Primary Use Case |
| --- | --- |
| **PKG** | Automated deployments via MDM solutions or local admins. Preferred for enterprise environments. |
| **DMG** | Manual installations by unprivileged end-users, BYOD. |

| Architecture | Latest Installation | Version Feed |
| --- | --- | --- |
| **Universal** | [PKG](https://release-manager.us.gs.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=universal&channel=packaged&redirect=true) | [DMG](https://release-manager.us.gs.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=universal&channel=standalone&redirect=true) | [PKG](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=universal&channel=packaged) | [DMG](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=universal&channel=standalone) |
| **Apple Silicon** (ARM64) | [PKG](https://release-manager.us.gs.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=arm64&channel=packaged&redirect=true) | [DMG](https://release-manager.us.gs.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=arm64&channel=standalone&redirect=true) | [PKG](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=arm64&channel=packaged) | [DMG](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=arm64&channel=standalone) |
| **Intel** (x64) | [PKG](https://release-manager.us.gs.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=x64&channel=packaged&redirect=true) | [DMG](https://release-manager.us.gs.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=x64&channel=standalone&redirect=true) | [PKG](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=x64&channel=packaged) | [DMG](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=x64&channel=standalone) |

### Browser Updates

The browser follows a weekly update schedule aligned with Chrome’s release cycle, which includes weekly security patches and a major version update with new features approximately every month.

Administrators can select between two release channels through the **deployment** policy:

-   **Stable Channel** (default): Receives weekly updates that include both new features and security patches.
-   **Long-Term Support (LTS) Channel**: Receives weekly security patches and new Prisma Browser and Chromium features only during the monthly major version updates.

The **Deployment** policy in the management console allows customization of the deployment delay for new features and configuration of the update enforcement schedule.

Updates downloaded during the update process are applied at the next browser start or restart. Active browser sessions will display a notification prompting users to restart their browsers to apply the update.

**macOS**

For macOS devices, browser updates are currently managed within the browser context. The update process initiates only while the browser is running and operates using the active user's permissions.

This process will be updated with the upcoming introduction of the Prisma Browser Updater for macOS.

## IGEL Deployment

This is the IGEL deployment information

Prisma Browser installation and update over IGEL OS is performed via the **IGEL App Portal**. For more information, refer to the [IGEL App Portal](https://app.igel.com/).

## Linux Deployment

These are the Linux deployment methods

### Distribution Agnostic Installation

Installation of the latest version on either Ubuntu/Fedora (MD5):

eaeb2552cdffe5842debb6c8b7f5cffd):

```
curl -fsS https://updates.talon-sec.com/linux/prisma-access-browser/install.sh | sudo bash
```

### Ubuntu

Dynamic list of Prisma Browser Linux (.deb) stable versions can be found [here](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=linux_deb&architecture=x64&channel=stable) . New stable versions are released on a weekly basis and will be reflected in the list

.

**Manual/One-time Installation**

Install the package using the downloaded .deb file.

```
sudo apt install prisma-access-browser-stable\_<version\_number>-1\_amd64.deb
```

**Package Repository (via MDM/Local)**

Create a new repository file under /etc/apt/sources.list.d

```
echo "deb \[arch=amd64\] https://updates.talon-sec.com/linux/prisma-access-browser/deb/ stable main" | sudo tee /etc/apt/sources.list.d/prisma-access-browser.list
                
```

**Import the GPG key (before using the repository)**

```
wget -q -O - https://updates.talon-sec.com/linux/prisma-access-browser/linux\_signing\_key.pub | sudo tee /etc/apt/trusted.gpg.d/pab.asc >/dev/null
```

Update the package list

```
sudo apt update
```

**Install Prisma Browser**

```
sudo apt install prisma-access-browser-stable
```

**Remove Prisma Browser**

```
sudo apt remove prisma-access-browser-stable
```

### Fedora

Dynamic list of Prisma Browser Linux (.rpm) stable versions can be found [here](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=linux_rpm&architecture=x64&channel=stable) . New stable versions are released weekly and are reflected in the list.

**Manual/One time Installation**

Install the package using the download rpm file.

```
sudo dnf install prisma-access-browser-stable <version\_number>-10x86\_64.rpm
```

If you are using sudo yum -

```
sudo yum install prisma-access-browser-stable <version\_number>-10x86\_64.rpm
```

**Package Repository**

-   **Create a new repository file under _/etc/yum.repos.d/package-name.repo_ with the following content:**
    
    ```
    \[prisma-access-browser\]
                            name=prisma-access-browser
                            baseurl=https://updates.talon-sec.com/linux/prisma-access-browser/rpm/stable/x86\_64
                            enabled=1
                            gpgcheck=1
                            gpgkey=https://updates.talon-sec.com/linux/prisma-access-browser/linux\_signing\_key.pub
                        
    ```
    
-   **Optionally - you can manually import the key (as is mentioned in the repo file**.
    
    ```
    sudo rpm --import https://updates.talon-sec.com/linux/prisma-access-browser/linux\_signing\_key.pub
                        
    ```
    
-   **Clear cache**
    
    ```
    sudo dnf clean all
    ```
    
-   **Install the Package**
    
    ```
    sudo dnf install prisma-access-browser-stable
    ```
    
-   **Remove the Package**
    
    ```
    sudo dnf remove prisma-access-browser-stable
    ```
    

### Engine Updates

All versions of the browser will update the engine component automatically. These are rolled out gradually to the entire user-base and are not configurable by policy. This is required for browser functionality and to get the latest updates, fixes, and policies.

* * *

[

Previous

Prisma Browser Prerequisites



](/content/techdocs/en_US/prisma-access-browser/getting-started/prisma-access-browser-prerequisites.html)

[

Next

Deploy the Prisma Browser via MDM

](/content/techdocs/en_US/prisma-access-browser/deployment/deploy-prisma-access-browser.html)

* * *