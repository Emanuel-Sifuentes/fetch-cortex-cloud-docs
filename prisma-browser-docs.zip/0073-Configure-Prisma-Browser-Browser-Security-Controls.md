---
title: "Configure Prisma Browser Browser Security Controls"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Security Controls"
updated: "Mar 12, 2026"
---

# Configure Prisma Browser Browser Security Controls
Configure browser security controls for Prisma Access Secure Enterprise Browser (Prisma Browser).

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

You can configure the controls in the following ways:

-   When you're creating a new browser security rule, you can set the controls in the [Browser Security controls page](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-security-rules.html#task-wlg_c5t_fcc_step-browser-security).
-   You can [edit an existing rule](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules.html#manage-prisma-access-browser-policy-rules_task-edit-rules).
-   You can [create a policy profile](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles.html#manage-prisma-access-browser-policy-profiles_task-jfp_rny_fcc) and attach it to a rule.
-   You can select it from Strata Cloud Manager ConfigurationPrisma Browser PolicyControlsBrowser Security.

For information on a control, select the group where it is contained:

-   [Browser Security – Browser Session](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-browser-session.html)
-   [Browser Security – Browser Hardening](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-browser-hardening.html)
-   [Browser Security – Passwords and Autofill](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-saved-data.html)
-   [Browser Security – Network Protection](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-network-protection.html)
-   [Browser Security – Extensions](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-extensions.html)
-   [Browser Security – Internet Express Compatibility Mode](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-internet-explorer-compatibility-mode.html)
-   [Browser Security – Printers](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-printers.html)
-   [Browser Security – Privacy](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-privacy.html)
-   [Browser Security – Protected Browsing – Attack Surface Reduction](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-protected-browsing.html)