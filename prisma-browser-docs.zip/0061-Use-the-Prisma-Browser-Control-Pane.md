---
title: "Use the Prisma Browser Control Pane"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/user-guide/prisma-access-browser-use-the-control-pane"
depth: 2
breadcrumbs: "Home > Prisma Browser > Use the Prisma Browser Control Pane"
updated: "Tue Feb 10 06:48:18 PST 2026"
---

# Use the Prisma Browser Control Pane
Learn how to set up and use your Cloud managed Prisma Access Secure Enterprise Browser (Prisma Browser) control pane.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Prisma Browser | [Set up and use](/content/techdocs/en_US/prisma-access-browser/user-guide/prisma-access-browser-setup-and-use.html) |

The Prisma Browser Control Pane provides additional tools and features that can provide some information and tools for you as well as for end users.

1.  Click on the Prisma Browser icon to open the pane.
    
2.  If there are any issues, open the Troubleshoot page by clicking the shield icon next to the personal image. See Troubleshoot the Prisma Browser for more information on opening the page. The Troubleshooting page provides information on the status and diagnostics of the browser.
    
3.  Use the following tools and features:
    
    1.  Posture – Displays the Troubleshoot page, where you can see if there are any errors or issues with the Browser. This is accesses by clicking on the shield icon.
        
    2.  Lock – Locks the Prisma Access Browser. It can only be unlocked with the PIN code, biometric authentication, or a passkey.
        
    3.  Manage profiles – Applicable if you have multiple profiles. For example, you have multiple profiles over different Prisma Access Browser tenants.
        
    4.  Logout – Logs out of the browser. You need to fully sign in again to access the browser.
        
    5.  Getting started and customization – Provides some quick end-user information about the Prisma Access Browser and allows end users to customize their accounts with their picture and to import their bookmarks. For more information. See Getting Started and Customization.
        
    6.  Show sidebar – Toggles the display of the sidebar. Your administrator must have the sidebar enabled to use this feature.