---
title: "Configure Autonomous Digital Experience Management (ADEM)"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-autonomous-digital-experience-management-adem"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Customization Controls > Configure Autonomous Digital Experience Management (ADEM)"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure Autonomous Digital Experience Management (ADEM)
Adem configuration for PAB

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Real User Monitoring (RUM)

This feature controls the ability to install or uninstall the ADEM plugin.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Autonomous Digital Experience Management.
    
3.  Select one of the following options:
    
    -   **Activate** - Allow the ADEM plugin to install.
        
    -   **Deactivate** - Allow the ADEM plugin to uninstall.
        
    
4.  Click Set.