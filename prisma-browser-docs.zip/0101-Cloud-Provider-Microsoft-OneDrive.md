---
title: "Cloud Provider - Microsoft OneDrive"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/cloud-storage-integrations/cloud-provider-microsoft-onedrive"
depth: 3
breadcrumbs: "Home > Prisma Browser > Cloud Storage Integrations > Cloud Provider - Microsoft OneDrive"
updated: "Tue Feb 10 06:48:41 PST 2026"
---

# Cloud Provider - Microsoft OneDrive
This document contains the directions for integrating Microsoft OneDrive as the cloud provider

## Microsoft OneDrive Prerequisites

These are the prerequisites for configuring Microsoft OneDrive as your cloud provider:

-   Global Administrator access in Azure Active Directory (AD)

End users require a valid Microsoft 365 license:

-   Microsoft 365 Business Basic /Standard / Premium
-   Microsoft 365 Apps for Business
-   Microsoft 365 E3 / E5

## Configure Microsoft OneDrive as the Cloud Provider

1.  Register a new app in Azure.
    
    1.  Sign in to the [Azure Portal](https://portal.azure.com/).
        
    2.  Go to **Azure Active Directory → App registrations → + New registration**.
        
    3.  Enter a descriptive name (for example, _Prisma Browser Cloud Storage for M365_)
        
    4.  Choose **Single tenant** (Accounts in this organizational directory only).
        
    5.  Under **Redirect URI**, select **Single-page application (SPA)** and use this URI: https://gdhaibkimkeghllnpodfpoamchapggea.chromiumapp.org/
        
    6.  Click **Register**.
        
    
2.  Add Permissions to the New App.
    
    1.  Open the new app **→ App permissions → + Add a permission**.
        
    2.  Choose **Microsoft Graph**.
        
    3.  Add the following Application permissions:
        
        -   Application.Read.All
        -   DelegatedPermissionGrant.Read.All
        
    4.  Click **+Add a permission → Microsoft Graph → Delegated permissions**.
        
    5.  Add the following permission:
        
        -   Files.ReadWrite.All
        
    6.  Click **Grant admin consent for <your tenant name>** Click **Yes** in the consent confirmation pop-up.
        
        User.Read permission (delegated) is added by default by the application. DO NOT REMOVE THIS PERMISSION.
        
    
    WHY ARE THESE PERMISSIONS NEEDED?
    
    **Prisma Browser** requires specific permissions. These are the minimum necessary to ensure proper connection and to manage file downloads to your organization's cloud storage. This **least-privilege** approach minimizes security risks by only requesting access essential for its operation.
    
    | **Permission Type** | **Permission Name** | **Reason** |
    | --- | --- | --- |
    | Delegated | User.Read | Confirms that the user connected to the browser is the same user that is connected to Microsoft. |
    | Delegated | Files.ReadWrite.All | Saving files to the user's OneDrive on their behalf. |
    | Application | Application.Read.All DelegatedPermissionGrant.Read.All | Verifies the integration configured by the Microsoft admin. |
    
    Admins always consent to application permissions. In contrast, end users consent to delegated permissions. Granting admin consent for delegated permissions is required. It prevents users from mistakenly denying permissions, which would block them from downloading and saving files to OneDrive when a Security policy is triggered.
    
    Verifying the onboarding status of the integration is critical. Improper configuration will prevent Prisma Browser from saving files to OneDrive. This will block end users from downloading and saving files when their download action matches a policy rule.
    
3.  Generate Client Secret.
    
    1.  Go to **Certificates & Secrets → New client secret**.
        
    2.  In the Add a client secret tab, do the following:
        
        1.  Enter a **description** for the secret, for example - Microsoft secret 01. (this field is optional.
        2.  In the **Expires** field, select **730 days (24 months)**.
        
    3.  Click **Add**.
        
    4.  Copy the value of the new client secret. You will need it for the next step when you connect the cloud storage to the Prisma Browser. We recommend that you save it in a safe place.
        
    
4.  Connect to the Prisma Browser.
    
    1.  Go to the Prisma Browser admin console and select **Integrations**.
        
    2.  Select **Cloud Storage**.
        
    3.  Click on either **+add provider** or **Connect your first provider**.
        
    4.  Select the provider - **Microsoft**.
        
    5.  Insert a descriptive **Storage name** for the connection, for example - _Microsoft Cloud Storage_.
        
    6.  Paste the **Client secret** that you generated in the previous step.
        
    7.  Enter the Application (client) ID and the Directory (tenant) ID from the Application Overview in the Azure Portal.
        
    8.  Click **Test provider connection** to verify the connection with Azure.
        
    9.  Once the test is successful, click **Add Provider**.
        
    
5.  Create the Save to Cloud Rule
    
    1.  Open the **Access & Data Control** rules and create a new rule.
        
    2.  At the **Data Control** step, select **File Download**.
        
    3.  Select **Save to organization storage** and choose the provider that you configured in the previous step.
        
    4.  Add any additional details, and click **Set**.
        
    

## Known Limitations and Requirements

To successfully use Save to Cloud, users must meet the following conditions:

-   **Microsoft 365 Licensing:** The policy must apply only to users who hold a valid Microsoft 365 license that includes access to OneDrive and the Office suite.
-   **Email Consistency:** The email address used to sign into the browser must match the Microsoft account associated with the user’s OneDrive. This prevents accidental data leakage or cross-account DLP violations.
-   **Microsoft Sign-In Required:** Users must be signed into their Microsoft account. If not already authenticated, they will be prompted to log in, with the browser providing a username hint to streamline the process.

HTML sites will be compressed using zip format and saved in a folder. The Prisma Browser does not support unzipping files. As a result, this is not recommended.