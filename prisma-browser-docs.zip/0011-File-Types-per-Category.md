---
title: "File Types per Category"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/file-types-per-category"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > File Types per Category"
updated: "Mar 12, 2026"
---

# File Types per Category
The following categories show the fie types that can be allowed or blocked when File Upload or File Download use specific file types.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
|  |  |

The following categories show the fie types that can be allowed or blocked when File Upload or File Download use specific file types.

| **Documents** | doc, docm, docx, dot, dotm, dotx, odt, rtf, pdf, txt, wps, xps, csv, dbf, dif, ods, prn, slk, xls, xlam, xls, xlsb, xlsm, xlsx, xlt, xltm, xltx, xlw, odp, pot, potm, potx, ppa, ppam, pps, ppsm, ppsx, ppt, pptm, pptx, thmx |
| --- | --- |
| **Multimedia** | jpg, jpeg, bmp, png, gif, tif, svg, webp, wmf, wmv, emf, mp3, mp4, mov, m4a, m4v, mpg, mpeg, avi, flv, 3gp, 3gpp, 3g2, 3gp2 |
| **Source Code** | a, asm, asp, awk, bat, c, class, cmd, cpp, cxx, db, def, des, dlg, dpc, dpj, dxp, h, hpp, hrc, hxx, idl, ilb, inc, java, js, jsp, l, ll, pl, pm, ps, s, scp, sh, src, y, yxx |
| **Web Pages** | htm, html, mht, mhtml, xml, xps, xhtml, xht, shtml |
| **Archives** | a, ar, tar, bz2, gz, lz, lz4, lzma, z, 7z, s7z, ace, b6z, kgb, lzh, lha, pea, rar, war, xar, zip, zipx, zz |