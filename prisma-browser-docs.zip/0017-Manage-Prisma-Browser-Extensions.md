---
title: "Manage Prisma Browser Extensions"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-extensions"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Extensions"
updated: "Mar 12, 2026"
---

# Manage Prisma Browser Extensions
Learn how to view and manage extensions for Prisma Access Secure Enterprise Browser (Prisma Browser).

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

The Prisma Browser maintains an Extension directory that includes extensions installed by end-users on the browser. This information allows you to maintain proper corporate policy management, manage visibility and risk analysis.

The Extension list displays details of each Extension, and includes the following information:

-   **Name** - The Extension name.
    
-   **Users** - The number of users who have installed the extension on their devices.
    
    If there are more users than devices, it indicates that some devices are being used by multiple users..
    
-   **Devices** - The number of devices where the extension is installed. If there are more users than devices, it indicates that some users have access to multiple devices.
    
-   **Risk score**\- Risk for an extension is determined by a combination of the risk impact and the risk likelihood considering its permissions, credibility of the reviews, and the reputation of the extension publisher. The higher the risk score, the greater the chance that the extension is malicious.
    
    In Prisma Browser, the malicious extension is blocked, and will be completely removed from the user's device. For Prisma Browser Extension, the malicious extension is disabled.
    
    You can hover over the Extension's Risk score to see the actual score \`(pit of 5). The scores and the risk level are as follows:
    
    -   **Low** - Score between 1-2
        
    -   **Medium** - Score of 3
        
    -   **High** - Score between 4-5
        
-   **Extension ID** - The identification number of the extension. The ID links to the source of the extension.
    

1.  From Strata Cloud Manager, ConfigurationPrisma Browser DirectoryExtensions.
    
2.  Search for specific applications by name or Extension ID.
    
3.  **Filter** the applications based on specific options:
    
    -   **Source** - Filter the list by the original source of the extension.
        
    -   **Status** - Filter the extensions based on whether or not the extension is in use or not.
        
    
4.  Select an extension to open the extension drawer. The drawer contains some additional information regarding the extensions.
    
    -   **Installation source** - Displays the source of the installation. There can be more than one source for the extension.
        
    -   **Extension ID** - The identification number of the extension. The ID links to the source of the extension.
        
    -   **Risk score**\- The Risk Score is determined based on the extension's permissions, source code analysis, credibility of reviews, and the publisher's reputation. The score falls into the following ranges:
        
        -   **Low** - Score between 0-2
            
        -   **Medium** - Score of 3
            
        -   **High** - Score between 4-5
            
    -   **Risk likelihood** - This value determines the likelihood of an extension becoming malicious. The score falls into the following ranges:
        
        -   **Low** - Score between 0-2
            
        -   **Medium** - Score of 3
            
        -   **High** - Score between 4-5
            
    -   **Risk impact** - This value measures the impact of the extra permissions an extension can access. A high risk impact means that the extension has access not more sensitive permissions.
    -   **Manifest** - The version of the Manifest platform that is used.
    -   **Global stats**\- Displays the basic global statistics from ChromeStats data. The information includes:
        
        -   **Download count** - The number of times that the extension was downloaded.
            
        -   **Rating** - The global rating for the extension.
            
        -   **Last version update** - The last time that the publisher issued an update and version number.
            
    -   **Overall permissions** - Displays the permissions that are granted to the extension. Click on the permission to see a description.
        
    -   **Web access permissions** \- Displays the list of websites with which the extension has permission to interact. If the extension has access to all websites, the result will be **All URLs**.If the extension does not have any website access permissions, then the section will _not_ appear.
        
    -   **Installations** - The number of devices where the extension is installed. The figure can be displayed by extension version or by source (if more than one source is applied to the extension.
        
    -   **Recent Activities** - Displays the recent activity for the extension.