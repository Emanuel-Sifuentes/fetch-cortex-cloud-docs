---
title: "IGEL Deployment"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/prisma-access-browser-update-mechanics/igel-deployment"
depth: 3
breadcrumbs: "Home > Prisma Browser > Installers and Updates > IGEL Deployment"
updated: "Tue Feb 10 06:48:28 PST 2026"
---

# IGEL Deployment
This is the IGEL deployment information

Prisma Browser installation and update over IGEL OS is performed via the **IGEL App Portal**. For more information, refer to the [IGEL App Portal](https://app.igel.com/).