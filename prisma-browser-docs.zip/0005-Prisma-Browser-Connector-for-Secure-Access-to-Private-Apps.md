---
title: "Prisma Browser Connector for Secure Access to Private Apps"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/onboard-the-prisma-browser-connector"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Browser Connector for Secure Access to Private Apps"
updated: "Feb 2, 2026"
---

# Prisma Browser Connector for Secure Access to Private Apps
Secure private applications on remote, unmanaged devices with Prisma Browser Connector, by allowing Prisma Browser to seamlessly connect to Data Centers using ZTNA-Connectors.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Prisma Browser Standalone | Prisma Browser Standalone license; Prisma Browser Connector dd-on license; Prisma Browser Connector; Network Administrator or Superuser role. |

Prisma® Browser Connector integrates Prisma Browser with ZTNA Connector to provide secure access to private applications. This feature simplifies private application access for remote unmanaged devices with new or existing Prisma Browser Standalone deployments or existing Next Generation Firewall (NGFW) customers by eliminating the need for a full Prisma Access deployment. It offers a streamlined, secure channel for private application traffic, focusing on ease of use and integration within your network.

The Prisma Browser Connector leverages the Prisma Browser as a client-side endpoint and a ZTNA Connector virtual machine (VM) in your private network.

## Connection Protocols

The Prisma Browser Connector supports the following connection protocols:

-   MASQUE
-   HTTP 2
-   HTTP 1.1

The Prisma Browser Connector establishes a secure and efficient connection using the MASQUE (QUIC) Protocol. If the QUIC protocol is unavailable or blocked in transit, then it falls back to HTTP2 automatically.

The process involves:

-   **Automated Connection and Orchestration**: The Prisma Browser Connector and MASQUE Proxy work with Orchestration for ZTNA-C (Zero Trust Network Access Connector) to manage the connection.
-   **Closest Region Selection**: The Prisma Browser Connector automatically selects the cloud region closest to where the ZTNA-Connector is deployed.
-   **Connection Establishment**: The Prisma Browser establishes the connection, creating Automated Tunnels across the Internet to the selected worldwide data center location.

The Prisma Browser Connector supports secure access to both web-based (HTTP/HTTPS) and non-web-based private applications (SSH/RDP). It is also able to scale automatically to meet traffic needs.

The Prisma Browser Connector supports up to 10 ZTNA Connectors per deployment. This allows you to manage the scope and resource allocation. For more information, refer to [ZTNA Connection Requirements and Guidelines](https://docs.paloaltonetworks.com/prisma-access/administration/ztna-connector-in-prisma-access/ztna-connector-requirements-and-guidelines).

## Deploy the Prisma Browser Connector for Private Application Access

This section provides the step-by-step instructions for configuring the Prisma Browser Connector within the Strata Cloud Manager. This section describes:

-   **Step 1:** User Onboarding
-   **Step 2:** Private Application Setup
-   **Step 3:** Enforce SSO Applications
-   **Step 4:** Download and Distribute
-   **Step 5:** Browser Policy

## Step 1: User Onboarding

Onboard users and configure [Cloud Identity Engine (CIE) integration](https://docs.paloaltonetworks.com/cloud-identity/cloud-identity-engine-getting-started/associate-a-cloud-identity-engine-instance). This establishes the necessary user authentication framework, allowing authorized users to access private applications via the Prisma Browser.

If you have already completed user onboarding as part of the regular Prisma Browser Standalone onboarding process, you can skip this step.

1.  Click the **Users** tab.
2.  Select an [authentication profile](https://docs.paloaltonetworks.com/cloud-identity/cloud-identity-engine-getting-started/authenticate-users-with-the-cloud-identity-engine/set-up-an-authentication-profile) from the **Cloud Identity Engine (CIE)**.
3.  Specify the relevant **user groups** that will be granted access.

## Step 2: Private Application Setup

Download and deploy the [ZTNA Connector](https://docs.paloaltonetworks.com/strata-cloud-manager/getting-started/insights-scm/monitor-data-centers/monitor-data-centers-ztna-connectors). This initiates the deployment and configuration process for the ZTNA Connector, which serves as the secure gateway for private application access.

1.  Click the **Private Applications** tab.
    
2.  Click **Deploy** **ZTNA Connectors.** This section defines the infrastructure and specific private applications that the ZTNA Connector manages. In the dropdown section, click “Follow the setup instructions in the **ZTNA Connection Configuration."** Go to [Configure ZTNA Connector](https://docs.paloaltonetworks.com/prisma-access/administration/ztna-connector-in-prisma-access/configure-a-ztna-connector) for more information.
    
    When you configure Target Apps in the ZTNA Connector, you must add them to the Prisma Browser Application page as well. Apps added on IP Subnets are not currently supported on Prisma Browser.
    
3.  Open the Prisma Browser Applications page (ConfigurationPrisma BrowserApplications and select the **Private Applications** tab. This allows you to define **application targets** using FQDNs, and wildcards. These targets specify the internal private applications (web or non-web) the ZTNA Connector will make accessible to Prisma Browser users.
    
    Applications added to the ZTNA Connector must also be added to the Prisma Browser in the Applications page.
    
    Public apps configured as Private apps are not supported.
    
    1.  Click **Add private app**, and enter the required information. For more information, refer to [Add a Private Application](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-applications?otp=task-iq1_skt_fcc#task-iq1_skt_fcc).
        
    2.  Select the Non-web Apps tab and click Add non-web App if you need to add apps that are SSH- or RDP-based. This extends secure access capabilities beyond web-based applications to include other crucial enterprise services.
        

The remaining steps are configured in a manner similarly to thoes in the Prisma Browser Onboarding. Refer to the following steps:

-   [Enforce SSO applications](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-onboarding?otp=task-brr_td4_gcc#task-brr_td4_gcc)
-   [Download and distribute](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-onboarding?otp=task-ebf_d24_gcc#task-ebf_d24_gcc)
-   [Browser policy](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-onboarding?otp=task-hnh_bf4_gcc#task-hnh_bf4_gcc)

## Validate Private Application Access with Prisma Browser

Once the Strata Cloud Manager is properly configured, your end-users can validate private application access using the Prisma Browser.

## Step 1: Log into the Prisma Browser

1.  Open the Prisma Browser application.
2.  Complete the SSO login process, which typically redirects through your configured CIE.§§§§§§§

## Step 2: Access a Configured Private Web App

Access a configured private web application. This step verifies that web-based private applications are correctly routed and accessible through the Prisma Browser Connector infrastructure.

1.  Navigate to the URL of a private web application (for example, WC app1 van2 auto.com) within the **Prisma Browser**.
2.  Confirm successful access and functionality of the application.

## Step 3: Access a Configured Private Non-Web App

Access a configured private non-web application (for example, SSH) using remote connections. This validates secure access to non-web services, demonstrating the full capability of the Prisma Browser Connector for diverse application types.

1.  In the **Prisma Browser**, go to **Non-web connections**..
2.  Select and connect to a configured private non-web application, such as an **SSH** server.
3.  Provide any necessary credentials (for example, a **private key**) and confirm a successful connection.

## Step 4: Check the Troubleshooting Page

Review the Prisma Browser troubleshooting page for proxy status and routing details. This diagnostic step allows you to confirm that traffic is being correctly proxied through the Prisma Browser Connector infrastructure and to identify any potential routing issues.

1.  In the **Prisma Browser** address bar, type prisma://troubleshoot and press **Enter**..
2.  Review the **Prisma integration** page to verify the **proxy** status, type (for example, MASQUE), and confirm that traffic is routing over the **MASQUE** infrastructure for private applications.
    

## Known Limitations

The following are the known limitations of the Prisma Browser Connector:

1.  Apps added via IP Subnets are currently not supported. They can only be defined using FQDNs and wildcards.
2.  Public apps configured as Private apps are not supported.
3.  Once a group, connector, or application is created, the IP blockers cannot be changed.
4.  The system supports a limit of up to 10 ZTNA Connectors per tenant.
5.  If the MASQUE (QUIC) is not available or blocked, the system defaults to HTTP2.
6.  The system only supports RDP and SSH protocols for non-web apps.
7.  Application targets must be defined using FQDNs or wildcards.
8.  Some menus that are unavailable in **Prisma Browser** (but are available in **Prisma Access**) may still appear in the interface; however, these menus are not functional and should not be used.