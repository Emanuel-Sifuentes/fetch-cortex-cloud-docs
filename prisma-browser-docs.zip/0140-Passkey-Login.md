---
title: "Passkey Login"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules/login-controls/passkey-login"
depth: 5
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Rules > Manage Prisma Browser Access and Data Control Rules > Login Controls > Passkey Login"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Passkey Login
this is information for Passkey login

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Passkeys offer a passwordless, secure, and convenient method for signing into apps and websites. They use your device's built-in security (like fingerprint, face scan, or PIN) and public-key cryptography to generate unique, phishing-resistant credentials that automatically sync across your devices and act as a Multi-Factor Authenticator.

Some passkeys are managed for corporate access (such as IdP authentication, or PB [authentication factor](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-browser-hardening?otp=task-ydp_f2l_hcc#task-ydp_f2l_hcc)). However, users are frequently prompted by third-party websites to create passkeys for convenience. Consequently, they often generate personal passkeys that are unseen and outside of IT control.

PB solves this by providing **granular control over passkey login**. Administrators can apply policies to allow or deny passkey usage based on application, device posture, network, or location. For example, you can explicitly allow passkey login for your sanctioned Identity Provider (e.g. Okta), while blocking passkey usage on other, non-corporate applications.

The Passkey Login control is supported on Prisma Browser and Prisma Browser Extension.

To enable Passkey Login Control:

1.  At the Login controls tab, select **Passkey** login.
    
2.  Click on the **Passkey login** tab to open **Control Passkey login**, and select one of the following options:
    
    1.  **Allow** - Logins using Passkeys will be permitted.
        
    2.  **Block** - Logins with Passkeys will be blocked.
        
    
3.  If you select Allow, you can require the use of multi-factor authentication.
    
    1.  Click on the **MFA** tab to open the Multi Factor Authentication.
        
    2.  Select **Require additional MFA prior to login**.
        
    
    The Prisma Browser Extension does not support Multi Factor Authentication; any configuration for Prisma Browser Extension will be ignored.
    
4.  If you select **Block**, you can allow your users to prompt for special permission to bypass the negative result. Click the **Prompt** tab.
    
    1.  **Pop-up Notifications**. Select one of the following options.
        
        -   **Warn and allow to proceed anyway** - Users will receive a warning but they can proceed anyway.
        -   **Warn and allow to proceed anyway with a reason** - Users will receive a warning but they can proceed if they provide a reason.
        -   **Permission Request** – You will receive a message requesting permission.
        
    2.  **Bypass timeframe** – Indicate how long any bypass will be valid.
        
    
5.  If you want to configure a custom **Dialog text** that will appear when the user is blocked, do the following:
    
    1.  Click **Dialog text**.
        
    2.  Select one of the following options:
        
        1.  **Use default texts** - Do not provide any custom texts for your users.
        2.  **Customize default texts** - Enter a Title for your message and an optional description
        
    
6.  Click **Set**.