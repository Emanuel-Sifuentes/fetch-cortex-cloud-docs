---
title: "Integrate Prisma Browser with Microsoft 365"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/third-party-integrations/integrate-prisma-access-browser-with-microsoft-365"
depth: 3
breadcrumbs: "Home > Prisma Browser > Third-Party Integrations > Integrate Prisma Browser with Microsoft 365"
updated: "Tue Feb 10 06:48:41 PST 2026"
---

# Integrate Prisma Browser with Microsoft 365
Integrate Prisma Browser with Microsoft 365 (formerly Office 365) to enable your users to open encrypted documents in the Prisma Browser.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Browser | Prisma Access with Prisma Access Browser bundle license or Prisma Access Browser standalone license; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html); Microsoft 365 |

**This feature will be deprecated in March 2026.**

You can integrate Prisma Browser with Microsoft 365 (formerly Office 365) to allow your users to open encrypted documents in the Prisma Browser.

To integrate with Microsoft 365, you will need to obtain the tenant ID and client ID from the Microsoft Azure portal, and then enable the integration in Strata Cloud Manager.

1.  Find your tenant ID.
    
    1.  Sign in to the [Azure portal](https://portal.azure.com/).
        
    2.  Make sure you're signed in to the tenant you want to find the ID for. If you're not in the correct tenant, [switch directories](https://docs.microsoft.com/en-us/azure/azure-portal/set-preferences#switch-and-manage-directories) .
        
    3.  Under Azure services, select Microsoft Entra ID. If you don't see Microsoft Entra ID, use the search function to find it.
        
    4.  Locate the Tenant ID in the Overview page.
        
    
2.  Obtain your Microsoft 365 application (client) ID.
    
    1.  Log in to the [Azure portal](https://portal.azure.com/).
        
    2.  Make sure you're signed in to the correct tenant If you're not in the correct tenant, [switch directories](https://docs.microsoft.com/en-us/azure/azure-portal/set-preferences#switch-and-manage-directories) .
        
    3.  Under Azure services, select Microsoft Entra ID. If you don't see Microsoft Entra ID, use the search function to find it.
        
    4.  Under Manage, select App registrationsNew registration.
        
    5.  Enter a display Name for your application. Your users will see the display name when they interact with the app.
        
        You can change the display name at any time or use it for multiple app registrations. It doesn't affect the automatically generated Application (client) ID, which uniquely identifies your app.
        
    6.  Specify which users can use the application.
        
    7.  For Redirect URI, select Single Page Application (SPA) and provide the following URI: [Microsoft 365](https://gdhaibkimkeghllnpodfpoamchapggea.chromiumapp.org/).
        
    8.  Click Register.
        
        When registration finishes, you can find the Application (client) ID in the app registration's Overview page.
        
    
3.  Enable the integration in Strata Cloud Manager.
    
    1.  Go to ConfigurationPrisma BrowserAdministrationIntegrationsServices.
        
    2.  Scroll to Office 365 Integration and expand it.
        
    3.  Click Enabled, then enter the Microsoft 356 Tenant ID and Client ID.
        
    4.  Click Save.
        
    
    The following file types are supported:
    
    -   doc, dot, docx, dotx, dotm, docm
    -   xls, xlt, xla , xlsx, xltx, xlsm, xltm, xlam, xlsb
    -   ppt, pot, pps, pptx, potx, ppsx, ppam, pptm, potm, ppsm
    -   mdb