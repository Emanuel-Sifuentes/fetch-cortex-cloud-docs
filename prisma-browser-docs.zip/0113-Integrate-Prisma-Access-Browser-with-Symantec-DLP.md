---
title: "Integrate Prisma Access Browser with Symantec DLP"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/third-party-integrations/integrate-prisma-access-browser-with-symantec-dlp-integration"
depth: 3
breadcrumbs: "Home > Prisma Browser > Third-Party Integrations > Integrate Prisma Access Browser with Symantec DLP"
updated: "Tue Feb 10 06:48:41 PST 2026"
---

# Integrate Prisma Access Browser with Symantec DLP
Integrate the Prisma Access Browser to with Symantec DLP to provide sensitive data protection for Prisma Access Browser users.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Access Browser | Prisma Access with Prisma Access Browser bundle license or Prisma Access Browser standalone license; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html); Symantec DLP |

You can integrate the Prisma Access Browser to with Symantec DLP to provide sensitive data protection for your Prisma Access Browser users. Symantec DLP can detect and protect sensitive data in cloud apps, endpoints, networks, and data centers.

After you integrate with Symantec DLP, your Prisma Access Browser users will be able to use it as a file scanning engine. For more information, refer to [Malicious File Protection](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls).

1.  To enable the Symantec DLP integration in Strata Cloud Manager:
    
    1.  Go to ManageConfigurationPrisma Access BrowserAdministrationIntegrationsServicesConfigurationPrisma Access BrowserAdministrationIntegrationsServices.
        
    2.  Scroll to Symantec DLP Integration and expand it.
        
    3.  Click Enabled, then complete the following steps:
        
        -   Enter the Symantec DLP URL.
        -   Enter the Detector ID.
        -   Enter the Filter ID.
        -   Upload the Client Certificate in .pfx format.
        -   Provide the Key Passphrase.
        
    4.  Click Save.