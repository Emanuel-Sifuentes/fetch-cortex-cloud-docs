---
title: "Configure Native RDP/SSH"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-applications/configuring-native-rdp-ssh"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Applications > Configure Native RDP/SSH"
updated: "Mar 12, 2026"
---

# Configure Native RDP/SSH
Guide to configure RDP/SSH

| Where Can I Use This? | What Do I Need? |
| --- | --- |
|  |  |

Native RDP/SSH is a feature in Prisma Browser that allows you to access RDP (Remote Desktop Protocol) and SSH (Secure Shell) applications **without the need for additional licenses.**

This feature **replaces** the existing RDP/SSH capabilities found under Prisma Browser’s **Remote Connections**.

**Key Changes Upon Activation:**

-   Native RDP takes precedence over PRA (Prisma Access Remote Access) and Remote Connections will no longer work via Prisma Browser on the tenant.
    
-   A new option, **Non-Web Apps,** appears under the **Applications Tab**.
    
-   The **Non-Web Apps** option under the **Access and Data Control rule** will be renamed **Remote Connections.**
    

## Configure the Native RDP/SSH

The configuration flow for Non-Web applications is similar to setting up Remote Connections.

**A. Applications Tab (Non-Web Apps)**

In the Applications directory, do the following:

1.  Click the **Non-web Apps** tab and click **Add non-web app**.
    
2.  In the **Add Non-web Apps** window, enter the information as needed.
    
3.  Be sure to configure the **Non-Web App** using an **FQDN** (Fully Qualified Domain Name) or an **IP address**.
    
4.  The configuration supports **non-standard ports**.
    
    1.  The standard RDP port is 3389
        
    2.  The standard SSH port is 22
        

**B. Access and Data Control Rule**

-   The rule creation flow remains the same as for any other application.
    
-   Within the **Non-Web** Application settings, you can allow the user to add **Manual Connections** or disable this functionality as per the defined scope.
    

For tenants with Prisma Access entitlement, all traffic associated with user-created applications established through the manual connections option is routed through Prisma Access by default.

## Enable Native RDP/SSH

To enable and fully utilize the Native RDP/SSH feature, follow these steps:

1.  Configure a Non-Web App under the Applications directory.
2.  Create an Access and Data Control Policy allow access to the newly configured Non-Web App.
3.  Create a Security Policy under Explicit Proxy (EP).
    -   This step is necessary to allow access to RDP/SSH applications that may reside within your data center.
        
        1.  Navigate to **Configuration** > **NGFW and Prisma Access**.
        2.  Change the Configuration Scope to **Prisma Access** or **Explicit Proxy**.
        3.  Create a Security Rule in Explicit Proxy with the following parameters:
            
            -   **Source:** Trust
            -   **Destination:** Any or Specific Location
            -   **Applications:** ms-RDP and SSH
            -   **Action:** Allow
            
            You may need to duplicate these policies on other intermediaries, such as the Next-Generation Firewall (NGFW), that are in the path to your private applications.
            
            Once a port is selected, it cannot be changed in any way. You need to define a new application with the desired port.
            
        

### Migration from Remote Connections

Native Clients and Remote Connections/PRA **cannot co-exist** in Prisma Browser. Remote Connections/PRA must be disabled first for Native RDP/SSH to work.

If Remote Connections/PRA is currently enabled on your tenant, you must **request the feature be enabled** via #help-pb-native-clients (channel/alias)

1.  **Take Note of All Configurations:** Before disabling, record all existing Remote Connection configurations as you will need to manually reconfigure the applications and update the policies later.
    
    -   _Self-Correction: You will need this information to re-configure the apps as Non-Web Apps._
        
2.  **Disable Remote Connections:**
    
    -   Navigate to **Administration** > **Remote Connection**.
        
    -   Disable the toggle switch.
        

1.  **Configure Non-Web Apps:** Once disabled, **Remote Connections** will be renamed to **Non-Web Apps** in the administration screens. You can now configure the applications and policies for the new feature.
    
2.  **Follow the Enablement Steps:** Proceed with the steps outlined in **Enable Native RDP/SSH**.
    

### User Experience

Users access the Remote Connections feature through the Prisma Browser client interface.

1.  Click on the **Prisma Browser Profile Icon**.
    
2.  Click on **Remote Connections**.
    

This will open a new tab for Remote Connections where the user can view:

-   All RDP/SSH applications allowed per the policy created by the administrator.
    
-   An option to add **"New Connections,"** _if_ the **Manual Connect** option is enabled for their profile/scope.
    

**Connection Management:**

-   Connections **defined by the user** can be **Edited** or **Deleted** from the list.
    
-   Connections **defined by the administrator** **cannot** be edited by the user.

Only 1 additional connection can be defined with the same IP/FQDN. This means that a maximum of 2 IP/FQDNs can share the same connection.