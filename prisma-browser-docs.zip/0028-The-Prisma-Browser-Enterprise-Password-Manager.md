---
title: "The Prisma Browser Enterprise Password Manager"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/the-prisma-access-browser-enterprise-password-manager"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > The Prisma Browser Enterprise Password Manager"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# The Prisma Browser Enterprise Password Manager
The information that everyone needs about the browser.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Password-related breaches remain a major risk in enterprise environments. The Prisma Browser introduces centralized password management to enforce secure handling of credentials.

Built-in browser managers lack enterprise features like policy rule controls, access management, encryption, and audit logging. Extensions add functionality but increase the attack surface and are vulnerable to user tampering.

Integrating password management with existing identity and access systems adds complexity and cost. As a result, many organizations avoid standardization, leading to insecure practices such as password reuse, and unauthorized credential sharing.

## The Prisma Browser Enterprise Password Manager

To address these challenges, we developed the Enterprise Password Manager as a first-party solution, purpose-built to meet the needs, and tightly integrated with Prisma Browser. The solution supports complex enterprise requirements by enabling robust security controls, seamless policy rule enforcement, and a streamlined user experience.

## Key Features

## Password Manager - User Guide

[Click here to go directly to the Admin Guide](#concept-mmv_gmh_jfc_adminguide).

## Password Manager Inventory

The Password Manager in Prisma Browser enables users to securely store, manage, and use credentials for applications not integrated with the organization's identity provider.

The main page of the Password Manager is the Inventory page, where you can manage, create, edit, or remove logins.

You can open the inventory in the following ways:

-   Click the Prisma Browser icon → Password Manager.
-   Click Settings → Password and Autofill → Password Manager.
-   Open the Password Manager from one of the dialogs opened by the Browser when saving and updating or viewing passwords on a website.
-   Click on the Password Manager key icon on the Browser sidebar.
-   Navigate to prisma://password-manager/

When you open the Password Manager, it displays the list of available logins.

If you previously used the Legacy Password Manager in Prisma Browser, the system migrates your logins automatically to the Enterprise Password Manager.

If no logins exist, the Password Manager shows an empty state screen.

## Create a Login

You can manually create logins through the Password Manager Inventory.

To create a login manually, open the Inventory and click “Create login.” Enter the required details:

-   **Username** for the application (optional).
-   **Password** for the application (mandatory).
-   **URL** of the application that triggers the Password Manager to suggest this login (mandatory).
-   **Note** describing the login (optional).
    

## Manage Logins in the Inventory

Click a login to open its details pane, where you can view, edit, and manage the entry.

The browser may prompt you for a step-up MFA (PIN code or passkey) based on your admin policy rule before revealing login details.

You can view the details of a login using the available options:

-   Click the **reveal** or **copy** icons to view or copy the username or password (if allowed).
-   Click the **arrow** icon to open the URL associated with the login.
-   Click **Edit** to change the login details.
    
-   Click **Delete** to remove the login from the inventory (if allowed). **Make sure you have another way to access the website before deleting a login**.

## Password Generator

The Enterprise Password Manager includes a built-in password generator, accessible from the inventory page. This tool helps create strong, difficult-to-crack passwords.

1.  Navigate to the Inventory and click **Password Generator**.
    
2.  Choose your desired password characteristics.
    
3.  The generated password is displayed. Click to copy it to your clipboard.
4.  Paste the password when creating or updating account passwords or websites.

## Import Logins

You can import logins from a third-party browser or password manager by following these steps:

1.  Navigate to the Inventory and click **Import**.
    
2.  Select the source for the import.
    
3.  Export your logins from the source as a CSV file, following the provided instructions.
    
4.  Choose the CSV file to import your logins into the Prisma Browser Password Manager.

## Export Logins

You can export your stored passwords so that you can import them to another machine.

1.  Click on the Prisma Browser icon on the toolbar and click to open the **Control Pane**.
2.  Click **Password Manager**.
    
3.  In thee Password Manager, click **Export**.
    
4.  Exporting content from the Password Manager requires you to enter your MFA method.
    
5.  Export your logins from the source as a CSV file, and save it to your preferred location.
    
6.  Click **Save**. Choose the CSV file to import your logins into the Prisma Browser Password Manager.

## Settings

Click the **Settings** tab to enable or disable the Password Manager for your browser or to import logins from another browser or third-party Password Managers.

## Password Manager Interactions

The Password Manager automatically appears when it detects an available login for a URL or when you save or update a password for that URL.

## Save a Login

When you register on a site or log in to a URL that the Password Manager does not recognize, it prompts you to save a new login to the Prisma Browser Enterprise Password Manager.

Click **Login details** to add more information to the login.

If you missed or closed the dialog by mistake, you can get back to it by clicking the key icon.

## Update a Login

When you update a password in the Prisma Browser Enterprise Password Manager, the system prompts you to save the changes.

If you miss the prompt, click the key icon in the omnibox to reopen it.

## Use a Login

If there is a key icon in the omnibox, this means that there are saved logins for the current site.

Click on the icon to view the logins. You can drill down to see the details.

The browser might prompt you for a step-up MFA when you reveal login details.(PIN code, Passkey, or IdP authentication) based on your admin policy rule configured in [Browser Security > Browser Hardening > Authentication Factor](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-browser-hardening.html#configure-browser-hardening_task-ydp_f2l_hcc).

When you focus on an input field in a login form on a URL with an available login, the Password Manager suggests matching logins and enables you to autofill them.

To autofill the login, the browser can also require a step-up MFA based on your admin policy rule.

## Profile Sync

The Password Manager automatically syncs personal logins across user devices when you sign in with the same credentials.

This sync functionality works only if you enable profile sync in the **Browser Customization → Profile sync** policy rule settings.

The Password Manager officially supports desktop devices (Windows and macOS). It also syncs passwords to the mobile Password Manager where sync is supported.

## Prisma Browser Enterprise Password Manager - Admin Guide

## Policy Rule

The Password Manager is managed in the **Browser Security -> Saved Data -> Password Manager** control.

The default value of the control is **Enabled,** with MFA enabled on a 5-minute timeout.

The Password Manager can be enabled or disabled.

When it is disabled, the Password Manager pop-ups do not display, and the inventory will be disabled.

## Multi-factor Authentication

The system can require users to complete a step-up MFA based on policy rule when performing actions that involve retrieving a login, such as:

-   Opening a login from the Inventory
    
-   Viewing login details through the omnibox pop-up
    
-   Autofilling a login form
    

After a successful step-up MFA, the system won’t prompt again for a defined interval (5 minutes by default).

Administrators can enable or disable step-up MFA for all logins stored in the Password Manager by configuring the **Password Manager** policy rule control. They can also adjust the MFA Prompt Interval setting it to always prompt, or to a shorter or longer interval than the default.

You can configure the MFA factor in **Browser Security → Authentication Factor**. PAB currently supports local PIN and Passkey authentication. [Click here for more information.](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security?otp=task-ydp_f2l_hcc#task-ydp_f2l_hcc)

## Events

The Prisma Browser Enterprise Password Manager logs all actions that users perform within the manager, including:

-   **Login created** - The system logs when a user adds a login through the Inventory or the Save Login pop-up.
-   **Login deleted** - The system logs when a user deletes a login through the Inventory.
-   **Login details changed** - The system logs changes to a login’s details, including metadata or the password value.
-   **Login retrieved** - The system logs when a user retrieves a login by autofilling it or by using the **eye** icon or **copy** button to view or copy the credentials.

You can view these events in the Prisma Browser Event log under the new Password Manager category.

The system can forward these events to your organization's SIEM/SOC. You can then correlate them with other activity – such as login attempts, failed logins, or browsing events – to build a complete timeline around credential usage.