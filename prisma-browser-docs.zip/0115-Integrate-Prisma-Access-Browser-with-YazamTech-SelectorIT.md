---
title: "Integrate Prisma Access Browser with YazamTech SelectorIT"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/third-party-integrations/integrate-prisma-access-browser-with-yazamtech-selectorit"
depth: 3
breadcrumbs: "Home > Prisma Browser > Third-Party Integrations > Integrate Prisma Access Browser with YazamTech SelectorIT"
updated: "Tue Feb 10 06:48:41 PST 2026"
---

# Integrate Prisma Access Browser with YazamTech SelectorIT
Integrate the Prisma Access Browser with YazamTech SelectorIT to enable data transfer in a secure environment.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Access Browser | Prisma Access with Prisma Access Browser bundle license or Prisma Access Browser standalone license; f; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html); YazamTech SelectorIT |

You can integrate the Prisma Access Browser with YazamTech SelectorIT to protect your networks from external attacks by allowing data transfer in a secure environment, and blocking any unauthorized data transfer.

After you integrate with YazamTech SelectorIT, your Prisma Access Browser users can use it as a file scanning engine. For more information, refer to [Malicious File Protection](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls).

1.  To enable the YazamTech SelectorIT integration in Strata Cloud Manager:
    
    1.  Go to ManageConfigurationPrisma Access BrowserAdministrationIntegrationsServicesConfigurationPrisma Access BrowserAdministrationIntegrationsServices.
        
    2.  Scroll to YazamTech SelectorIT Integration and expand it.
        
    3.  Click Enabled, then enter the following information:
        
        -   The YazamTech URL
        -   The YazamTech username
        -   The YazamTech password
        
    4.  Enter the Tenant ID and Client ID.
        
    5.  Click Save.