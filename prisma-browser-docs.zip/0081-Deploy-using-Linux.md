---
title: "Deploy using Linux"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/deploy-prisma-access-browser/deploy-using-linux"
depth: 3
breadcrumbs: "Home > Prisma Browser > Deploy the Prisma Browser via MDM > Deploy using Linux"
updated: "Tue Feb 10 06:48:28 PST 2026"
---

# Deploy using Linux
+---directions on deploying PAB using Linux

## Distribution Agnostic Installation

Installation of the latest version on either Ubuntu/Fedora (MD5):

eaeb2552cdffe5842debb6c8b7f5cffd):

```
curl -fsS https://updates.talon-sec.com/linux/prisma-access-browser/install.sh | sudo bash
```

## Ubuntu

Dynamic list of Prisma Browser Linux (.deb) stable versions can be found [here](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=linux_deb&architecture=x64&channel=stable) . New stable versions are released on a weekly basis and will be reflected in the list

.

**Manual/One-time Installation**

Install the package using the downloaded .deb file.

```
sudo apt install prisma-access-browser-stable\_<version\_number>-1\_amd64.deb
```

**Package Repository (via MDM/Local)**

Create a new repository file under /etc/apt/sources.list.d

```
echo "deb \[arch=amd64\] https://updates.talon-sec.com/linux/prisma-access-browser/deb/ stable main" | sudo tee /etc/apt/sources.list.d/prisma-access-browser.list
```

**Import the GPG key (before using the repository)**

```
wget -q -O - https://updates.talon-sec.com/linux/prisma-access-browser/linux\_signing\_key.pub | sudo tee /etc/apt/trusted.gpg.d/pab.asc >/dev/null
```

Update the package list

```
sudo apt update
```

**Install Prisma Browser**

```
sudo apt install prisma-access-browser-stable
```

**Remove Prisma Browser**

```
sudo apt remove prisma-access-browser-stable
```

## Fedora

Dynamic list of Prisma Browser Linux (.rpm) stable versions can be found [here](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=linux_rpm&architecture=x64&channel=stable) . New stable versions are released weekly and are reflected in the list.

**Manual/One time Installation**

Install the package using the download rpm file.

```
sudo dnf install prisma-access-browser-stable <version\_number>-10x86\_64.rpm
```

If you are using sudo yum -

```
sudo yum install prisma-access-browser-stable <version\_number>-10x86\_64.rpm
```

**Package Repository**

-   **Create a new repository file under _/etc/yum.repos.d/package-name.repo_ with the following content:**
    
    ```
    \[prisma-access-browser\]
    name=prisma-access-browser
    baseurl=https://updates.talon-sec.com/linux/prisma-access-browser/rpm/stable/x86\_64
    enabled=1
    gpgcheck=1
    gpgkey=https://updates.talon-sec.com/linux/prisma-access-browser/linux\_signing\_key.pub
    ```
    
-   **Optionally - you can manually import the key (as is mentioned in the repo file**.
    
    ```
    sudo rpm --import https://updates.talon-sec.com/linux/prisma-access-browser/linux\_signing\_key.pub
    ```
    
-   **Clear cache**
    
    ```
    sudo dnf clean all
    ```
    
-   **Install the Package**
    
    ```
    sudo dnf install prisma-access-browser-stable
    ```
    
-   **Remove the Package**
    
    ```
    sudo dnf remove prisma-access-browser-stable
    ```
    

* * *

* * *