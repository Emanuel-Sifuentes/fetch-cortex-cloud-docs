---
title: "Configure Prisma Browser Mobile Device Posture Attributes"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-devices/prisma-access-browser-mobile-device-posture-attributes"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Devices > Configure Prisma Browser Mobile Device Posture Attributes"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure Prisma Browser Mobile Device Posture Attributes
Define the device posture attributes that determine which mobile devices can join the device group.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

In Prisma Browser, you can add attributes as match criteria when you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc). Because Prisma Browser policy rules are enforced at the device group level, the attributes provide granular security that ensures the devices that Prisma Browser allows to access your apps are adequately maintained and adhere with your security standards before they are allowed access to your network resources. For example, before allowing access to your most sensitive apps, you might want to ensure that the mobile devices accessing your apps are not rooted or jailbroken. In this case, you would create a device group with an attribute that only allows mobile devices that are not rooted or jailbroken. The following sections detail the attributes you can use to determine device group membership for mobile devices. To learn about attributes for managing device group membership on Windows and macOS devices, see [Configure Prisma Browser Device Posture Attributes](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices/prisma-access-browser-device-posture-attributes.html)

## Negative Postures

In some cases, you may want to **exclude** certain device attributes rather than require them. This is called creating a **negative posture**.

For example, you might normally create a rule that **requires** devices to run a specific operating system. However, if a new rule requires that devices **must not** use that operating system, you can use a negative posture instead.

This feature allows you to define rules that **explicitly exclude** certain attributes—such as a particular operating system—from being allowed.

## Root/Jailbreak Status

Enable this attribute to create a device group that only allows mobile devices that have not been rooted or jailbroken.

## Active Screen Lock

Active screen lock mechanisms limit device access to authorized users only, preventing malevolent players from gaining access to confidential information on a mobile device. When you enable the Active screen lock attribute in a device group, Prisma Browser verifies that the device is enabled with an automatic screen lock, password, PIN, biometric, or similar lock feature before allowing access to the group.

## iOS and Android OS Versions

Creating a device group that uses the device's operating system as a posture is a good way to make sure that users have specific versions of the OS. If you add an OS version attribute as match criteria for a device group, Prisma Browser checks the device OS version matches the attribute you defined before allowing membership in the device group.

Define the list of acceptable operating system versions for the Prisma Browser posture mechanism to check as follows.

1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), add the OS versions attribute.
    
2.  Select the iOS or Android versions, minimal minor versions, and minimal security patch level to allow into the device group.
    
3.  Click Save.
    

## Device Type

Enable the Device type attribute to ensure that the device group only contains specific types of devices—such as smartphones or tablets. This can be especially useful when you need to create specialized rules for the different devices.

## Device Manufacturer

Enable the Device manufacturer attribute to restrict device group membership to Android devices from selected manufacturers. This attribute is supported for Android devices only; it does not support iOS devices.

1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), enable the Device manufacturer attribute.
    
2.  Select the Android device manufacturers you want to support in the device group.
    
3.  Click Set.