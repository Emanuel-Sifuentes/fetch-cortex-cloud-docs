---
title: "Configure Branding"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-branding"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Customization Controls > Configure Branding"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure Branding
PAB controls for Browser customization - Branding

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Theme Color

Mobile Browser - **Partial support**

The Prisma Browser allows users to modify the browser theme color. You can choose to let users select their own favorite color if they desire. Choose a specific color from a color palette, or enter colors based on the following color codes:

-   R G B
    
-   H S L
    
-   HEX
    

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Theme Color.
    
3.  Select one of the following options:
    
    -   **Users choose their own** - allows users to select their own color.
        
    -   **Custom color** - allows you to set the color scheme.
        
    
4.  Click Set.
    

## Brand Color

Mobile Browser - **Partial support**

You can select a color that will be applied according to all user-facing browser elements. This includes dialogs, block pages, and other elements.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Brand Color.
    
3.  Select one of the following options:
    
    -   **Default color** – Prisma Browser will use the default color for browser elements.
        
    -   **Custom color** \- You can select a custom color for browser elements.
        
        When selecting an accessible color, You should avoid indicative colors, such as red or green.
        
        For more information on accessible colors, refer to [WebAIM](https://webaim.org/resources/contrastchecker/).
    
4.  Click Set.
    

## Company Logo

Mobile Browser - **Full support**

The Prisma Browser allows you to select your own logo to increase branding awareness. The logo appears on the homepage, in messages sent to the users, and in the Browser Control Pane.

You can add a company logo, or no logo to leave the default Prisma Browser Logo.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Company Logo.
    
3.  Select one of the following options:
    
    -   **No Company Logo** - The default Prisma Browser logo will be displayed.
        
    -   **Set Company Logo**\- Drag the logo image or browse for it.
        
        The logo image must conform to the following requirements.
        
        -   File format - PNG or SVG only
            
        -   Recommended width - 600 px
            
        -   File size - up to 1 MB
            
        -   The logo should be transparent (no background).
            
    
4.  Click Set.
    
5.  The logo will now be displayed on the homepage and all places where the logo is used.
    

## Company Name

Mobile Browser - **Full support**

You can use the Company Name feature to add the organization's name to the top line of the browser.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Company Name.
    
3.  Select one of the following options:
    
    -   **Set name** \- Enter the name that is to be displayed on the top of the homepage. It will appear as The **<company name> browser - Powered by Palo Alto Networks**.
        
    -   **Display no name** - the display will show - **Secure Browser - Powered by Palo Alto Networks**.
        
    
4.  Click Set.
    
5.  The name will now be displayed on the homepage and elsewhere.
    

## Custom Texts

Mobile Browser - **No support**

You can modify the default texts that appear in user-facing dialogs and other pages. This can help describe additional information regarding policies - for example - why a particular policy isn't allowed, and if there is anything that can be done to allow for special permission.

This feature can also be used for localizing the information if required.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Custom Texts.
    
3.  Select one of the following options:
    
    -   **Use default dialog text** - the dialog texts will be the default, preconfigured texts.
        
    -   **Customize and edit dialog texts** \- Select the dialog that you want to edit, and click the pencil icon. In the **Edit Text** window, edit the **Title** and **Description**. If needed, add new line characters to provide some formatting.
        
        There are three tabs for this option:
        
        -   **Dialog texts -** Customize the text in the various dialogs.
        -   **Security texts -**Customize the text in the security dialogs.
        -   **Other -** Customize the link and title in the PABX **About** section.
            
            The **Other** tab is limited to the PABX.
            
        
    -   **Add link** \- Enter the information for the Link name (up to 30 characters), and add the URL.
        
    
4.  Save.
    
5.  Repeat and edit or customize as many additional dialogs as needed.
    
6.  Click Save when all dialogs are modified.
    

## Browser Icon

Mobile Browser - **No support**

This feature is only available on macOS.

Organizations that use the Prisma Browser can use their own internally designed icon if they so desire. If not, you can make sure that only the default Prisma Browser icon is used.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Browser Icon.
    
3.  Select one of the following options:
    
    -   **Use Prisma Browser icon** - The Prisma Browser will use the default icon.
        
    -   **Set browser icon** \- You can select a custom icon.
        
    
4.  Click Set.