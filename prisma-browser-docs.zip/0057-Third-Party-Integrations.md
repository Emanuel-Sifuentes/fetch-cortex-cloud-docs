---
title: "Third-Party Integrations"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/third-party-integrations"
depth: 2
breadcrumbs: "Home > Prisma Browser > Third-Party Integrations"
updated: "Feb 10, 2026"
---

# Third-Party Integrations
A link to all the third-party integration apps.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
|  |  |

Prisma Access Browser works with the following third-party services:

-   [Microsoft 365](/content/techdocs/en_US/prisma-access-browser/integrations/third-party-integrations/integrate-prisma-access-browser-with-microsoft-365.html) This feature will be deprecated in March 2026.
-   [Microsoft Information Protection](/content/techdocs/en_US/prisma-access-browser/integrations/third-party-integrations/integrate-prisma-access-browser-with-microsoft-information-protection.html)
-   [Windows Account-Based SSO Authentication](/content/techdocs/en_US/prisma-access-browser/integrations/third-party-integrations/windows-account-based-sso-authentication.html)
-   [Google Workspace](/content/techdocs/en_US/prisma-access-browser/integrations/third-party-integrations/integrate-prisma-access-browser-with-google-workspace.html)
-   [Votiro](/content/techdocs/en_US/prisma-access-browser/integrations/third-party-integrations/integrate-prisma-access-browser-with-votiro.html)
-   [CrowdStrike Falcon Intelligence](/content/techdocs/en_US/prisma-access-browser/integrations/third-party-integrations/integrate-prisma-access-browser-with-crowdstrike-falcon-intelligence.html)
-   [OPSWAT MetaDefender](/content/techdocs/en_US/prisma-access-browser/integrations/third-party-integrations/integrate-prisma-access-browser-with-opswat-metadefender.html)
-   [Enforce PAB Mobile Access on Managed Devices Using MDM App Configuration](/content/techdocs/en_US/prisma-access-browser/integrations/third-party-integrations/enforcing-prisma-access-browser-mobile-access-on-managed-devices-usiing-mdm-app-configuration.html)