---
title: "Configure Prisma Browser Browser Customization Controls"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Customization Controls"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure Prisma Browser Browser Customization Controls
Configure browser customization controls for Prisma Access Secure Enterprise Browser (Prisma Browser).

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

When you're creating a browser customization rule, you can configure the controls in the following ways:

-   When you're creating a new browser customization rule, you can set the controls in the [Browser Customization page](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-customization-rules.html#task-tsj_k5t_fcc_step-browser-customization).
-   You can [edit an existing rule](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules.html#manage-prisma-access-browser-policy-rules_task-edit-rules).
-   When you [create a policy profile](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles.html#manage-prisma-access-browser-policy-profiles_task-jfp_rny_fcc), you can configure browser security to control user security settings in the Prisma Browser.
-   You can select it from Strata Cloud Manager ConfigurationPrisma BrowserPolicyControlsBrowser Customization.

For information on a control, select the group where it is contained:

-   [Browser Customization - Branding](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-branding.html)
-   [Browser Customization – Autonomous Digital Experience Management (ADEM)](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-autonomous-digital-experience-management-adem.html)
-   [Browser Customization - Customization](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-customization.html)
-   [Browser Customization - Routing](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-routing.html)
-   [Browser Customization – New Tab and Home Page](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-new-tab-and-home-page.html)
-   [Browser Customization - Upgrade Management](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-upgrade-management.html)