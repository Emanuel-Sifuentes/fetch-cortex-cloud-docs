---
title: "Troubleshoot the Prisma Browser"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/troubleshoot-the-prisma-access-browser"
depth: 2
breadcrumbs: "Home > Prisma Browser > Troubleshoot the Prisma Browser"
updated: "Feb 10, 2026"
---

# Troubleshoot the Prisma Browser
Troubleshoot a problematic browser installation/update

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Occasionally, some errors and issues occur when using the Prisma Browser. This article will provide you with some common solutions to issues that may arise.

## Installation Failures

If the Prisma Browser does not install, follow these steps to troubleshoot the issue:

**Latest Installer Version**

-   Make sure that you are using the latest version of the Prisma Browser Installer:
    -   Visit [the Prisma Access Browser Official Download page](https://get.pabrowser.com).
    -   Compare the version number of the installer that you have with the installer on the download page.
    -   If the version on the download page is newer, download that installer and use it for installation.

**Disk Space**

-   Make sure that there is sufficient disk space on the device:
    -   **Windows devices:** Open File Explorer, right-click on the drive where you want to install Prisma Browser and select "Properties." Check the "Free space" section.
    -   **macOS:** Click the Apple menu, select "About This Mac," and then click on the "Storage" tab.
-   Ensure that there is sufficient space for the Prisma Browser installation requirements.
-   If necessary, free up enough space by deleting unneeded files or moving them to an external memory.

**Network Accessibility**

-   Make sure that the following URLs can be reached:
    -   updates.talon-sec.com
    -   bfe078e7921507bb.talon-sec.com
    -   Check your firewall settings to make sure that these URLs are not blocked.
-   Go to prisma/troubleshoot, open Diagnostics, and ensure that the Update service is up and running.

**User Privileges**

-   Make sure that the active user has the correct privileges to install software.
    -   If you are not sure that the installation privileges are available, try installing a different software package (for example Firefox, Brave, Chrome).

**Root Certificates (Windows only)**

Verify that the system has all required root certificates installed, mainly DigiCert and GlobalSign:

-   Open an Admin Powershell.
-   Run the following command:
    
    ```
    Get-ChildItem -Path Cert:\\LocalMachine\\Root | Where-Object {$.Subject -like "\*DigiCert Trusted Root G4\*" -or $.Subject -like "\*DigiCert Trusted G4 Code Signing\*" -or $\_.Subject -like "\*GlobalSign Root R6\*"} | Format-Table Subject, Thumbprint -AutoSize
    ```
    
-   Verify the outputs of the two certificates.
-   If either certificate is missing, download and install them from the official DigiCert and GlobalSign websites:
    -   [DigiCert Root Certificates](https://www.digicert.com/kb/digicert-root-certificates.htm)
    -   [GlobalSign Root Certificates](https://support.globalsign.com/ca-certificates/root-certificates/globalsign-root-certificates)
-   Follow the instructions on the sites to install the certificates on your system.
    
    **If there are still issues, perform the following checks:**
    
    -   **Residual Installation Files:** Check for residues of previous or failed installations and delete them:
        -   Terminate any running PrismaAccessBrowser processes:
            -   Press CTRL+SHIFT+ESC to open the Task Manager.
            -   Look for any processes named PrismaAccessBrowser\*.
            -   Right-click on the process and select **End Task**.
        -   Remove the following directories from the File Explorer:
            -   %LOCALAPPDATA%\\Palo Alto Networks\\
            -   %PROGRAMFILES(x86)%\\Palo Alto Networks
            -   %PROGRAMFILES%\\Palo Alto Networks
        -   If these directories exist, delete them.
        -   Empty the Recycle Bin to ensure all residual files are completely removed.
    

**Active Security Products**

-   Check the security product's logs for any entries related to Prisma Browser or its components.
-   If any entries indicate that the installation is being blocked, follow these steps:
    -   Open the security product's control panel.
    -   Navigate to the settings or exceptions/whitelist section.
    -   Add the following executables and directories to the whitelist:
        
    -   %LOCALAPPDATA%\\Palo Alto Networks\\
    -   %PROGRAMFILES(x86)%\\Palo Alto Networks
    -   %PROGRAMFILES%\\Palo Alto Networks
    -   Temporarily disable the security product and attempt the installation again to see if the issue is resolved.
    -   If the installation succeeds with the security product disabled, re-enable the security and ensure the necessary whitelisting is in place to prevent future issues.

**Active Group Policies**

-   Open the Group Policy Management Console"
    -   Press Win + R, type gpedit.msc, and click **Enter**.
-   Navigate to the following path to check for software restriction policies:
    -   Computer Configuration\\Administrative Templates\\System
    -   User Configuration\\Administrative Templates\\System
-   Look for any policies related to software restrictions or installation restrictions.
-   If you find any relevant policies, you should:
    -   Review the policies and understand their purpose.
    -   Once the installation is successful, make sure that any necessary exceptions are properly documented and maintained.

## Update Issues

If Prisma Browser does not update, follow these steps to troubleshoot the issue:

**Current Version**

-   Open the Prisma Browser and navigate to prisma://settings/help.
-   Check the displayed version number and compare it to the latest version number on the download page.
-   If the numbers are the same, no update is needed.

**Network Accessibility**

-   Open a web browser and try to navigate to these URLs:
    -   updates.talon-sec.com
    -   bfe078e7921507bb.talon-sec.com
    -   Go to prisma://troubleshoot, open Diagnostics, and make sure that the Update service is up and running.
-   If the URLs cannot be reached:
    -   Check your internet connection to make sure that it s stable.
    -   Check your firewall to make sure that these URLs are bot blocked. If you are in a corporate environment, make sure that the URLs are whitelisted.

**Omaha Client (Windows Only)**

-   If the “About” page shows: "An error occurred while checking for updates: Update check failed to start (error code 3: 0x80040154)":
    -   Open the Task Scheduler.
        -   Run the command _taskschd.msc_ and check for the following taskd:
            -   PANWUpdateTaskMachineCore
            -   PANWUpdateTaskMachineUA
        -   If these tasks are not present, the Omaha client may not be installed correctly.
        -   Check the following directories to see if the Omaha client exists:
            -   %PROGRAMFILES(x86)%\\Palo Alto Networks\\Update
            -   %LOCALAPPDATA%\\Palo Alto Networks\\Update
        -   If the tasks or files are missing, reinstall the Omaha client.

**Root Certificate (Windows Only)**

-   Verify that the system has all required root certificates installed:
    -   Open the Microsoft Management Console:
        -   Run the command _mmc_.
        -   In MMC, go to "File" > "Add/Remove Snap-in."
        -   Select "Certificates" and click "Add."
        -   Choose "Computer account" and click "Next," then "Finish."
    -   In the MMC console, expand "Certificates" under "Trusted Root Certificate Authorities."
    -   Check for the following certificates:
        -   DigiCert Trusted Root G4 (requires 05:9b)
        -   DigiCert Trusted G4 Code Signing (requires 08)
        -   GlobalSign Root R6 (starts with 45)
    -   If either certificate is missing, download and install them from the official DigiCert and GlobalSign websites:
        -   [DigiCert Root Certificates](https://www.digicert.com/kb/digicert-root-certificates.htm)
        -   [GlobalSign Root Certificates](https://support.globalsign.com/ca-certificates/root-certificates/globalsign-root-certificates)
    -   Follow the instructions on the websites to install the certificates on your system.

**New Version Directory**

-   Open the File Explorer and navigate to the Prisma Browser Installation directory:
    -   %PROGRAMFILES(x86)%\\Palo Alto Networks
    -   %LOCALAPPDATA%\\Palo Alto Networks
-   Look for a directory corresponding to the new version number.
-   Make sure that the executables in the new version directory are properly signed.
    -   Right-click on an executable.
    -   Select Properties, then go to the Digital Signatures tab.
    -   Ensure that the signatures are valid.
-   -   If files are unsigned, check for possible issues such as download corruption, disk errors, or security product interference.
        

**Active Security Product**

-   Check the security product's logs for any entries related to Prisma Browser or its components.
-   If any entries indicate that the update is being blocked, follow these steps:
    -   Open the security product's control panel.
    -   Navigate to the settings or exceptions/whitelist section.
    -   Add the following executables and directories to the whitelist:
        -   -   Executables related to Prisma Browser.
            -   Directories
                -   %LOCALAPPDATA%\\Palo Alto Networks\\
                -   %PROGRAMFILES(x86)%\\Palo Alto Networks
                -   %PROGRAMFILES%\\Palo Alto Networks
-   Temporarily disable the security product and attempt the update again to see if the issue is resolved.
-   If the update succeeds with the security product disabled, re-enable it and ensure the necessary whitelisting is in place to prevent future issues.

**Network Connection**

-   Test your network speed using an online speed test tool (e.g., speedtest.net).
-   If the network speed is significantly lower than expected:
    -   Restart your routers or modem.
    -   Check to make sure that other devices on the network are not consuming excessive bandwidth,
    -   If the issues persist, contact your Internet Service Provider.

## Browsing Issues

if there are issues when browsing using the Prisma Browser, follow thee steps to troubleshoot the issue:

-   **All Websites**
    -   **Site Functionality in Other Browsers**
        -   Open a different browser (Chrome / Edge).
        -   Navigate tot he websites that are experiencing issues in Prisma Browser.
        -   See if the sites load and function correctly.
        -   If they do not function correctly, the issue is likely a problem with the websites themselves or a broader network problem.

**Firewall and Whitelisting**

-   Open the firewall settings on your device:
    -   **Windows:** Control Panel > System and Security > Windows Defender Firewall
    -   **macOS:** System Preferences > Security & Privacy > Firewall
-   Check the list of allowed applications and processes.
-   Ensure that Executables related to the Prisma Browser, as well as the following directories are allowed through the firewall:
    -   %LOCALAPPDATA%\\Palo Alto Networks\\
    -   %PROGRAMFILES(x86)%\\Palo Alto Networks
    -   %PROGRAMFILES%\\Palo Alto Networks
-   If necessary, manually add Prisma Browser to the firewall's list of allowed applications.
-   Examine firewall logs to find relevant clues for a block and possibly whitelist Prisma Browser executables and directories.

**Problematic Extensions**

-   Open Prisma Browser and navigate to the extensions page: prisma://extensions/
-   Disable all extensions.
-   Try accessing the problematic websites again. If the sites work, enable the extensions one at a time to identify the problematic one.

## Specific Websites

**Site Functionality in Other Browsers**

-   Open a different browser (Chrome / Edge).
-   Navigate tot he websites that are experiencing issues in Prisma Browser.
-   See if the sites load and function correctly.
-   If they do not function correctly, the issue is likely a problem with the websites themselves or a broader network problem.

**Filewall and Whitelisting**

-   Open the firewall settings on your device:
    -   **Windows:** Control Panel > System and Security > Windows Defender Firewall
    -   **macOS:** System Preferences > Security & Privacy > Firewall
-   Check the list of allowed applications and processes.
-   Ensure that Executables related to the Prisma Browser, as well as the following directories are allowed through the firewall:
    -   %LOCALAPPDATA%\\Palo Alto Networks\\
    -   %PROGRAMFILES(x86)%\\Palo Alto Networks
    -   %PROGRAMFILES%\\Palo Alto Networks
-   If necessary, manually add Prisma Browser to the firewall's list of allowed applications.
-   Examine firewall logs to find relevant clues for a block and possibly whitelist Prisma Browser executables and directories.

**Cross-Site Cookies**

-   Open the developer tools in Prisma Browser (press Ctrl+Shift+I or F12).
-   Navigate to the "Application" tab.
-   Expand the "Cookies" section and check for any cross-site cookies used by the website.
-   Ensure that Prisma Browser is configured to allow cross-site cookies:
    -   Go to prisma://settings/cookies and ensure that "Block third-party cookies" is disabled.
-   If cross-site cookies are required, add the specific sites to the list of allowed cookies.

**Site-Specific Configuration**

-   Open the developer tools in Prisma Browser (press Ctrl+Shift+I or F12).
-   Navigate to the "Network" tab.
-   Reload the website and observe the network requests.
-   Look for any blocked resources and note their URLs.
-   Ensure that the website's configuration does not blacklist any necessary resources:
    -   Go to prisma://settings/security and check for any site-specific configurations.
    -   Add any necessary resources to the whitelist.

**Problematic Extensions**

-   Open Prisma Browser and navigate to the extensions page: prisma://extensions/
-   Disable all extensions.
-   Try accessing the problematic websites again. If the sites work, enable the extensions one at a time to identify the problematic one.

**IE Mode**

-   Open Prisma Browser and navigate to the problematic site.
-   Check if the site is being accessed in IE mode.
-   If it only works in IE but not in Prisma Browser IE mode, a feature may be missing.

## Extension Issues

If there are issues with the browser extensions in the Prisma Browser, follow these steps to troubleshoot the issue:

**Extension Functionality in Other Browsers**

-   Install the extension in Chrome and Edge browsers.
-   Verify that the extension functionality is consistent across both browsers.
-   Note any specific differenced or issues encountered.

**NaCl Dependency**

-   Open the Development Console (usually accessed by right-clicking the web page and selecting _Inspect_ or by pressing CTRL+Shift+I).
-   Look for any errors or warnings related to NaCl.
-   In Chrome, some extensions may explicitly mention NaCl errors or dependencies in the console output.

**Desktop-Installed Services**

-   Review the extension's documentation or support resources.
-   Check if the extension requires any desktop-installed services or applications to function correctly.
-   Test the extension's functionality both with and without any associated desktop services installed.

## PWA Issues

If there are issues with Progressive Web Apps (PWAs) in Prisma Browser, follow these steps to troubleshoot the issue.

**Browser Version**

-   Ensure the user is running the latest version of Prisma Browser.
-   Guide the user to update Prisma Browser to the latest available version if necessary.
-   Verify if the issue persists after updating.

**PWA Installation in Other Browsers**

-   Attempt to install the PWA in both Chrome and Edge browsers.
-   Make sure that the installation process completes successfully without any errors.
-   Compare the installation behavior with Prisma Browser to identify any discrepancies.

**Multiple Profiles**

-   Inform users about the Chromium limitation affecting PWAs when there are multiple profiles in use.
-   Explain that only one profile can utilize PWAs due to how Chromium handles app installations and storage.
-   Advise your users to check if multiple profiles are active and recommend using PWAs in the profile where it is most needed.

By following these steps, you should be able to identify and resolve the most common issues related to installation, updating, browsing, extensions, and PRWs in the Prisma Browser.

If the errors still persist, please contact Support for further assistance.

## Authentication Issues

In some cases, the browser was not authenticating because the device ID was missing.

Chek to see that the authenticator app must be installed on the same device (iPad) ad the Prisma Browser. If they are on the same device, the apps can communicate and pass the Entra ID that is needed for authentication.