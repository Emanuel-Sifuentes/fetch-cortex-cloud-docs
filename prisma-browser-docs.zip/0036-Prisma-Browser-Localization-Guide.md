---
title: "Prisma Browser Localization Guide"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/prisma-access-browser-localization-guide"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Browser Localization Guide"
updated: "Feb 10, 2026"
---

# Prisma Browser Localization Guide
This document provides you with the information on switching languages where available.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

This guide ensures you can configure the Prisma Browser to the language of your choice based on the available localization support.

1.  Localization Support
    
    The Prisma Browser supports two levels of localization.
    
    1.  **Full Localization Support** -
        
        The following components are translated for languages that have full support:
        
        1.  **Chromium Elements** - This includes the following elements:
            -   Browser menus
            -   Settings
            -   Other base components
        2.  **Prisma Browser\-specific Elements** - This includes the following elements:
            -   Prompts
            -   Dialog
            -   Policy indicators
            -   Other browser-specific components
        
    2.  **Partial Localization Support** - The translations are mostly automated, with limited human intervention. The following components are translated:
        
        1.  Many browser elements will be in the selected language.
        2.  Components specific to Prisma Browser will default to English (US).
        
        RTL languages are not supported.
        
    
2.  **Fully Supported Languages** - The following languages are fully supported:
    
    Prisma Browser Supported Languages
    | Language | Code |
    | --- | --- |
    | Chinese (simplified) | CN\_zh |
    | Chinese (traditional) | CN\_tw |
    | Danish | DA\_dK |
    | Dutch | NL\_nl |
    | French | FR\_fr |
    | German | DE\_de |
    | Italian | IT\_it |
    | Japanese | JA\_Jp |
    | Korean | KO\_kr |
    | Norwegian | NO\_nb |
    | Polish | PL\_pl |
    | Portuguese | PT\_pt |
    | Portuguese (Brazil) | PT\_br |
    | Russian | RU\_ru |
    | Spanish (Spain) | ES\_es |
    | Spanish (Latin America) | ES\_419 |
    | Swedish | SV\_se |
    | Ukrainian | UK\_ua |
    | Vietnamese | VI\_vn |
    
3.  **Default Behavior**
    
    **If the device language is fully supported**: The browser will default to this language.
    
    **If the device language isn't fully supported**: The browser will default to English (US).
    
4.  **Changing the Browser Language**
    
    For **Windows**
    
    1.  Open the Prisma Browser.
        
    2.  Navigate to prisma://settings/languages.
        
    3.  Under the **Browsers** section, click **Select Language**.
        
    4.  Choose your desired language.
        
    5.  Click **Relaunch the Browser**.
        
        Language changes will take effect after browser relaunch.
        
    
    For **macOS**
    
    1.  Open the Prisma Browser.
        
    2.  Navigate to prisma://settings/languages.
        
    3.  Review the list of supported languages.
        
        -   To enable partially supported languages:
            -   Toggle **Allow the browser to be displayed in languages that are not fully supported**.
            -   If the device is already set in the desired language, relaunch the browser. Language changes will take place after the relaunch.
        -   To switch to a fully supported language:
            -   Open your Mac device's **System Settings**.
                -   Navigate to System Settings > General > Language and Region.
                -   Alternatively, you can click **Open your computer's Language Settings** from the browser.
            -   Scroll to the **Applications** section.
            -   Click **+** to add the browser and set your preferred language.
            -   Relaunch the browser to apply the changes.
        
        Language changes will take effect after browser relaunch.