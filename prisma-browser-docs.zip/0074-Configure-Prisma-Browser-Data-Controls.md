---
title: "Configure Prisma Browser Data Controls"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Data Controls"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure Prisma Browser Data Controls
Configure data controls for Prisma Access Secure Enterprise Browser (Prisma Browser).

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

You can configure the controls in the following ways:

-   When you're creating a new browser security rule, you can set the controls in the [When Contains (Content Settings) page](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules.html#task-create-access-rule_step-content-settings).
-   You can [edit an existing rule](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules.html#manage-prisma-access-browser-policy-rules_task-edit-rules).
-   If you're using an [external control (profile)](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules.html#manage-prisma-access-browser-access-and-data-control-rules_task-scd_w5t_fcc), you can select it from Strata Cloud Manager ConfigurationPrisma Access BrowserPolicyControlsData Control.

For information on a control, select the group where it is contained:

-   [Data Controls – Data Leak Prevention](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/configure-data-leak-prevention.html)
-   [Data Controls – Malware Protection](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/configure-malware-protection.html)