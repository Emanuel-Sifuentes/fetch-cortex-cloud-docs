---
title: "Prisma Browser Administration"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration"
depth: 1
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration"
updated: "Mar 12, 2026"
---

# Prisma Browser Administration
Updated on

Mar 12, 2026

Focus

1.  [Home](/)
2.  [Prisma Browser](/content/techdocs/en_US/prisma-access-browser.html)
3.  [Prisma Access Browser Administration](/content/techdocs/en_US/prisma-access-browser/administration.html)

[![PDF Cover Image](/content/dam/techdocs/en_US/pdf/prisma-access-browser/prisma-access-browser-administration.pdf/jcr:content/renditions/cq5dam.thumbnail.319.319.png)](/content/dam/techdocs/en_US/pdf/prisma-access-browser/prisma-access-browser-administration.pdf "Open PDF")

[Download PDF

](/content/dam/techdocs/en_US/pdf/prisma-access-browser/prisma-access-browser-administration.pdf)

* * *

Table of Contents

![Filter icon](/content/dam/techdocs/en_US/images/icons/css/filter.svg)

Filter

Expand all | Collapse all

-   [Use the Prisma Browser Dashboards](/content/techdocs/en_US/prisma-access-browser/administration/use-the-prisma-access-browser-dashboards.html)
-   [Digest Prisma Browser Home Screen Highlights](/content/techdocs/en_US/prisma-access-browser/administration/monitor-prisma-access-browser-statistics.html)
-   [Device Health](/content/techdocs/en_US/prisma-access-browser/administration/device-health.html)
-   [Explore Prisma Browser Events](/content/techdocs/en_US/prisma-access-browser/administration/investigate-prisma-access-browser-events.html)
    
    -   [Prisma Browser Investigations](/content/techdocs/en_US/prisma-access-browser/administration/investigate-prisma-access-browser-events/prisma-access-browser-forensics.html)
-   [Account Protection for the Prisma Browser](/content/techdocs/en_US/prisma-access-browser/administration/account-protection-for-the-prisma-access-browser.html)
-   [Manage Prisma Browser Users](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-users.html)
-   [Manage Configuration Versions (Draft Mode)](/content/techdocs/en_US/prisma-access-browser/administration/manage-configuration-versions-draft-mode.html)
-   [Manage Prisma Browser Devices](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html)
    
    -   [Manage Prisma Browser Device Groups](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices/manage-prisma-access-browser-device-groups.html)
    -   [Configure Prisma Browser Device Posture Attributes](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices/prisma-access-browser-device-posture-attributes.html)
    -   [Configure Prisma Browser Extension Posture Attributes](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices/prisma-access-browser-extension-device-posture-attributes.html)
    -   [Configure Prisma Browser Mobile Device Posture Attributes](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices/prisma-access-browser-mobile-device-posture-attributes.html)
    -   [Live Session Streaming](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices/co-browsing.html)
-   [Manage Prisma Browser Applications](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-applications.html)
    
    -   [Configure Native RDP/SSH](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-applications/configuring-native-rdp-ssh.html)
-   [Manage Prisma Browser Extensions](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-extensions.html)
-   [Manage Prisma Browser Policy Rules](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules.html)
    
    -   [Manage Prisma Browser Access and Data Control Rules](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules.html)
        
        -   [Login Controls](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules/login-controls.html)
            
            -   [Login Forms](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules/login-controls/login-form.html)
            -   [Passkey Login](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules/login-controls/passkey-login.html)
    -   [Manage Prisma Browser Security Rules](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-security-rules.html)
    -   [Manage Prisma Browser Customization Rules](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-customization-rules.html)
-   [Manage Prisma Browser Policy Profiles](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles.html)
    
    -   [Configure Prisma Browser Data Controls](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls.html)
        
        -   [Configure Data Leak Prevention](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/configure-data-leak-prevention.html)
        -   [Configure Malware Protection](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/configure-malware-protection.html)
        -   [Live Page Scanning](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/live-page-scanning.html)
        -   [Webpage Element Removal](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/webpage-element-removal.html)
    -   [Configure Prisma Browser Browser Security Controls](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security.html)
        
        -   [Configure Browser Session](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-browser-session.html)
        -   [Configure Browser Hardening](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-browser-hardening.html)
        -   [Configure Network Protection](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-network-protection.html)
        -   [Configure Saved Data](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-saved-data.html)
        -   [Configure Extensions](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-extensions.html)
        -   [Configure Internet Explorer Compatibility Mode](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-internet-explorer-compatibility-mode.html)
        -   [Configure Printers](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-printers.html)
        -   [Configure Privacy](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-privacy.html)
        -   [Configure Protected Browsing](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-protected-browsing.html)
    -   [Configure Prisma Browser Browser Customization Controls](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization.html)
        
        -   [Configure Branding](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-branding.html)
        -   [Configure Autonomous Digital Experience Management (ADEM)](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-autonomous-digital-experience-management-adem.html)
        -   [Configure Customization](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-customization.html)
        -   [Configure Routing](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-routing.html)
        -   [Configure New Tab and Home Page](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-new-tab-and-home-page.html)
        -   [Configure Upgrade Management](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-upgrade-management.html)
-   [Manage Prisma Browser Sign-in Rules](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-sign-in-rules.html)
-   [Manage Prisma Browser Requests to Bypass Policy Rules](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-requests.html)
-   [Manage Rollback Control for the Prisma Browser](/content/techdocs/en_US/prisma-access-browser/administration/rollback-control-for-the-prisma-access-browser.html)
-   [Prisma Browser Remote Connections](/content/techdocs/en_US/prisma-access-browser/administration/prisma-access-browser-remote-connections.html)
-   [Prisma Browser Self-Protection for Windows](/content/techdocs/en_US/prisma-access-browser/administration/prisma-browser-self-protection-fpr-windows.html)
-   [The Prisma Browser Enterprise Password Manager](/content/techdocs/en_US/prisma-access-browser/administration/the-prisma-access-browser-enterprise-password-manager.html)
-   [Location-based Policy](/content/techdocs/en_US/prisma-access-browser/administration/location-based-policy.html)
-   [The Prisma Browser Extension](/content/techdocs/en_US/prisma-access-browser/administration/the-prisma-access-browser-extension.html)
    
    -   [Prisma Browser Extension History Collection](/content/techdocs/en_US/prisma-access-browser/administration/the-prisma-access-browser-extension/prisma-access-browser-extension-history-collection.html)
    -   [Prisma Browser Extension Bulk Extension ID Import](/content/techdocs/en_US/prisma-access-browser/administration/the-prisma-access-browser-extension/prisma-browser-extension-bulk-extension-id-import.html)
-   [File Types per Category](/content/techdocs/en_US/prisma-access-browser/administration/file-types-per-category.html)