---
title: "CA Region"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-ca"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Browser Prerequisites > CA Region"
updated: "Tue Feb 10 06:48:12 PST 2026"
---

# CA Region
The following domains are for clients in the CA region.

The following domains are for clients in the CA region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   ca.api.wildfire.paloaltonetworks.com
-   ca.wildfire.paloaltonetworks.com
-   cie-api-proxy.ca.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.ca.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.ca.talon-sec.com
-   users-assets.ca.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com