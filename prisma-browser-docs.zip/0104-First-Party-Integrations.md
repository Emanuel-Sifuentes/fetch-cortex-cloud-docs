---
title: "First-Party Integrations"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/first-party-integrations/first-party-integrations"
depth: 3
breadcrumbs: "Home > Prisma Browser > First-Party Integrations > First-Party Integrations"
updated: "Tue Feb 10 06:48:41 PST 2026"
---

# First-Party Integrations
A link to the first-party integrations

| Where Can I Use This? | What Do I Need? |
| --- | --- |
|  |  |

Prisma Access Browser works with the following Prisma Access services:

-   [File Handling and Analysis in Advanced WildFire](/content/techdocs/en_US/prisma-access-browser/integrations/first-party-integrations/file-handling-and-analysis-in-advanced-wildfire.html)
-   [IP Based Enforcement Using an Authentication Gateway](/content/techdocs/en_US/prisma-access-browser/integrations/first-party-integrations/ip-based-enforcement-using-an-authentication-gateway.html)