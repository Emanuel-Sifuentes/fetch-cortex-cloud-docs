---
title: "Integrate Prisma Browser and Okta with the Device Posture Provider"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/integrate-prisma-browser-aand-okta-with-the-device-posture-provider"
depth: 2
breadcrumbs: "Home > Prisma Browser > Integrate Prisma Browser and Okta with the Device Posture Provider"
updated: "Feb 10, 2026"
---

# Integrate Prisma Browser and Okta with the Device Posture Provider
Describes the integration between PB/Okta and DPP

By integrating Okta with Prisma Browser, you can use [device posture data](https://help.okta.com/oie/en-us/content/topics/identity-engine/devices/device-assurance-device-posture-idp.htm) from Prisma Browser to configure detailed device assurance and app sign-in policies. This integration helps you enforce stronger security requirements and ensure that only compliant devices can access Okta-protected resources.

The Device Posture Provider feature uses a SAML-based integration for secure communication. Okta sends a SAML request to PAB, and PAB responds with a SAML assertion containing device posture attributes. These attributes allow you to create granular sign-in policies based on your organization’s security standards.

**Prerequisites:**

You need to enable the following features from the Okta Admin Console:

-   Device Posture Claims Mapping
-   Device Posture Provider

For more information refer to [Enable self-service features](https://help.okta.com/oie/en-us/content/topics/security/manage-ea-and-beta-features.htm).

## Configure the Device Posture IdP in Okta

**Open the Prisma Browser Onboarding screen**

From the Strata Cloud Manager, select Configuration Onboarding

1.  Navigate to the **Enforce SSO Applications** step.
2.  Copy the Issuer URI and Single Sign-On URL.
3.  Download the Prisma Browser certificate.
    

In the Okta Admin Console, go to SecurityIdentity Providers.

1.  Click **Add Identity Provider**.
2.  Select **SAML 2.0**
3.  Configure the Prisma Browser as an IdP. For more information, refer to [Add a SAML Identity Provider](https://help.okta.com/oie/en-us/content/topics/security/idp-add-saml.htm).
    
    -   IdP Usage: Select Device Posture Provider.
    -   IdP Issuer URI: Paste the Issuer URI from the Prisma Browser.
    -   IdP Single Sign-On URL: Enter the sign-on URL from Prisma Browser.
    -   IdP Signature Certificate: Upload the certificate from Prisma Browser.
    -   Destination: Paste the Single Sign-On URL path that you copied from Prisma Browser.
    -   Click **Save**.
    -   From the Summary screen, download the SAML Metadata.
        
4.  Return to the Prisma Browser Onboarding screen and upload the SAML Metadata file.
    
5.  Enable the Integration

## Enable the Device Posture IdP as Provider for Device Assurance

You can create or modify the device assurance policies to incorporate additional signals from your IdP due to its integration with the Device Posture Provider. See [Add a device assurance policy](https://help.okta.com/oie/en-us/content/topics/identity-engine/devices/device-assurance-add.htm).

1.  In the Okta Admin Console, go to SecurityDevice integration.
2.  On the **Endpoint Security tab**, click **Add endpoint integration**.
3.  Select **Device posture provider**.
4.  Select the Platform.
5.  Save the configuration.
    

## Configure a Device Assurance Policy

1.  Go to SecurityDevice Assurance Policy.
2.  Click **Add Policy**.
3.  Click **Create Policy**.
4.  Define a Policy Name.
5.  Select the Platform.
6.  In the Device attribute provider(s) section, select: **Device Posture Provider**.
7.  In **Device management**, select **Device must be managed**. **see note below**
8.  Click **Save**.
    

Device must be Managed - Okta defines **Managed** as follows: The device is under the organization's IT or security team's control and oversight, as indicated by installed management agents or software.

## Integrate the Policy into an App Sign-in Policy

After you create a device assurance policy, integrate it into an app sign-in policy to ensure enforcement before users access protected resources. For detailed steps, see **[Add device assurance to an app sign-in policy](https://help.okta.com/oie/en-us/content/topics/identity-engine/devices/device-assurance-policy-rule.htm)**.

If the global session policy requires a password, the **Okta Sign-In Widget** prompts users to enter their username and password before redirecting them to the device posture Identity Provider (IdP).

To verify compliance first, configure the app sign-in policy rule that requires device posture claims with the highest priority. You can also apply conditions such as **Group**, **Platform**, or **Network Zone** to target specific users.

### Configure an Authentication Policy to use Device Posture IdP Signals

1.  Go to SecurityAuthentication Policies sectionApp sign-in
2.  Click **Add Rule**
3.  Define a Policy Name.
4.  In the **Device Assurance policy is**, select **Any of the following device assurance policies**.
5.  Select the Device Assurance policy you created in the previous step.
6.  Click ∫**Save**.

## Modify the Catch-All Rule, and Set it to Deny All

1.  Go to SecurityAuthentication Policies sectionApp sign-in
2.  Find the Catch-All rule.
3.  Click ActionsEdit.
4.  At the bottom, set the rule to **Deny All**.