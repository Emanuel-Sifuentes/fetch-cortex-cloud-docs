---
title: "Configure Internet Explorer Compatibility Mode"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-internet-explorer-compatibility-mode"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Security Controls > Configure Internet Explorer Compatibility Mode"
updated: "Mar 12, 2026"
---

# Configure Internet Explorer Compatibility Mode
PAB Internet Explorer Compatibility

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Internet Explorer Compatibility Mode

Mobile Browser - **No support**

Internet Explorer Compatibility Mode does not support Private Apps.

Microsoft has announced end-of-support dates for different versions of IE. For more information, refer to [Microsoft's Lifecycle FAQ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge).

Organizations may require compatibility with Internet Explorer, as they are running internal legacy websites.

You can select these particular sites and allow users to access them in the Prisma Browser using Internet Explorer Compatibility Mode. This will render the application or site as if it were being accessed via Internet Explorer.

The Prisma Browser Internet Explorer ~Compatibility Mode is compatible with the Internet Explorer browser version 11.

Click [here](https://chromeenterprise.google/policies/url-patterns/) for more information regarding entering URLs.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyProfilesBrowser Security
    
2.  Select Internet Explorer Compatibility Mode.
    
3.  Select one of the following options:
    
    -   **Enable compatibility mode** \- You need to add the target URLs that need Internet Explorer Compatibility.
        
    -   **No compatibility mode support** - Users will not be able to use sites that require IE Compatibility.
        
    
4.  Click Set.