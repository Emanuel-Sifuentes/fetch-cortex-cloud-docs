---
title: "Configure Prisma Browser Extension Posture Attributes"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-devices/prisma-access-browser-extension-device-posture-attributes"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Devices > Configure Prisma Browser Extension Posture Attributes"
updated: "Mar 12, 2026"
---

# Configure Prisma Browser Extension Posture Attributes
Define the device posture attributes that determine which Devices can join the device group.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

In Prisma Browser Extension, you can add attributes as match criteria when you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc). Because Prisma Browser policy rules are enforced at the device group level, the attributes provide granular security that ensures the devices that Prisma Browser Extension allows to access your apps are adequately maintained and adhere with your security standards before they are allowed access to your network resources. For example, before allowing access to your most sensitive apps, you might want to ensure that the devices using the Prisma Browser Extension accessing your apps are using only the Opera browser. In this case, you would create a device group with an attribute that only allows devices using the extension that are only using the Opera browser. The following sections detail the attributes you can use to determine device group membership for devices using the Prisma Browser Extension.

To learn about attributes for managing device group membership on Windows and macOS devices, see [Configure Prisma Browser Device Posture Attributes](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices/prisma-access-browser-device-posture-attributes.html)

## Negative Postures

In some cases, you may want to **exclude** certain device attributes rather than require them. This is called creating a **negative posture**.

For example, you might normally create a rule that **requires** devices to run a specific operating system. However, if a new rule requires that devices **must not** use that operating system, you can use a negative posture instead.

This feature allows you to define rules that **explicitly exclude** certain attributes—such as a particular operating system—from being allowed.

## Windows and macOS OS Versions

Creating a device group that uses the device's operating system as a posture is a good way to make sure that users have specific versions of the OS. If you add an OS version attribute as match criteria for a device group, Prisma Browser checks the device OS version matches the attribute you defined before allowing membership in the device group.

Define the list of acceptable operating system versions for the Prisma Browser posture mechanism to check as follows.

1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), add the OS version attribute.
    
2.  Select the Windows or macOS versions, editions, and build numbers to allow into the device group.
    
    Selecting **All...versions** will use all historical versions of the operating systems, including those that re deprecated it yes.
    
    Selecting **All...versions** will use all historical versions of the operating systems, including those that re deprecated it yes.
    
3.  Click **Save**.
    

## Browser Brands

Enable the Browser Brands attribute to ensure that the device group only contains specific types of browsers—such as Chrome, Edge, or Brave. This can be especially useful when you need to create specialized rules for different browsers.

1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), enable the Browser Brands attribute.
    
2.  Select the browser brands you want to support in the device group.
    
3.  If you need to restrict the browsers to specific versions, click the pencil icon, and in the Specific brand version, enter the Minimum version of the browser that is acceptable.
    
4.  Click Set.