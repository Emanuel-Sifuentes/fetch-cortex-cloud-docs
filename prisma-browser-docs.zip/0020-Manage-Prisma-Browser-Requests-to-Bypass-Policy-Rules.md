---
title: "Manage Prisma Browser Requests to Bypass Policy Rules"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-requests"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Requests to Bypass Policy Rules"
updated: "Mar 12, 2026"
---

# Manage Prisma Browser Requests to Bypass Policy Rules
Learn how to manage end user requests to bypass Prisma Browser rules for access to otherwise blocked sites and apps.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

In some cases, end users may find that the Prisma Browser rules are too strict to allow users to access the resources they need. For example, a user might need to download a file that is restricted based on a browser rule, or may need access to a website that is normally off limits.

To address this issue, Prisma Browser allows you to set up temporarily bypass rules conditions. For each supported control, you can configure a policy that allows your users to bypass the rule.

There are three ways to allow users to bypass the rules:

-   **Warn and allow to proceed anyway**—Notifies users that the web application they are trying to access is restricted, but allow them to proceed anyway.
-   **Warn and allow the user to proceed anyway with a reason**—Notifies users that the web application they are trying to access is restricted, but allows them to proceed after supplying a reason they need access.
-   **Permission request**—Notify users that the web application they are trying to access is restricted, and prompt them to submit a request for access. In this case, you must review and approve the request before the user can access the app.

The following controls allow you to set up a rule bypass:

-   Web Access
-   Login Control
-   File Download
-   File Upload
-   Screenshot
-   Print
-   Typing Guard

You can also set the bypass window to allow users to bypass the restrictions for a specified amount of time.

You can examine the Event Logs to see controls that may be too restrictive and tune them up so that they are more useful.

## How are bypass requests configured in policy?

You [define the bypass conditions within the policy rules](#manage-prisma-access-browser-requests_task-xgg_w5y_fcc). Then, when users attempt to perform an action or visit a site blocked by the corresponding rule, they can submit a bypass request. Bypass requests are an extension of Prompt actions where Prisma Browser prompts the user with a message indicating that the action or site is blocked and allowing them to continue anyway. To set bypass conditions, you configure the prompt action to enable permission requests. With bypass conditions you must [review and approve the request](#manage-prisma-access-browser-requests_task-mcm_hvy_fcc) before Prisma Browser allows the user to perform the blocked action or access the blocked site.

## Configure the Bypass Conditions

Configure the conditions for bypass rules when you [create or edit an Access and Data Control rule](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules.html). The way you configure the conditions depends on the type of user activity for which you want to allow bypass.

## Set Bypass Conditions for Web Access Rules

1.  In the Policy Rules - Edit ruleWeb access page, select Prompt.
    
2.  Define the bypass conditions for the web access rule by selecting one of the following options:
    
    -   Warn and allow to proceed anyway—notifies users that the web application they are trying to access is restricted, but allow them to proceed anyway. You will receive an event.
    -   Warn and allow the user to proceed anyway with a reason—notifies users that the web application they are trying to access is restricted, but allow them to proceed after supplying a reason they need access. You will receive an event.
    -   Permission request—notify users that the web application they are trying to access is restricted, and prompt them to submit a request for access. In this case, you must [review and approve the request](#manage-prisma-access-browser-requests_task-mcm_hvy_fcc) before the user can access the app.
    

## Set Bypass Conditions for Login Controls

The Login restriction section in Access & Data Control rules enables you to restrict login to specific email domains.

1.  In the **Policy Rules - Edit rule→Login controls** page, select **Prompt**.
    
2.  Define the bypass conditions for the login restriction rule by selecting one of the following options:
    
    1.  **Allow** - Allow all domains.
        
    2.  **Block** - Block all domains.
        
    3.  **Allow specific email domains** - Allows access only to the domains you specify.
        
    4.  **Block specific email domains** - Blocks access only to the domains you specify.
        
    
3.  Specify the email domains that this rule governs.
    
4.  Select **Prompt when the login is blocked** - With this setting enabled, when users attempt to login using a restricted email, Prisma Browser notifies them. You can set the following bypass conditions:
    
    1.  Warn and allow to proceed anyway—notifies users that the web application they are trying to access is restricted, but allow them to proceed anyway. You will receive an event.
        
    2.  Warn and allow the user to proceed anyway with a reason—notifies users that the web application they are trying to access is restricted, but allow them to proceed after supplying a reason they need access. You will receive an event.
        
    3.  Permission request—notify users that the web application they are trying to access is restricted, and prompt them to submit a request for access. In this case, you must [review and approve the request](#manage-prisma-access-browser-requests_task-mcm_hvy_fcc) before the user can access the app.
        
    
5.  Set the duration of the Bypass timeframe, ranging from 10 minutes to 90 days. Select once to allow a single download.
    

## Set Bypass Conditions for File Download

The File Download profile in [Access & Data Control rules](https://docs.paloaltonetworks.com/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules.html) allows you to restrict file downloads. This option is available from either the Profiles or from the Data controls, but we recommend using the Data controls to manage policies

1.  In the **Policy Rules - Edit rule-Data controls** page, select **File Download**.
    
2.  Select either **Allow** or **Allow (Protected)**.
    
3.  Click **Prompt Before download** and select **Before download**.
    
4.  Select **Popup notification** and define the bypass conditions for file downloads by selecting one of the following options.:
    
    1.  Warn and allow to proceed anyway—notifies users that the web application they are trying to access is restricted, but allow them to proceed anyway. You will receive an event.
        
    2.  Warn and allow the user to proceed anyway with a reason—notifies users that the web application they are trying to access is restricted, but allow them to proceed after supplying a reason they need access. You will receive an event.
        
    3.  Permission request—notify users that the web application they are trying to access is restricted, and prompt them to submit a request for access. In this case, you must [review and approve the request](#manage-prisma-access-browser-requests_task-mcm_hvy_fcc) before the user can access the app.
        
    
5.  Set the duration of the Bypass timeframe, ranging from 10 minutes to 90 days. Select once to allow a single download.
    

## Set Bypass Conditions for File Upload

The File Upload profile in [Access & Data Control rules](https://docs.paloaltonetworks.com/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules.html) allows you to restrict file uploads. This option is available from either the Profiles or from the Data controls, but we recommend using the Data controls to manage policies.

1.  In the **Policy Rules - Edit rule-Data controls** page, select **File Upload**.
    
2.  Select either **Allow** or **Allow (Protected)**.
    
3.  Click **Prompt Before upload** and select **Before upload**.
    
4.  Select **Popup notification** and define the bypass conditions for file upload by selecting one of the following options.:
    
    1.  Warn and allow to proceed anyway—notifies users that the web application they are trying to access is restricted, but allow them to proceed anyway. You will receive an event.
        
    2.  Warn and allow the user to proceed anyway with a reason—notifies users that the web application they are trying to access is restricted, but allow them to proceed after supplying a reason they need access. You will receive an event.
        
    3.  Permission request—notify users that the web application they are trying to access is restricted, and prompt them to submit a request for access. In this case, you must [review and approve the request](#manage-prisma-access-browser-requests_task-mcm_hvy_fcc) before the user can access the app.
        
    
5.  Set the duration of the Bypass timeframe, ranging from 10 minutes to 90 days. Select once to allow a single upload.
    

## Set Bypass Conditions for Typing Guard

-   The typing guard control in [Access & Data Control rules](https://docs.paloaltonetworks.com/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules.html) allows you to restrict the ability of users to type. This option is available from either the Profiles or from the Data controls, but we recommend using the Data controls to manage policies.
    

1.  In the **Policy Rules - Edit rule-Data controls** page, select **Typing Guard**.
    
2.  Select **Enable**.
    
3.  Select **Prompt**.
    
4.  Select **Popup notification** and define the bypass conditions for file upload by selecting one of the following options.:
    
    1.  Warn and allow to proceed anyway—notifies users that the web application they are trying to access is restricted, but allow them to proceed anyway. You will receive an event.
        
    2.  Warn and allow the user to proceed anyway with a reason—notifies users that the web application they are trying to access is restricted, but allow them to proceed after supplying a reason they need access. You will receive an event.
        
    3.  Permission request—notify users that the web application they are trying to access is restricted, and prompt them to submit a request for access. In this case, you must [review and approve the request](#manage-prisma-access-browser-requests_task-mcm_hvy_fcc) before the user can access the app.
        
    
5.  Set the duration of the Bypass timeframe, ranging from 10 minutes to 90 days. Select once to allow a single upload.
    

## Set Bypass Conditions for Screenshot Protection

The screenshot control in [Access & Data Control rules](https://docs.paloaltonetworks.com/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules.html) allows you to restrict the ability of users to take screenshots. This option is available from either the Profiles or from the Data controls, but we recommend using the Data controls to manage policies.

1.  In the **Policy Rules - Edit rule-Data controls** page, select **Screenshot**.
    
2.  Select either **Allow** or **Allow (Protected)**.
    
3.  Click **Prompt** .
    
4.  Select **Popup notification** and define the bypass conditions for file upload by selecting one of the following options.:
    
    1.  Warn and allow to proceed anyway—notifies users that screenshots are restricted, but allow them to proceed anyway. You will receive an event.
        
    2.  Warn and allow the user to proceed anyway with a reason—notifies users that screenshots are restricted, but allow them to proceed after supplying a reason they need access. You will receive an event.
        
    3.  Permission request—notify users that screenshots are restricted, and prompt them to submit a request for access. In this case, you must [review and approve the request](#manage-prisma-access-browser-requests_task-mcm_hvy_fcc) before the user can access the app.
        
    
5.  Set the duration of the Bypass timeframe, ranging from 10 minutes to 90 days. Select once to allow a single upload.
    

## Set Bypass Conditions for Printing Controls

The print control in [Access & Data Control rules](https://docs.paloaltonetworks.com/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules.html) allows you to restrict the ability of users to print. This option is available from either the Profiles or from the Data controls, but we recommend using the Data controls to manage policies.

1.  In the **Policy Rules - Edit rule-Data controls** page, select **Print**.
    
2.  Select **Allow**.
    
3.  Select **Prompt**.
    
4.  Select **Popup notification** and define the bypass conditions for file upload by selecting one of the following options.:
    
    1.  Warn and allow to proceed anyway—notifies users that printing is restricted, but allow them to proceed anyway. You will receive an event.
        
    2.  Warn and allow the user to proceed anyway with a reason—notifies users that printing is restricted, but allow them to proceed after supplying a reason they need access. You will receive an event.
        
    3.  Permission request—notify users that printing is restricted, and prompt them to submit a request for access. In this case, you must [review and approve the request](#manage-prisma-access-browser-requests_task-mcm_hvy_fcc) before the user can access the app.
        
    
5.  Set the duration of the Bypass timeframe, ranging from 10 minutes to 90 days. Select once to allow a single upload.
    

## Manage Permission Requests

After you set bypass request conditions on policy rules, you must review incoming requests and decide whether or not to allow the requests.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyRequests.
    
2.  Select the request you want to review and click Reply.
    
3.  Review the request and then select one of the following responses:
    
    -   Approve—Grants approval for the request for the pre-configured duration, or select a different duration.
    -   Decline—Rejects the request. Prisma Browser continues to block the requested action or site access.
    
4.  Choose the timeframe for the request. This overrides the default setting in the rule with a specific timeframe for the approval.
    
5.  (Optional) Add a comment for the user.
    
6.  Submit your response.
    

The user will get a notification that there is a response for their request.

You can also manage permission requests via API and connect them to external systems.

## Investigate Bypass Requests

If you have [configured bypass conditions](#manage-prisma-access-browser-requests_task-xgg_w5y_fcc) on your policy rules and you find that you are [approving similar requests](#manage-prisma-access-browser-requests_task-mcm_hvy_fcc), this might indicate that you need to tune your policy rules. You can investigate current and past bypass rules to assess whether you need to make some adjustments to your policy on the ConfigurationPrisma Browser PolicyRequests page.

-   Search for specific bypass requests by URL.
    
-   Filter requests based on the following parameters:
    
    -   Request type—Filter on the type of bypass: Web access, File upload, File download, or App login.
    -   Status—Filter on requests that are Pending, Approved, or Declined.
    -   Created at—Filter on requests made during a specific time frame.
    -   User—Filter on specific users making requests.
    -   Policy rule—Filter on the rule that trigged the bypass requests.
    -   URL—Filter based on the URL of the web application that generated the request.