---
title: "Prisma Browser User Guide Overview"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/user-guide/prisma-access-browser-user-guide-overview"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Browser User Guide Overview"
updated: "Tue Feb 10 06:48:18 PST 2026"
---

# Prisma Browser User Guide Overview
Learn about Prisma Access Secure Enterprise Browser (Prisma Browser), what it is, how data is synced, the functionality, and the messages.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
|  |  |

## Prisma Browser Overview

Prisma Browser is a browser designed specifically for enterprise use, built on the Chromium platform and fortified with security features to protect users and organizations against cyberthreats like phishing, malware, eavesdropping, and data exfiltration.

The Prisma Browser combines the user-friendly interface and core features of Google Chrome with enhanced security measures to provide a secure browsing experience that maintains Chrome's simplicity and speed. This allows users to enjoy the familiarity and convenience of Chrome while addressing its various security weaknesses.

## Prisma Browser Synced Data Storage

Syncing with Prisma Browser’s sync service is automatic. Every user's identity is assigned a unique key that encrypts the data that is sent and stored.

Neither Palo Alto Networks employees nor Prisma Browser console administrators have access to these keys. Encryption keys are stored in a secret store that is only accessible with a token associated with the user account.

A record of each access to the encryption key is maintained.

## Prisma Browser Functionality

The Prisma Browser contains an impressive array of built-in security features, including:

-   Phishing protection
    
-   Malware protection
    
-   Network security capabilities
    

Even though Prisma Browser offers powerful and comprehensive protection from online threats, no security solution is completely foolproof. We strongly encourage you to always remain vigilant when browsing and to exercise discretion and vigilance when sharing information online.

The Prisma Browser logs web traffic and browser activities that are appropriate for data protection and organizational security.

The Prisma Browser does not record keystrokes, user passwords, or user inputs on forms.

The Prisma Browser does allow users to save login credentials for websites, similar to Google Chrome. This data is saved locally and cannot be accessed outside of your computer.

Prisma Browser should be used for any web browsing defined by the company. Depending on company policy, you may be allowed to use another browser for other purposes.

See [Palo Alto Network’s Privacy Policy](https://www.paloaltonetworks.com/resources/datasheets/prisma-access-browser-privacy-datasheet).

## Prisma Browser Troubleshooting

Some Prisma Browser messages can seem like issues, but are for safety or compliance purposes. Some messages can be issues.

-   A Restricted website message means that this website is identified as being unsafe, vulnerable, fraudulent, or malicious.
-   The ”Your connection is not private” message often occurs due to a website misconfiguration or certificate issue. If you believe a website was blocked in error, please contact IT. Until IT approves the site, do not proceed.
    
-   If you receive an error when you attempt to sign into a website with a username that is set to your company email address, please contact IT for assistance. Be sure to include the URL of the website and your computer’s hostname/IP address in the Description.
-   See [use the control pane](/content/techdocs/en_US/prisma-access-browser/user-guide/prisma-access-browser-setup-and-use.html) for specific info about troubleshooting the control pane.