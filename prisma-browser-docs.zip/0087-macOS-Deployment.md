---
title: "macOS Deployment"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/prisma-access-browser-update-mechanics/macos-deployment"
depth: 3
breadcrumbs: "Home > Prisma Browser > Installers and Updates > macOS Deployment"
updated: "Feb 10, 2026"
---

# macOS Deployment
These are the macOS deployment methods

Prisma Browser supports two installation variations for macOS environments. Both variations can be installed offline, and include a self-updating component.

| File Type | Primary Use Case |
| --- | --- |
| **PKG** | Automated deployments via MDM solutions or local admins. Preferred for enterprise environments. |
| **DMG** | Manual installations by unprivileged end-users, BYOD. |

| Architecture | Latest Installation | Version Feed |
| --- | --- | --- |
| **Universal** | [PKG](https://release-manager.us.gs.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=universal&channel=packaged&redirect=true) | [DMG](https://release-manager.us.gs.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=universal&channel=standalone&redirect=true) | [PKG](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=universal&channel=packaged) | [DMG](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=universal&channel=standalone) |
| **Apple Silicon** (ARM64) | [PKG](https://release-manager.us.gs.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=arm64&channel=packaged&redirect=true) | [DMG](https://release-manager.us.gs.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=arm64&channel=standalone&redirect=true) | [PKG](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=arm64&channel=packaged) | [DMG](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=arm64&channel=standalone) |
| **Intel** (x64) | [PKG](https://release-manager.us.gs.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=x64&channel=packaged&redirect=true) | [DMG](https://release-manager.us.gs.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=x64&channel=standalone&redirect=true) | [PKG](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=x64&channel=packaged) | [DMG](https://release-manager.us.gs.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=mac&architecture=x64&channel=standalone) |

## Browser Updates

The browser follows a weekly update schedule aligned with Chrome’s release cycle, which includes weekly security patches and a major version update with new features approximately every month.

Administrators can select between two release channels through the **deployment** policy:

-   **Stable Channel** (default): Receives weekly updates that include both new features and security patches.
-   **Long-Term Support (LTS) Channel**: Receives weekly security patches and new Prisma Browser and Chromium features only during the monthly major version updates.

The **Deployment** policy in the management console allows customization of the deployment delay for new features and configuration of the update enforcement schedule.

Updates downloaded during the update process are applied at the next browser start or restart. Active browser sessions will display a notification prompting users to restart their browsers to apply the update.

**macOS**

For macOS devices, browser updates are currently managed within the browser context. The update process initiates only while the browser is running and operates using the active user's permissions.

This process will be updated with the upcoming introduction of the Prisma Browser Updater for macOS.