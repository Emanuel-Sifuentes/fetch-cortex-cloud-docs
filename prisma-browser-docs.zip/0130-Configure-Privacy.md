---
title: "Configure Privacy"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-privacy"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Security Controls > Configure Privacy"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure Privacy
Browser Security Privacy configuration

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Third-party Cookies

Mobile Browser - **No support**

The Prisma Browser allows you to configure whether or not you will accept cookies from web pages that are not from the domain that's in the address bar.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Third-party Cookies.
    
3.  Select one of the following options:
    
    -   **Allow** - Third-party elements can set cookies.
        
    -   **Block** - Third-party elements cannot set cookies.
        
    
4.  Click Set.
    

## Browser History

Mobile Browser - **No support**

The Prisma Access Browser allows you manage the ability to delete the browser history.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Browser History.
    
3.  Select one of the following options:
    
    -   **Enable** - browser history is saved.
        
    -   **Disable** - browser history is not saved, and tab syncing is disabled. This setting cannot be changed by users.
        
    -   **Block Deletion** - browser history and download history cannot be deleted.
        
    
4.  Click Set.
    

## Cookies

Mobile Browser - **No support**

This policy controls the ability to store cookies on the browser. It allows companies to keep the data only for the session to avoid theft of the credentials.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Cookies.
    
3.  Select one of the following options:
    
    -   **Allow** - default cookies behavior, as controlled by the end-user.
        
        After choosing this option, you can select specific domains to exclude. This means that the selected domains will not be able to set cookies.
        
    -   **Block** - do not allow any websites to set the local data.
        
        Blocking cookies can cause issues with loading websites.
        
        After choosing this option, you can select specific domains to include. This means that the selected domains will be able to set cookies.
        
    -   **Session only** - keep cookies for the duration of the session. After choosing this option, you can select the URLs that will keep cookies for the duration of the session.
        
    
4.  Click Set.