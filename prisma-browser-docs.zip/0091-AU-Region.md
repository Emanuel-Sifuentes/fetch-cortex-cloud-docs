---
title: "AU Region"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-au"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Browser Prerequisites > AU Region"
updated: "Tue Feb 10 06:48:12 PST 2026"
---

# AU Region
The following domains are for clients in the AU region.

The following domains are for clients in the AU region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   au.api.wildfire.paloaltonetworks.com
-   au.wildfire.paloaltonetworks.com
-   cie-api-proxy.au.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.au.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.au.talon-sec.com
-   users-assets.au.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com