---
title: "Cloud Storage Integrations"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/cloud-storage-integrations"
depth: 2
breadcrumbs: "Home > Prisma Browser > Cloud Storage Integrations"
updated: "Feb 10, 2026"
---

# Cloud Storage Integrations
Describes how to integrate Microsoft One drive and Google Drive

| Where Can I Use This? | What Do I Need? |
| --- | --- |
|  | Refer to the cloud providers for their specific requirements. |

The **Save to Cloud** capability enables you to block direct file downloads to user endpoints and instead redirect downloads to organization-managed cloud storage, such as Microsoft OneDrive or Google Drive. This approach not only aligns with data protection policy rules but also improves user productivity by offering smooth access to files across devices.

### Select between Cloud Storage and Encrypted Downloads

This section provides the guidance for selecting the appropriate method - cloud storage or encrypted downloads - for securely distributing and accessing files, based on specific operational and security requirements,

Cloud storage and encrypted downloads both support secure file distribution, but each serves different use cases. The appropriate choice depends on many different factors.

**RECOMMENDED USE CASES**

Use **Cloud Storage** when:

-   **Frequent Access Is Required —** Multiple users or devices need regular access to the files.
-   **Real-time Collaboration Is Needed —** Multiple users must view, edit, or comment on files simultaneously.
-   **Version Control Is Required —** You need to track changes and maintain a history of file versions.
-   **Centralized Access Control Is Important —** You can manage permissions and user access directly within the cloud environment.
-   **Mobile or Remote Access Is Necessary —** Users require access from multiple locations or devices, including mobile endpoints.

Use **Encrypted Downloads** when:

-   **One-Time or Limited Access Is Sufficient —** Files are intended for single-use or short-term local access.
-   **High Security is a Priority —** Files contain sensitive information that must be stored locally with encryption. The files can only be downloaded using the browser.
-   **Offline Access Is Required —** Users need to access files in environments without reliable internet connectivity.
-   **Collaboration Isn’t Needed —** Files don’t require editing or sharing across users or devices.
-   **Regulatory Compliance Requires Local Storage —** Certain policy rules or legal frameworks mandate storage outside of cloud platforms.

Encrypted downloads allow you to determine where the files will exist locally, and can only be opened using the Prisma Browser. Save to Cloud allow you to move the files to any location and is not encrypted.

You need to configure the Cloud Storage Integrations before you select the cloud storage providers.

The following cloud providers can be configured:

-   [Microsoft OneDrive](/content/techdocs/en_US/prisma-access-browser/integrations/cloud-storage-integrations/cloud-provider-microsoft-onedrive.html#cloud-provider-microsoft-onedrive)
-   [Google Drive](/content/techdocs/en_US/prisma-access-browser/integrations/cloud-storage-integrations/cloud-provider-google-drive.html#cloud-provider-google-drive)

## Cloud Provider - Microsoft OneDrive

This document contains the directions for integrating Microsoft OneDrive as the cloud provider

### Microsoft OneDrive Prerequisites

These are the prerequisites for configuring Microsoft OneDrive as your cloud provider:

-   Global Administrator access in Azure Active Directory (AD)

End users require a valid Microsoft 365 license:

-   Microsoft 365 Business Basic /Standard / Premium
-   Microsoft 365 Apps for Business
-   Microsoft 365 E3 / E5

### Configure Microsoft OneDrive as the Cloud Provider

1.  Register a new app in Azure.
    
    1.  Sign in to the [Azure Portal](https://portal.azure.com/).
        
    2.  Go to **Azure Active Directory → App registrations → + New registration**.
        
    3.  Enter a descriptive name (for example, _Prisma Browser Cloud Storage for M365_)
        
    4.  Choose **Single tenant** (Accounts in this organizational directory only).
        
    5.  Under **Redirect URI**, select **Single-page application (SPA)** and use this URI: https://gdhaibkimkeghllnpodfpoamchapggea.chromiumapp.org/
        
    6.  Click **Register**.
        
    
2.  Add Permissions to the New App.
    
    1.  Open the new app **→ App permissions → + Add a permission**.
        
    2.  Choose **Microsoft Graph**.
        
    3.  Add the following Application permissions:
        
        -   Application.Read.All
        -   DelegatedPermissionGrant.Read.All
        
    4.  Click **+Add a permission → Microsoft Graph → Delegated permissions**.
        
    5.  Add the following permission:
        
        -   Files.ReadWrite.All
        
    6.  Click **Grant admin consent for <your tenant name>** Click **Yes** in the consent confirmation pop-up.
        
        User.Read permission (delegated) is added by default by the application. DO NOT REMOVE THIS PERMISSION.
        
    
    WHY ARE THESE PERMISSIONS NEEDED?
    
    **Prisma Browser** requires specific permissions. These are the minimum necessary to ensure proper connection and to manage file downloads to your organization's cloud storage. This **least-privilege** approach minimizes security risks by only requesting access essential for its operation.
    
    | **Permission Type** | **Permission Name** | **Reason** |
    | --- | --- | --- |
    | Delegated | User.Read | Confirms that the user connected to the browser is the same user that is connected to Microsoft. |
    | Delegated | Files.ReadWrite.All | Saving files to the user's OneDrive on their behalf. |
    | Application | Application.Read.All DelegatedPermissionGrant.Read.All | Verifies the integration configured by the Microsoft admin. |
    
    Admins always consent to application permissions. In contrast, end users consent to delegated permissions. Granting admin consent for delegated permissions is required. It prevents users from mistakenly denying permissions, which would block them from downloading and saving files to OneDrive when a Security policy is triggered.
    
    Verifying the onboarding status of the integration is critical. Improper configuration will prevent Prisma Browser from saving files to OneDrive. This will block end users from downloading and saving files when their download action matches a policy rule.
    
3.  Generate Client Secret.
    
    1.  Go to **Certificates & Secrets → New client secret**.
        
    2.  In the Add a client secret tab, do the following:
        
        1.  Enter a **description** for the secret, for example - Microsoft secret 01. (this field is optional.
        2.  In the **Expires** field, select **730 days (24 months)**.
        
    3.  Click **Add**.
        
    4.  Copy the value of the new client secret. You will need it for the next step when you connect the cloud storage to the Prisma Browser. We recommend that you save it in a safe place.
        
    
4.  Connect to the Prisma Browser.
    
    1.  Go to the Prisma Browser admin console and select **Integrations**.
        
    2.  Select **Cloud Storage**.
        
    3.  Click on either **+add provider** or **Connect your first provider**.
        
    4.  Select the provider - **Microsoft**.
        
    5.  Insert a descriptive **Storage name** for the connection, for example - _Microsoft Cloud Storage_.
        
    6.  Paste the **Client secret** that you generated in the previous step.
        
    7.  Enter the Application (client) ID and the Directory (tenant) ID from the Application Overview in the Azure Portal.
        
    8.  Click **Test provider connection** to verify the connection with Azure.
        
    9.  Once the test is successful, click **Add Provider**.
        
    
5.  Create the Save to Cloud Rule
    
    1.  Open the **Access & Data Control** rules and create a new rule.
        
    2.  At the **Data Control** step, select **File Download**.
        
    3.  Select **Save to organization storage** and choose the provider that you configured in the previous step.
        
    4.  Add any additional details, and click **Set**.
        
    

### Known Limitations and Requirements

To successfully use Save to Cloud, users must meet the following conditions:

-   **Microsoft 365 Licensing:** The policy must apply only to users who hold a valid Microsoft 365 license that includes access to OneDrive and the Office suite.
-   **Email Consistency:** The email address used to sign into the browser must match the Microsoft account associated with the user’s OneDrive. This prevents accidental data leakage or cross-account DLP violations.
-   **Microsoft Sign-In Required:** Users must be signed into their Microsoft account. If not already authenticated, they will be prompted to log in, with the browser providing a username hint to streamline the process.

HTML sites will be compressed using zip format and saved in a folder. The Prisma Browser does not support unzipping files. As a result, this is not recommended.

## Cloud Provider - Google Drive

This document contains the directions for integrating Google Drive as the cloud provider

### Google Drive Prerequisites

These are the prerequisites for configuring Google Drive as your cloud provider:

-   Super Admin role in the Google Workspace Admin Console.
-   Role on a Google Cloud Platform (GCP) project. You need one of the following toles:
    -   **Service Account Creator** (roles/iam.serviceAccountCreator)
    -   **Service Account Key Admin** (roles/iam.serviceAccountKeyAdmin)
    -   **Service Usage Admin** (roles/serviceusage.serviceUsageAdmin)
    -   **Project Editor** role (roles/editor)

End users require a valid Google Workspace License. The supported SKUs include:

-   Google Workspace Business Starter
-   Google Workspace Business Standard
-   Google Workspace Business Plus
-   Google Workspace Enterprise Standard
-   Google Workspace Enterprise Plus

### Configure Google Drive as the Cloud Provider

This document outlines the steps required to onboard Google Drive as a cloud Storage Provider for use with Prisma Browser’s **Save to Cloud** feature. This process involves configuring access through Google Cloud Platform (GCP) and delegating domain-wide authority in the Google Workspace Admin Console.

1.  Enable the Google Drive API in GCP.
    
    1.  Open a browser tab and navigate to the Google Cloud Console.
        
    2.  **Select or create** a project that will be used for the integration.
        
    3.  In the left side menu, go to **APIs & Services → Enabled APIs and Services**.
        
    4.  Click Enable **APIs & Services**.
        
    5.  Select **Google Drive API** and click **Enable** on the details page.
        
    
2.  The Service Account allows the browser to upload files by generating a one-time token per upload, eliminating the need for the user to log in each time.
    
    Create a Service Account.
    
    1.  In the **Google Cloud Console**, go to the project you selected in the previous step.
        
    2.  Navigate to **IAM & Admin** and select **Service Accounts**.
        
    3.  Click **\+ Create service account**.
        
        1.  Enter a Service account name. This name will be displayed in the Google Cloud Console.
        2.  Click **Create** and continue to generate the Service account ID. You can edit it, if needed.
        3.  Optionally, enter a Service Account description.
        4.  Click **Done**.
            
        
    4.  Continue through the steps until the service account is created.
        
    
3.  Generate a Private Key (JSON)
    
    1.  Locate your newly-created service account in the list.
        
    2.  Click the **More (⋮)** icon under the Actions field, and select Manage Keys.
        
    3.  Click **ADD KEY** → **Create new key**.
        
    4.  Choose **JSON** as the key type and click **Create**.
        
    5.  The system downloads a private key file to your computer. **Store this file securely**; it authenticates the service account.
        
    
4.  Retrieve the Client ID
    
    1.  Go back to the **Service Accounts** page in the Cloud Console.
        
    2.  Click the name of your service account to open its details.
        
    3.  Under the **Details** tab, locate the **Client ID** and copy it. You will use this in the next step.
        
    
5.  Delegate Domain-Wide Authority in Google Workspace.
    
    1.  Open a browser and navigate to the[**Google Admin Console**](https://admin.google.com).
        
    2.  Sign in using a **Super Admin** account.
        
    3.  From the left-hand menu, go to **Security** → **API Controls**.
        
    4.  Scroll to the **Domain-wide delegation** section and click **Manage Domain Wide Delegation**.
        
    5.  Click **Add new** to add a new Client ID.
        
    6.  In the **Client ID** field, paste the ID you copied from your service account.
        
        In the **OAuth Scopes** field (comma-delimited), enter the following scopes:
        
        -   https://www.googleapis.com/auth/drive.file
        -   https://www.googleapis.com/auth/drive.metadata.readonly
        
    7.  These scopes allow the service account to access and manage Google Drive files on behalf of users within the domain.
        
    8.  Click **Authorize** to complete the delegation process.
        
        **Why are the Scopes required?**
        
        ​​These scopes adhere to the principle of least privilege, ensuring the application only has the permissions required to perform its core functions — securing connections and managing file downloads effectively to the organizational cloud.
        
    9.  These scopes allow the service account to access and manage Drive files on behalf of users within the domain.
        
        | drive.metadata.readonly | Used to list folders in the user's drive |
        | --- | --- |
        | drive.file | Used to upload files to the user's drive |
        
        By using **domain-wide delegation**, Prisma Browser can upload files to an end-user's Google Drive without any user interaction. This process leverages the user's browser sign-in context, eliminating the need for them to be actively signed into Google.
        
        For security, Prisma Browser uses a **short-lived access token** to upload files to Google Drive. This token is created only when a file download triggers a matching cloud storage rule and is strictly scoped to the signed-in user, which prevents extensive access.
        
    
6.  Create the integration with the Prisma Browser Console.
    
    1.  Go to the Prisma Browser admin console and select **Integrations**.
        
    2.  Select **Cloud Storage**.
        
    3.  Click on either **+add provider** or **Connect your first provider**.
        
    4.  Select **Google**.
        
    5.  Insert a descriptive name for connection; for example, your Google tenant name.
        
    6.  Upload the JSON file.
        
    7.  Enter an email to verify permissions.
        
        -   This step secures your organization’s data and enhances user productivity by integrating with your managed cloud storage services. Instead of allowing direct file downloads to user devices, our **'Save to Cloud'** feature automatically redirects them to your organization’s cloud storage.
            
            This method ensures that you can enforce your data protection policies and give users seamless access to their files across all their devices, which supports better collaboration and a smoother workflow.
            
        -   To ensure that you have configured the permissions correctly, you must use the email of an active, licensed user in your organization. The system uses this email solely for a permissions check; it **will not** send emails or upload any files to the account.
        
    8.  Click **Test provider connection** to verify the connection with Google.
        
    9.  Once the test is successful, click **Add Provider**.
        
    

### Known Limitation

HTML sites will be compressed using zip format and saved in a folder. The Prisma Browser does not support unzipping files. As a result, this is not recommended.