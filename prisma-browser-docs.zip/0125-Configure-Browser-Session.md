---
title: "Configure Browser Session"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-browser-session"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Security Controls > Configure Browser Session"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure Browser Session
Configure browser security controls for Prisma Access Secure Enterprise Browser (Prisma Browser).

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Browser Lock

Mobile Browser - **Full support**

Prisma Browser includes a browser lock screen feature that adds an extra layer of security by requiring user authentication when the browser is accessed. When Browser Lock is enabled, users must either enter a PIN code, authenticate using a Passkey, or authenticate using their Identity Provider to unlock the browser:

-   When the browser is first opened or after the Operating System is unlocked.
-   After a configurable period of idle time away from the device.

This feature is especially valuable for unmanaged devices, where device-level security policies may not be enforced, and for shared devices, where enterprise data must be protected from unauthorized access by other users of the same system.

**Platform Behavior**

-   **Windows and macOS**: Idle time is determined using the same system mechanism that the operating system uses to trigger sleep mode.
-   **Mobile Devices**: The feature relies on the device’s native screen lock. PIN length and maximum failed attempts settings are ignored.

The Prisma Browser for Mobile relies on the native device screen lock, and not the lock that is included in the Prisma Browser tool. The PIN length and Maximum Failed Attempts will be ignored.

The Authentication method is configured in **Browser Security -> Authentication Factor**.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Browser Lock.
    
3.  Select one of the following options:
    
    -   **Enable** \- enable the Browser lock.
        
        -   Select the **Idle time** - 1 minute to 12 hours (or never). This is the time that must elapse before the Browser Lock screen appears.
    -   **Disable** \- the Prisma Access Browser will disable the Browser Lock.
        
    
4.  Click Set.
    

## Flush Browser Data

Mobile Browser - **Partial support**

This policy creates temporary browser sessions. This means that browser data will be cleared upon close, or after a configured time period.

The Prisma Browser for Mobile supports flushing data when the browser closes. Configuring periodic flushing on the mobile browser will have no impact.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Flush Browser Data.
    
3.  Select one of the following options:
    
    -   **Enable** \- the Prisma Browser flush the browser data.
        
        -   Select the attributes to clear:
            
            -   Browsing history
                
            -   Download history
                
            -   Cookies and other site data
                
            -   Cached images and files
                
            -   Passwords and Passkeys
                
            -   Autofill
                
            -   Site settings.
                
            -   Host app data
                
        -   Select the trigger for the browser flush action:
            
            -   **Browser close** - the data will be flushed when the browser is closed.
                
            -   **Time period** - the data will be flushed after the configured time elapsed. If this option is selected, you can set the flush time from 1-24 hours.
                
    -   **Disable** – disable the Browser flush feature.
        
    
4.  Click Set.
    
    i
    

## Concurrent Browser Sessions

Mobile Browser - **Full support**

This policy allows you to determine the maximum number of devices that a user can have logged into the browser at one time during the retention period. This includes both Prisma Browser and Prisma Browser for Mobile.

-   The back-end stores session data for 7 days (the retention period).
-   Prisma Browser sessions expire after 7 days of inactivity or upon manual logout.
-   Prisma Browser for Mobile sessions often stay active in the background to sync policy updates; this will prevent a session from becoming inactive. Mobile browser sessions must be closed manually

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Concurrent number of devices.
    
3.  Select one of the following options:
    
    -   **Limit number of devices** \- You will be able to limit the number of browser session concurrently. You can set the maximum to between 1 and 5 concurrent sessions per user.
        
    -   **Unlimited number of devices** – There is no limit to the number of concurrent sessions that users can have.
        
    
4.  Click Set.
    

## Session Refresh

Mobile Browser - **No support**

You can now set a time period after which users must log in again to re-authenticate. Fifteen minutes before the session expires, users will see a warning message in their current tab, notifying them that the session is nearing expiration. They can re-authenticate before the session ends by clicking **Re-authenticate Now**.

Policy changes only apply after the next logout.

For example, if session refresh was set to 9h, and is turned off, the user will still be logged out after 9h. They will not be logged out after their next session.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Session Refresh.
    
3.  Select one of the following:
    
    -   **Enable** to enable Session Refresh, then select **Log the user out every**: and select an appropriate time frame, ranging from 1 hour to 30 days
    -   **Disable** to disable Session Refresh.
    
4.  Click Set.