---
title: "Prisma Browser End-of-Life Policy"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/prisma-access-browser-end-of-life-policy"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Browser End-of-Life Policy"
updated: "Tue Feb 10 06:48:28 PST 2026"
---

# Prisma Browser End-of-Life Policy
Learn about the end-of-life policy for the Prisma Access Secure Enterprise Browser (Prisma Browser).

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Release Cadence

Prisma Browser follows a structured release cycle to provide timely updates, enhancements, and bug fixes:

The browser follows a weekly update schedule aligned with Chrome’s release cycle, which includes weekly security patches and a major version update with new features approximately every month.

Administrators can select between two release channels through the **deployment** policy:

-   **Stable Channel** (default): Receives weekly updates that include both new features and security patches.
-   **Long-Term Support (LTS) Channel**: Receives weekly security patches and new Prisma Browser and Chromium features only during the monthly major version updates.

The **Deployment** policy in the management console allows customization of the deployment delay for new features and configuration of the update enforcement schedule.

Updates downloaded during the update process are applied at the next browser start or restart. Active browser sessions will display a notification prompting users to restart their browsers to apply the update.

## End-of-Life (EoL) Policy

-   Each major version of our product is supported for ninety (90) days from its official release date. After this period, functionality is no longer guaranteed and technical support might be limited. Note: The release date remains unchanged for customers using customized gradual releases.
    
-   End users with EoL versions might encounter issues and difficulties upgrading to newer versions. To maintain security, compliance, and functionality, customers should plan for upgrades before the EoL stage.
    
-   We aim to ensure the security, stability, and functionality of our platform. Our EoL policy is designed to help customers plan transitions and upgrades effectively.
    
    For more information, please see [Palo Alto Networks End-of-Life Policy](https://www.paloaltonetworks.com/services/support/end-of-life-announcements/end-of-life-policy) and [Palo Alto Networks End-of-Life Summary](https://www.paloaltonetworks.com/services/support/end-of-life-announcements/end-of-life-summary).
    

## Security Updates and Functionality Guarantee

-   Security Updates: We provide security patches only for the latest version of Prisma Browser. All nonlatest versions, regardless of age, don't receive security updates.
    
-   Functionality Guarantee: We ensure that Prisma Browser core functionalities remain operational for versions up to 90 days from their official release date.
    
-   Risks and Limitations: Customers using versions beyond the 90-day support period might face increased security vulnerabilities, including risks of malware, data breaches, and other cyberthreats. Additionally, new features in the management console might not function or be accessible on older versions.
    
-   We strongly advise customers to regularly upgrade their browsers to the latest version using our autoupgrade policy. Staying informed about releases and maintaining the most recent version ensures your organization benefits from the latest security enhancements and feature improvements
    

## Browser Versions

A few features in the admin management console can help administrators to view the browser version breakdown and history:

-   Homepage: The Devices widget in the management console landing page presents the browser versions deploy in the tenant:
    
-   Devices screen: under the Browser Version field, the devices with the EoL browser version marked in red:
    
-   A version breakdown exists inside the device screen.