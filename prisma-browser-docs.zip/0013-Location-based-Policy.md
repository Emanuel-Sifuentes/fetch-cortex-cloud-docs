---
title: "Location-based Policy"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/location-based-policy"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Location-based Policy"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Location-based Policy
The location-based policy can be used to limit access to the Prisma Browser based on location.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone; Prisma Browser Mobile; Prisma Browser Extension | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Linux/IGEL browser - **No support**

This feature requires Prisma Browser version **129.90.2910.2** and later.

You now have the ability to apply policies based on the device's location in addition to the other Scope parameters that can be used for all policy rules.

The policy engine evaluates the location of the device every 60 minutes and reports the location back to the server. For macOS and Windows devices, the policy engine will use the OS Location Services, if enabled. Otherwise the engine will use Geo IP location.

## Important Information for Admins

1.  End-users who use VPN services can change their public IP by selecting a different location for their connection. For example, a user in Germany can decide to connect to the company network from a location in the United States, depending on the VPN provider.
    
    -   To reduce the risk of location bypass, you can use MDM (for managed devices) and enable OS location services to the browser, as well as to browsers that use the Prisma Browser Extension.
    
    The location may not be accurate around national borders for both OS Location Service and Geo IP.
    
2.  The Prisma Browser for Mobile currently uses only Geo IP.
3.  macOS Location Services are temporarily unavailable in Israel. See here for more information. [Why have Apple and Google disabled map features in Israel and Gaza?](https://www.govtech.com/question-of-the-day/why-have-apple-and-google-disabled-map-features-in-israel-and-gaza)

Older versions of the Prisma Browser can only use Geo IP. If you want to use OS Location Service, you need to upgrade.

Prisma Browser for Mobile supports Geo IP only.

Linux/IGEL Browser - **No Support**