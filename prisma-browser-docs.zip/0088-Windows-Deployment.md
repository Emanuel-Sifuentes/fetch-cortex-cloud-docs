---
title: "Windows Deployment"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/prisma-access-browser-update-mechanics/windows-deployment"
depth: 3
breadcrumbs: "Home > Prisma Browser > Installers and Updates > Windows Deployment"
updated: "Tue Feb 10 06:48:28 PST 2026"
---

# Windows Deployment
These are the Windows deployment methods

The following deployment methods are available for Windows devices:

**Online installer** is a stub lightweight stub installer that automatically retrieves the latest version of the browser from either the Default channel or Long-Term Support (LTS) channel, depending on the type of installer downloaded.

**Offline installer** consists of a standalone installation file that enables browser installation on systems without an internet connection.

| **Architecture** | **Online Installers (MSI)** | **Offline Installers (MSI)** |
| --- | --- | --- |
| **x64** | [Latest](https://installer.talon-sec.com/8c502beb44024f8582ed89b2a25501a6/PAB?os=windowsMsi) | [Latest LTS](https://installer.talon-sec.com/8c502beb44024f8582ed89b2a25501a6/PAB?os=windowsLtsMsi) | [Latest](https://releases.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=win&architecture=x64&channel=packaged&redirect=true) | [Version Feed](https://releases.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=win&architecture=x64&channel=packaged) |
| **ARM64** | [Latest](https://installer.talon-sec.com/8c502beb44024f8582ed89b2a25501a6/PAB?os=windowsArmMsi) | [Latest LTS](https://installer.talon-sec.com/8c502beb44024f8582ed89b2a25501a6/PAB?os=windowsArmLtsMsi) | [Latest](https://releases.talon-sec.com/api/v1/latest?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=win&architecture=arm64&channel=packaged&redirect=true) | [Version Feed](https://releases.talon-sec.com/api/v1/appcast.xml?appid=%7Bdfef2477-4f0e-454b-bc0d-03ce61074e4c%7D&platform=win&architecture=arm64&channel=packaged) |

## Browser Updates

The browser follows a weekly update schedule aligned with Chrome’s release cycle, which includes weekly security patches and a major version update with new features approximately every month.

Administrators can select between two release channels through the **deployment** policy:

-   **Default Channel**: Receives weekly updates that include both new features and security patches.
-   **Long-Term Support (LTS) Channel**: Receives weekly security patches and new Prisma Access Browser and Chromium features only during the monthly major version updates.

The **Deployment** policy in the management console allows customization of the deployment delay for new features and configuration of the update enforcement schedule.

Updates downloaded during the update process are applied at the next browser start or restart. Active browser sessions will display a notification prompting users to restart their browsers to apply the update.

**WINDOWS - Windows Installations with Auto-Update**

Windows installations configured with auto-update include both the browser and an updater service agent. This agent operates independently of the browser and is triggered by a system-level scheduled task.

-   **Background Updates**: When the machine is powered on, the scheduled task periodically checks for new browser versions, even if no user is logged in.
-   **Manual Update Check**: Users can manually trigger an update check by navigating to the **About** page at prisma://settings/help. If an update is available, the update service will notify the user and provide the option to install it.