---
title: "ID Region"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-ind"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Browser Prerequisites > ID Region"
updated: "Tue Feb 10 06:48:12 PST 2026"
---

# ID Region
The following domains are for clients in the ID region.

The following domains are for clients in the ID region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   id.api.wildfire.paloaltonetworks.com
-   id.wildfire.paloaltonetworks.com
-   cie-api-proxy.id.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.id.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.id.talon-sec.com
-   users-assets.id.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com