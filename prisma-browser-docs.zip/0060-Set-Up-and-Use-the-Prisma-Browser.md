---
title: "Set Up and Use the Prisma Browser"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/user-guide/prisma-access-browser-setup-and-use"
depth: 2
breadcrumbs: "Home > Prisma Browser > Set Up and Use the Prisma Browser"
updated: "Feb 10, 2026"
---

# Set Up and Use the Prisma Browser
Learn how to set up and use your Cloud managed Prisma Access Secure Enterprise Browser (Prisma Browser).

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Prisma Browser | [Set up and use](/content/techdocs/en_US/prisma-access-browser/user-guide/prisma-access-browser-setup-and-use.html) |

1.  Install the Prisma Browser.
    
    Your organization can select to deploy the Prisma Browser in several different ways:
    
    1.  It can be deployed by your administrators in a silent mode - that is - without any need for end-user intervention.
        
    2.  Your administrator can send you a link to the internal version of the application that was tested and customized by your administrators.
        
    3.  Your administrator can direct you to the Prisma Browser download site https://get.pabrowser.com
        
    
2.  Verify that the Prisma Browser is Installed.
    
    After the browser has been deployed to your computer, you will see the browser icon on your desktop. Double-click it to launch the Prisma Browser. If you don't see the Prisma Browser icon on your desktop:
    
    1.  If the Prisma Browser does not appear on your desktop, use the taskbar search function and search for Prisma Browser. If it appears, the Prisma Browser is installed on your computer.
        
    2.  In the search results, right-click on the Prisma Browser icon, and select Pin to Taskbar.
        
    3.  If you still can't locate the Prisma Browser on your computer, contact IT and provide them with the information they require.
        
    
3.  Sign in.
    
    1.  After the Prisma Browser launches, enter your work email address, then click Continue.
        
    2.  Reenter your email password for your work address, then click Sign in.
        
    3.  (Optional) If your organization has configured your account with two-factor authentication enabled, you will need to enter a PIN code or your biometric authentication to unlock the Prisma Browser every time you open it. If you use a PIN code, be sure to keep it safe.
        
    
4.  Set Prisma Browser as your default browser.
    
    1.  After you sign into your account, the Prisma Browser will relaunch with a welcome message.
        
    2.  At the top of the homepage, select the link called Set as default browser to make sure that the Prisma Browser will be your default browser.
        
    3.  This option sets Prisma Browser as the program associated with Web documents or links. Whenever a browser is needed, Prisma Browser will be the browser that opens.
        
    
5.  Import data from your previous Prisma Browser.
    
    You can migrate your settings, data, and bookmarks from your previous browser to the Prisma Browser
    
    1.  At the top of the homepage, select the link called Import browser data to make sure that the Prisma Browser will be your default browser.
        
    2.  In the Import bookmarks and settings window, select the browser and profile to import. You will see a list of available settings that you can import. Settings from non-Chrome browsers may be limited.
        
        The available profiles and items to import are based on the browsers that are currently installed on your computer. If there are multiple profiles for the same browser, we recommend that you select the one that is your default profile on the browser that you use for your day-to-day work.
        
    3.  All your bookmarks as well as other supported items should now be accessible through the Prisma Browser.
        
        After you import your bookmarks and other settings, all your browser-based work needs to be done using the Prisma Browser only.
        
    
6.  Start work with the Prisma Browser.
    
    1.  After the Prisma Browser is installed and configured on your system, you can start using it for your work.
        
    2.  The browser has the same look and feel as the Chrome browser, so there are no complex features you need to learn, or keyboard shortcuts you need to unlearn. Switching to this tool is a seamless and easy experience.
        
    
7.  Update the Prisma Browser.
    
    The Prisma Browser automatically checks for and installs updates in the background. When an update is ready, you may need to restart the browser. When this happens, you will receive an indication. In some cases, your IT department will monitor the updates and push the update to you when it's ready.
    
    1.  In the upper-right corner of the browser, select Update.
        
    2.  Select **Relaunch** to update the Prisma Browser. The browser will shut down, and restart. It will keep all open tabs.
        
    
    **How is Synced Data Stored?**
    
    Syncing with Prisma Access Browser's sync service is automatic. Every user's identity is assigned a unique key that encrypts the data that is sent and stored.
    
    Neither Palo Alto employees nor console administrators have access to these keys. Encryption keys are stored in a secret store that is only accessible with a token associated with the user account.
    
    A record of each access to the encryption key is maintained.