---
title: "Prisma Browser Prerequisites"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Browser Prerequisites"
updated: "Feb 10, 2026"
---

# Prisma Browser Prerequisites
Learn about the prerequisites for Prisma Access Secure Enterprise Browser (Prisma Browser), including: system requirements, domains to allow, and IdP proxy requirements.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Browser | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

### System Requirements

**Windows**

-   Windows 10 64-bit - ARM (A64) is supported.
    
    Effective October 14, 2025, Microsoft will discontinue support for Windows 10. After this date, they will no longer provide security updates, bug fixes, technical support, or feature enhancements.
    
-   Windows 11 64-bit - ARM (A64) is supported.
    
-   No admin privileges are required
    

**macOS**

-   macOS Monterey 12.0 or later.
    
-   Intel x86 or Apple M1 and above
    
-   No admin privileges are required
    

**Linux**

-   Ubuntu 22.04.5 LTS or later
-   Fedora 41 or later
-   IGEL OS12 or later
-   Architecture - x64
    
    Prisma Browser Linux deployment requires installation with Sudo permissions
    

**Android**

-   Android 12 and above with all security updates
    

**iOS**

-   iOS 18 and above.
    

### For Prisma Access Customers

-   Dataplane (PANOS): 10.2.9-h7, 10.2.4-h17, 10.2.10, 11.2.1
-   PA Infrastructure: 5.1.1
-   Panorama: 10.2.4 and above
-   Cloud Services Plugin: 5.1.0-h15

### Domains to Allow

The Prisma Browser communicates with several domains.

**SSL/TLS Inspection Requirement**

**DO NOT** enable SSL/TLS inspection for domains communicating with the Prisma Browser.

Prisma Browser uses certificate pinning for critical security. Network security infrastructure (Firewalls, Proxies, VPNs) that attempts to inspect traffic acts as a "Man-in-the-middle" by stripping the authentic Prisma Browser certificate and replacing it with its own external certificate.

Prisma Browser is designed to immediately detect and verify this behavior, resulting in the **termination of the connection to the browser** to prevent a potential security breach. This action is mandatory to maintain the integrity and security of the browser.

**Required Action:**

These domains must be added to your SSL Decryption Exclusion list. (SSL/TLS Bypass)

Please select your region:

-   [US Region](/content/techdocs/en_US/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-us.html#us-region)
-   [EU Region](/content/techdocs/en_US/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-eu.html#eu-region)
-   [UK Region](/content/techdocs/en_US/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domain-to-allow-uk.html#uk-region)
-   [JP Region](/content/techdocs/en_US/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-jp.html#jp-region)
-   [AU Region](/content/techdocs/en_US/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-au.html#au-region)
-   [SGP Region](/content/techdocs/en_US/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-sgp.html#sgp-region)
-   [CA Region](/content/techdocs/en_US/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-ca.html#ca-region)
-   [IN Region](/content/techdocs/en_US/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-in.html#in-region)
-   [ID Region](/content/techdocs/en_US/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-ind.html#ind-region)
-   [Fedramp Moderate](/content/techdocs/en_US/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-fedramp-moderate.html#domains-to-allow-fedramp-moderate)

## US Region

The following domains are for clients in the US region.

The following domains are for clients in the US region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   api.wildfire.paloaltonetworks.com
-   wildfire.paloaltonetworks.com
-   cie-api-proxy.us.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.talon-sec.com
-   login.talon-sec.com
-   ext-proxy.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.talon-sec.com
-   auth.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com

## EU Region

The following domains are for clients in the EU region.

The following domains are for clients in the EU region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   de.api.wildfire.paloaltonetworks.com
-   de.wildfire.paloaltonetworks.com
-   cie-api-proxy.eu.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.eu.talon-sec.com
-   login.eu.talon-sec.com
-   ext-proxy.eu.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.talon-sec.com
-   auth.eu.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com

## UK Region

The following domains are for clients in the UK region.

The following domains are for clients in the UK region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   uk.api.wildfire.paloaltonetworks.com
-   uk.wildfire.paloaltonetworks.com
-   cie-api-proxy.uk.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.uk.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.uk.talon-sec.com
-   users-assets.uk.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com

## JP Region

The following domains are for clients in the JP region.

The following domains are for clients in the JP region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   jp.api.wildfire.paloaltonetworks.com
-   jp.wildfire.paloaltonetworks.com
-   cie-api-proxy.jp.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.jp.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.jp.talon-sec.com
-   users-assets.jp.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com

## AU Region

The following domains are for clients in the AU region.

The following domains are for clients in the AU region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   au.api.wildfire.paloaltonetworks.com
-   au.wildfire.paloaltonetworks.com
-   cie-api-proxy.au.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.au.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.au.talon-sec.com
-   users-assets.au.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com

## SGP Region

The following domains are for clients in the SGP region.

The following domains are for clients in the SGP region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   sg.api.wildfire.paloaltonetworks.com
-   sg.wildfire.paloaltonetworks.com
-   cie-api-proxy.sg.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.sgp.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.sgp.talon-sec.com
-   users-assets.sgp.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com

## CA Region

The following domains are for clients in the CA region.

The following domains are for clients in the CA region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   ca.api.wildfire.paloaltonetworks.com
-   ca.wildfire.paloaltonetworks.com
-   cie-api-proxy.ca.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.ca.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.ca.talon-sec.com
-   users-assets.ca.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com

## IN Region

The following domains are for clients in the IN region.

The following domains are for clients in the IN region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   in.api.wildfire.paloaltonetworks.com
-   in.wildfire.paloaltonetworks.com
-   cie-api-proxy.in.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.in.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.in.talon-sec.com
-   users-assets.in.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com

## ID Region

The following domains are for clients in the ID region.

The following domains are for clients in the ID region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   id.api.wildfire.paloaltonetworks.com
-   id.wildfire.paloaltonetworks.com
-   cie-api-proxy.id.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.id.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.id.talon-sec.com
-   users-assets.id.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com

## FedRAMP Moderate

The following domains are for clients in the FedRAMP Moderate domain.

The following domains are for clients in the FedRAMP Moderate domain only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   api.pubsec-cloud.wildfire.paloaltonetworks.com
-   pubsec-cloud.wildfire.paloaltonetworks.com
-   cie-api-proxy.gov.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.gov.talon-sec.com
-   assets.gov.talon-sec.com
-   users-assets.gov.talon-sec.com
-   releases.talon-sec.com

Refer to the FedRAMP documentation for a complete list of supported [FedRAMP Moderate and High FQDNs](https://docs.paloaltonetworks.com/fedramp/prisma-sase/fedramp-moderate-and-high-requirements/fedramp-moderate-and-high-fqdns).

### For SSO Enforcement or Private App Access

For SSO Enforcement or Private App Access, you need to white-list **\*.prismaaccess.com**.

For SSO Enforcement, refer to [IP-Based Enforcement Using an Authentication Gateway](https://docs.paloaltonetworks.com/prisma-access-browser/integrations/first-party-integrations/ip-based-enforcement-using-an-authentication-gateway).

### For Prisma Access Customers Leveraging SSH/RDP/VNC Connections

\*.panwpra.com

### Prisma Browser Ecosystem and Identity Providers

The Prisma Browser ecosystem is designed to integrate with all modern Identity Providers (IdP), including:

-   **Microsoft Entra ID**
-   **Okta**
-   **Google Workspace**
-   **PingOne**
-   **PingFederate**

The Prisma Browser does not support older versions of ADFS. Authentication may fail if the ADFS server blocks calls to the IdP page.

### Required Attributes for IdP Integration

For successful synchronization of users and groups, the IdP must populate specific attributes into the **Cloud Identity Engine (CIE)**. The following attributes are mandatory:

-   For Group Synchronization:
    -   **Common-Name:** The group's display name.
    -   **Unique Identifier:** The group's ObjectGUID.
-   For User Synchronization:
    -   **Common-Name:** The user's display name.
    -   **Unique Identifier:** The user's ObjectGUID.
    -   **Mail:** The user's email address.
    -   **User Principal Name (UPN):** The user's UPN.