---
title: "Login Controls"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules/login-controls"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Rules > Manage Prisma Browser Access and Data Control Rules > Login Controls"
updated: "Mar 12, 2026"
---

# Login Controls
The new login controls for Access and Data Control Rules

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

The Login controls page allows you to control logging into applications and websites using the Prisma Browser.

The form-based login control - manages the way users specified in the scope of the rule can login to websites using any login form that includes a username field that needs to be specified by the user.

Select the login method to see the configuration method:

-   [Login Form](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules/login-controls/login-form.html)
-   [Passkey Login](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules/login-controls/passkey-login.html)