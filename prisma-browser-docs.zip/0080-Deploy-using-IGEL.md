---
title: "Deploy using IGEL"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/deploy-prisma-access-browser/deploy-using-igel"
depth: 3
breadcrumbs: "Home > Prisma Browser > Deploy the Prisma Browser via MDM > Deploy using IGEL"
updated: "Tue Feb 10 06:48:28 PST 2026"
---

# Deploy using IGEL
deploy PAB using IGEL

Prisma Browser installation and update over IGEL OS is performed via the **IGEL App Portal**. For more information, refer to the [IGEL App Portal](https://app.igel.com/).