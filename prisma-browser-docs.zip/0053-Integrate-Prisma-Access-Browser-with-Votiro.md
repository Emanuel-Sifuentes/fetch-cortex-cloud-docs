---
title: "Integrate Prisma Access Browser with Votiro"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/integrate-prisma-access-browser-with-votiro"
depth: 2
breadcrumbs: "Home > Prisma Browser > Integrate Prisma Access Browser with Votiro"
updated: "Tue Feb 10 06:48:41 PST 2026"
---

# Integrate Prisma Access Browser with Votiro
Integrate the Prisma Access Browser with Votiro to scan and sanitize files that your users download or upload using the Prisma Access Browser.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Access Browser | Prisma Access with Prisma Access Browser bundle license or Prisma Access Browser standalone license; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html); Votiro |

You can integrate the Prisma Access Browser with Votiro to protect your organization from zero-day and undisclosed attacks by sanitizing files that your Prisma Access Browser users download or upload. Using Votiro's file sanitization technology, you can ensure that every downloaded or upload file in the Prisma Access Browser is free from threats.

After you configure the Vitiro integration, your Prisma Access Browser users will be able to use it as a file scanning engine. For more information, refer to [Malicious File Protection](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls).

1.  Obtain the Votiro token.
    
    1.  Sign in to the Votiro management UI as the administrator.
        
    2.  Go to ConfigurationService Tokens.
        
    3.  Create a new integration and copy the generated token to the clipboard.
        
    
2.  Enable the Votiro integration in Strata Cloud Manager.
    
    1.  Go to ManageConfigurationPrisma Access BrowserAdministrationIntegrationsServices.
        
    2.  Scroll to Votiro Integration and expand it.
        
    3.  Click Enabled, then enter the Votiro URL and Votiro Token that you obtained.
        
    4.  Click Save.