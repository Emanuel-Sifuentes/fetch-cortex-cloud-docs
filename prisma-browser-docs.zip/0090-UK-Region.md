---
title: "UK Region"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domain-to-allow-uk"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Browser Prerequisites > UK Region"
updated: "Tue Feb 10 06:48:12 PST 2026"
---

# UK Region
The following domains are for clients in the UK region.

The following domains are for clients in the UK region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   uk.api.wildfire.paloaltonetworks.com
-   uk.wildfire.paloaltonetworks.com
-   cie-api-proxy.uk.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.uk.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.uk.talon-sec.com
-   users-assets.uk.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com