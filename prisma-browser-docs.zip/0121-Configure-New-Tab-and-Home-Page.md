---
title: "Configure New Tab and Home Page"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-new-tab-and-home-page"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Customization Controls > Configure New Tab and Home Page"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure New Tab and Home Page
New tab and home page configuration

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Browser Customization – New Tab and Home Page

### New Tab Page

Mobile Browser - **Full support**

This feature allows you to set the type of page that is displayed whenever a user opens the Prisma Browser or a new tab. This will help you create a unified look and feel across company resources.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select New Tab Page.
    
3.  Select one of the following options:
    
    -   **Prisma Browser New Tab** - Use the default page that is included with the browser when it installs.
        
    -   **Custom URL**\- Enter the URL of the selected new tab in the format
        
        https://www.example.com.
        
    
4.  Click Set.
    

### Home Page

Mobile Browser - **Full support**

This feature allows you to set a default homepage for the browser. This page will appear whenever a user opens the Prisma Browser home page. This will help you create a unified look and feel across company resources.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Home Page.
    
3.  Select one of the following options:
    
    -   **Configured by user** - Allow the users to select their own home page.
        
    -   **Prisma Browser New Tab Page** - Use the default homepage that is included with the browser when it installs.
        
    -   **Custom URL**\- Enter the URL of the selected homepage in the format
        
        https://www.example.com.
        
    
4.  Optionally, select the option to **Show home button on toolbar**.
    
5.  Click Set.
    

### Managed Shortcuts

Mobile Browser - **Full support**

To improve the efficiency for the users, the Prisma Browser allows you to configure applications and URLs that will appear on the homepage. In most cases, these will be applications that will be the ones most commonly needed by users in their day-to-day routine. You have the ability to enter a specific URL, a name, and a customized icon, if desired.

These links will also appear on the browser bookmark under **Company Shortcuts**.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Managed Shortcuts.
    
3.  Select one of the following options:
    
    -   **No Shortcuts** - Do not include any managed shortcuts on the homepage.
        
    -   **Set Shortcuts** - Click Add shortcut to add managed shortcuts to the homepage.
        
        1.  Enter the URL.
            
        2.  Enter a Name for the shortcut.
            
        3.  Optionally select an icon for the shortcut. If no icon is selected, the website’s Favicon will be used.
            
    
4.  Click Set.
    

### Background Image

Mobile Browser - **Partial support**

This feature allows you to select a custom background image for the Prisma Access Browser homepage.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Background Image.
    
3.  Select one of the following options:
    
    -   **Default background** - Use the default background image that is included with the browser when it installs.
        
    -   **Dark background** - Use a dark background image.
        
    -   **Light background** - Use a light background image.
        
        The light background is not supported in the Prisma Browser for Mobile.
        
    
4.  If you do not want to use a background image, select **No Background Image**.
    
5.  **Set Background image**\- Drag and Drop the Enter the URL of the selected homepage in the format.
    
    1.  Select a file to use as the background image. The image should best conform to the following guidelines:
        
        -   File format - PNG or JPEG.
            
        -   Image size 2560 px wide x 1440 px height.
            
        -   Maximum file size - 3 MB
            
    
6.  If you want to see how the Background image will be displayed on different devices, click the appropriate device in the **Image preview** section..
    
7.  You can either use the default filter option, or select a custom filter.
    
8.  Select the checkbox if you want to use the Color White Logo option. This will make the logo stand out on the homepage.
    
9.  Click Set.
    

### Admin Messages

Mobile Browser - **No support**

In many organizations, there is a challenge getting a message to all employees. The Prisma Browser offers a system for displaying messages on the homepage. The messages are displayed in a carousel - type display.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Admin Messages.
    
3.  Select one of the following options:
    
    -   **No admin messages** \- Do not display admin messages.
        
    -   **Set admin message**\- Click **Add Admin Message** and enter the following information:
        
        -   Select a **Title** for the message.
            
        -   Enter the **Message** text. The message size is limited to 1000 characters, and can also include links.
            
        -   **Add Link** - Optionally, add a link that will display on top of the message
        -   Click **Add**.
            
    
4.  On the main page, click **Set**. The message will be displayed on the homepage.
    

### Custom Notice

Mobile Browser - **Full support**

Only Prisma Browser for Mobile supports this feature.

Similar to Admin messages, this control allows you to send a message to all users who are using the Prisma Browser for Mobile.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Custom Notice.
    
3.  Select one of the following options:
    
    -   **Show notice** \- Display a custom notice for Prisma Browser for Mobile users.
        
        -   Select the frequency of the notice, ranging from **Only once** to **Every 30 days**. The default is **Every 7 days**.
            
            **Note:** If you uninstall and reinstall the browser, the frequency count restarts.
            
        -   Enter a **Title** for the message.
            
        -   Enter a **Description** for the message. The message is limited to 360 characters.
            
    -   **Don’t Show Notice** - Do not display a custom message to Prisma Browser for Mobile users.
        
    -   **Set admin message**\- Click **Add Admin Message** and enter the following information:
        
    
4.  Click Set.