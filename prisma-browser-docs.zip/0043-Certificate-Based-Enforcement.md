---
title: "Certificate-Based Enforcement"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/certificate-based-enforcement"
depth: 2
breadcrumbs: "Home > Prisma Browser > Certificate-Based Enforcement"
updated: "Tue Feb 10 06:48:41 PST 2026"
---

# Certificate-Based Enforcement
Ensure that access to Certificate-enabled applications is only possible from the Prisma Browser

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Browser | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Google Workspace Certificate Enforcement

This feature ensures that access to applications integrated with Google Workspace is only possible using the Prisma Browser.

Prisma Access comes with a dedicated Public Key Infrastructure (PKI) used for enforcement. Once enabled, each browser is provisioned with a dedicated, unique client certificate issued by the PKI (each tenant has a unique root CA used to sign the client certificates). Certificate enforcement ensures login to the identity provider is only allowed when the client certificate signed by the dedicated root CA is provided.

You need to set up the following prerequisites before configuring this option:

-   Google Workspace Context-Aware Access feature, available for Enterprise or Education accounts, or with Cloud Identity Premium.
-   Setting up SSO Authentication for Prisma Access with Group.

1.  Obtain the Prisma Browser Access root Certificate
    
    1.  Go to the Prisma Browser Management Console and select **Administration > Integration**.
    2.  Select and Enable **Google Workspace Integration**.
    3.  In the first section, click **Prisma Access Certificate** to download the unique tenant root certificate.
    
2.  Add the Prisma Browser Certificate to Google Workspace
    
    1.  Go to [Google Admin Console > Devices > Networks](https://admin.google.com/ac/networks).
    2.  Click on **Certificates**, then **Add Certificate** and upload the Prisma Access certificate.
    3.  Check the **Endpoint Verification** option and click **Add**.
    
3.  Add the Prisma Browser Certificate to Google Workspace
    
    1.  Go to **Google Admin Console -> Security -> Access and data control -> Context-Aware Access**.
    2.  Make sure that **Turn On** is selected.
    3.  Click **Access levels**, then select **Create new access level.**
    4.  Enter a Name for the Access Level. We recommend that you call it **Prisma Browsers**.
    5.  Click the **Advanced** tab and paste the text found at the end of section 2 on the instructions on the page. The following is **sample** text.
        
        ```
        device.certificates.exists(cert,
        ```
        
        ```
        cert.is\_valid && cert.root\_ca\_fingerprint ==
        ```
        
        ```
        "3HiBH90JUEGvo6kwGJxbkfKeD7pQAcqTzQLbCGH+t0s")
        ```
        
    
4.  Assign the New Access Level to Apps
    
    1.  Go to **Google Admin Console -> Security -> Access and data control -> Context-Aware Access**.
    2.  Click **Assign access levels**.
    3.  Select one or more apps from the list and click **Assign**.
    4.  Check the newly-created **Prisma Browsers** access level (the name that you created in step 2, above).
    
5.  Validation
    
    1.  Install the Prisma Browser.
    2.  Wait while the new Google Workspace configuration occurs; this usually takes approximately 5 minutes.
    3.  Perform a successful sign-in to an assigned app from Prisma Browser. Attempt to sign -in to the same application from a different browser. It shouldn't succeed.