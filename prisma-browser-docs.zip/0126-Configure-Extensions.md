---
title: "Configure Extensions"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-extensions"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Security Controls > Configure Extensions"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure Extensions
Configure Browser Security Extensions

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Allowed or Blocked Extensions

Mobile Browser - **No support**

Allowed or Blocked Extensions give you control over which extensions are permitted in the Prisma Browser.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Allowed or Blocked Extensions.
    
3.  Select one of the following options:
    
    -   **Allow all** - Allow all extensions.
        
    -   **Block specific extensions by ID or Risk** - You can select specific extensions to block. The extension must be identified either by its **ID** or its **Risk**.
        
    -   **Allow specific extensions by ID** - You can select specific extensions to permit. The extension must be identified by its ID.
        
    -   **Block all** - block all extensions.
        
    
4.  Click Set.
    

## Block Extensions by Permission

Mobile Browser - **No support**

This control allows you to block extensions based on their required permissions.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Block Extensions by Permission.
    
3.  Select one of the following options:
    
    -   **Grant all permissions** - permit running extensions without regard to their required permissions.
        
    -   **Block extensions that use specific permissions** - block that requires specific permissions. Permissions that were not selected will be permitted. You can select as many permissions as required.
        
    
4.  Click Set.
    

## Restrict Extension Host Permissions

Mobile Browser - **No support**

This control allows you to restrict Host permissions for extensions.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Restrict Extension Host Permissions.
    
3.  Select one of the following options:
    
    -   **Enable** - Enable restricting Extension Host Permissions.
        
    -   **Enable for specific domains** - Enable restricting host permissions for specified domains only.
    -   **Disable** - Disable restricting Extension Host Permissions.
        
    
4.  Click Set.
    

## Restrict Extension Host Permissions

Mobile Browser - **No support**

This control allows you to hide sensitive data - any data that can compromise user information and be used for illicit logins - from extensions.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Restrict Extension Host Permissions.
    
3.  Select one of the following options:
    
    -   **Enable** - prevent extensions from running scripts and accessing content.
        
    -   **Enable for specific domains** - prevent extensions from running scripts and accessing content from specific domains. Click [here](https://developer.chrome.com/docs/extensions/mv3/match_patterns/) to see information regarding domain syntax.
        
    -   **Disable** - do not prevent extensions from running scripts and accessing content.
        
    
4.  Click Set.