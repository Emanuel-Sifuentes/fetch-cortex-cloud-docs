---
title: "IP-Based Enforcement Using an Authentication Gateway"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/first-party-integrations/ip-based-enforcement-using-an-authentication-gateway"
depth: 3
breadcrumbs: "Home > Prisma Browser > First-Party Integrations > IP-Based Enforcement Using an Authentication Gateway"
updated: "Feb 10, 2026"
---

# IP-Based Enforcement Using an Authentication Gateway
IP-based enforcement Using the Authentication Gateway.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Browser | Prisma Access with Prisma Access Browser paid and production tenants only; Role: Superuser, with full read-write access. [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

IP-based enforcement enables you to restrict access to your applications by ensuring that authentication traffic originates only from authorized Prisma Access Browser egress IP addresses.

Existing customers using the shared Authentication Gateway, refer to the Migration Guide for existing Customers, below.

## Platform Support

IP-based enforcement supports both Prisma Access Browser (PAB) and Prisma Access Mobile Browser, providing consistent protection across desktop and mobile platforms.

## How it Works

The IP-based enforcement feature works through a simple yet effective mechanism:

1.  **The Authentication Gateways serves as a forward proxy**: The Authentication Gateways functions as a forward proxy with a set of predictable, dedicated IP addresses specific to your tenant.
2.  **Configured traffic routing**: The browser’s configuration routes IdP authentication traffic through the Prisma Access Browser gateway.
3.  **IdP conditional access**: You establish conditional access rules in your identity provider to only enable authentication from your dedicated Authentication Gateway egress IP addresses.
4.  **Enforced access control**: As a result, authentication attempts from browsers other than PAB will fail, effectively restricting access to your protected applications.

### Key Benefits

-   **Dedicated tenant-specific egress IPs**: Your tenant receives unique IP addresses not shared with other customers.
-   **Multitenant validation**: Easily verify traffic from specific tenants, even when managing multiple tenants.
-   **Regional availability**: Available in strategic global locations with automatic failover protection.

### Supported Regions

IP-based enforcement is available in the following GCP compute regions:

-   us-east4 (Ashburn, Virginia)
-   us-west1 (Portland)
-   europe-west2 (London)
-   europe-west3 (Frankfurt)
-   Asia-south1 (Mumbai)
    
    IP-based enforcement operates across all five regions by default, and the system doesn’t allow selecting individual regions.
    

### Configuration Steps

1.  Configure dedicated Egress IP Addresses
    
    1.  From the Strata Cloud Manager, go to Workflow → Prisma Browser → SSO Enforcement.**Configuration → Onboarding → Prisma Access Browser → View**.
        
    2.  Click **Create Dedicated Egress IP Addresses**.
        
        This process can take a few minutes until the IP Addresses are available in all regions.
        
    3.  Copy the list of generated IP addresses for use in your IdP configuration,
        
    
2.  Configure your Identity Provider (IdP)
    
    1.  Select your IdP provider from the list of supported providers and click **Save**:
        
        -   [Okta](/content/techdocs/en_US/prisma-access-browser/integrations/ip-based-enforcement.html#ip-based-enforcement_task-qhf_wv4_tcc)
        -   [Microsoft Azure Active Directory](/content/techdocs/en_US/prisma-access-browser/integrations/ip-based-enforcement.html#ip-based-enforcement_task-sy5_wqp_tcc)
        -   [PingID](/content/techdocs/en_US/prisma-access-browser/integrations/ip-based-enforcement.html#ip-based-enforcement_task-cl4_xw1_vcc)
        -   [VMware Workspace One Access](/content/techdocs/en_US/prisma-access-browser/integrations/ip-based-enforcement.html#ip-based-enforcement_task-i4k_jfg_vcc)
        -   [OneLogin](/content/techdocs/en_US/prisma-access-browser/integrations/ip-based-enforcement.html#ip-based-enforcement_task-sbh_jls_5cc)
        
    2.  In case your IdP does not appear on the list or you're using a custom IdP, contact Support or your Account team to configure your custom IdP URL. If you use multiple identity providers, you can select more than one from the list.
        
    3.  Follow the specific instructions for your selected IdP to configure conditional access with your dedicated egress IP addresses.
        
    
3.  Enable Authentication Traffic Routing
    
    1.  Toggle the **Authentication Traffic Routing** switch to enable the feature.
        
        If you use **Shared Authentication Gateway**, continue with the Migration Guide for existing Customers (below).
        
    2.  Validate the configuration by logging into an enforced application in your IdP:
        
        -   Test using a commercial browser - the system should deny access.
        -   Test using the Prisma Access Browser - the system should grant access.
        
    

### Migration Guide for Existing Customers

If you're already using IP address-based enforcement with shared IP addresses, follow these steps to migrate to dedicated IP addresses:

1.  **Access the New Interface**: The Admin Console will display a new dedicated IP address tab.
2.  **Create Unique IP addresses**: Generate your tenant-specific dedicated IP addresses.
    
3.  **Update IdP**: Add the new IP addresses to your IdP's conditional access policy rule.
4.  **Switch Enforcement Method**: Change to “Dedicated IP addresses” in the web interface, and click **Save**.

**Important Migration Notes:**

-   When migrating, keep the original shared IP addresses in your IdP's configuration as a fall back.
-   If you encounter issues with the new configuration, you can temporarily switch back to shared IP addresses in the admin console.
    
    Mobile browsers with versions older than \[1.5093 for iOS, 1.5096 for Android\] will continue using the old shared IP addresses until upgraded to the minimum supported version.
    

### Troubleshooting

If you encounter issues with IP-based enforcement:

-   Check your browser's troubleshooting page. :
    -   Click the Prisma Access Browser Extension icon in the menu bar.
        
    -   Click the shield icon.
        
    -   Open the **Authentication Gateway** section.
    -   Ensure that the **Status** shows **Configured**, and that no errors appear.
    -   Click **Test Connectivity**. Follow the instructions as needed.
        
-   Ensure that you have correctly configured the IP addresses in your IdP.
-   Turn on the Authentication Traffic Routing toggle.
-   If the issues persist, contact **Support**.

### Frequently Asked Questions (FAQ)

**Q: How long does it take for dedicated IP addresses to become available?**

A: The process typically takes a few minutes to complete across all supported regions.

**Q: Can I use the same IP addresses across multiple tenants?**

A: No, each tenant receives unique dedicated IP addresses to ensure proper isolation and security. For organizations managing multiple tenants, including all relevant IP addresses in the conditional access configuration is crucial.

**Q: How long will the IP addresses remain reserved?**

A: The system allocates your dedicated IP address to your tenant for as long as your tenant remains active as long as the **Dedicated IP Addresses** feature is enabled.

**Q: Which platforms support the Authentication Gateway?**

A: The feature is available for both Prisma Access Browser for desktop and mobile.

**Q: What is the expected behavior if the dedicated Authentication Gateways is configured, but the user has an old browser version?**

A: Old browser versions will keep sending traffic to the legacy Authentication Gateway (“shared proxy”) until the browser is up to date. For desktop browsers, the extension version should be automatically updated immediately after the next browser launch. For the Mobile Browser, ensure that users update to a supported version.

**Q: What does the traffic flow look like if I configure “route all traffic to Prisma Access”?**

A: When you enable the authentication routing, the authentication traffic will be routed through the authentication proxy regardless of the general traffic routing to Prisma Access.

**Q: What happens if a region becomes unavailable?**

A: The system or browser automatically routes users to the second-nearest available region to maintain service continuity.

**Q: Can I see all the Traffic logs in SLS?**

A: Currently this isn’t available.

**Q: My tenant is in a different region than the Authentication Gateways. What will happen?**

A: Authentication traffic will be routed through the region nearest to the user.

**Q: Can I use a dedicated authenticated gateway with an Eval/Lab license?**A

: The creation of dedicated egress IP addresses is a feature of paid subscriptions. If you're on a trial or require access through a different arrangement, contact your account team.