---
title: "Live Page Scanning"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/live-page-scanning"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Data Controls > Live Page Scanning"
updated: "Mar 12, 2026"
---

# Live Page Scanning
Live Page Scanning - AB

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Prisma Browser | Refer to the Prerequisites and Scope section below. |

Advanced Web Protection (Live Page Scanning) is a new capability within Prisma Browser’s web protection module. It provides real-time, in-browser analysis to protect your users against advanced web-based threats, including patient-zero attacks and evasive "last-mile" assembly attacks. This feature offers deep browser-level visibility into page runtime and inspects all traffic, including QUIC and SSL-pinned applications, without requiring decryption.

-   Protect users on **managed and unmanaged devices** (BYOD, contractor devices)
    
-   Inspect **encrypted traffic** and apps that cannot be decrypted via traditional network inspection
    
-   Detect advanced threats that bypass **inline network analysis**, including obfuscated scripts, SaaS platform abuse, and browser-in-browser attacks
    
-   Reduce the **patient-zero effect**, ensuring malicious sites are flagged before users are impacted
    
-   Maintain **end-user productivity** through real-time notifications, read-only access, or custom messaging during scanning
    

LPS leverages **browser-based execution** of detection models to emulate the endpoint experience, providing superior visibility into dynamic web content that traditional network-based analysis cannot inspect.

## Detection and Enforcement Behavior

-   **Browser-based detection flow**: The Browser forwards content to the AURL Extension for local inspection using pre-trained models.
-   Local vs. Cloud Analysis:
    -   **High-confidence threats** are blocked locally without cloud interaction.
    -   **Low-confidence detections** are forwarded to AURL Hex Cloud for additional analysis while allowing the page to load asynchronously.
-   Enforcement types:
    -   **Inline enforcement**: Requests are blocked once LPS determines that there is malicious content. until scanning completes.
    -   **Async enforcement**: Page loads while scanning occurs in the background.
-   **Patient-zero mitigation**: All URLs scanned in-browser feed data back to the AURL intelligence database to enhance future threat detection.

## Prerequisites and Scope

-   **Supported platforms** - Prisma Browser on Windows, macOS.
-   **Browser Support** - Prisma Browser 142.33.4.176or later.
-   **Prisma Browser Console** - Access required to configure policies and notifications.
-   **Network requirements** - Optional cloud communication for low-confidence detections, telemetry, and model updates.
-   **Whitelist url** - You need to whitelist the following url: [http://hex-prod-us.urlcloud.paloaltonetworks.com/](http://hex-prod-us.urlcloud.paloaltonetworks.com/)

## Admin Console Configuration

Notify users of ongoing scans, display pages in read-only mode if needed, and maintain workflow continuity.

**Enable LPS**

Once LPS is enabled, it can take up to 24 hours to take effect for your end-users.

1.  Navigate to PolicyControlsAccess & Data Control PoliciesThreat Protection.
    
2.  Locate **Live Page Scanning**.
    
3.  **Enable** Live Page Scanning.
    

5.  Create a new Access & Data Control rule, Include the Live Page Scanning Control, and configure the following:
    
    1.  **Scope** - Select the appropriate Users, User Groups, and Device Groups. You can also select Networks, Public IP and Geolocation.
        
    2.  **Applications** - Select the applications that will be included in the Live Page Scan.
        
    

## Event Reporting and Visibility

A new scan engine, **Live Page Scanning**, is now available. This scan type appears in web access events when users open defined applications. It also shows up in incidents when the Live Page Scanning engine detects malicious activity.

-   **Immediate incident events**: Include attack type, URL, timestamp, and enforcement action.
-   Event viewer / dashboards:
    -   Displays detections and scan results.
    -   Allows filtering by user, URL, category, or threat type.

## End User Experience

If a threat is detected, the page is fully blocked - even when the user scrolls.

The policy indicator will display in the omnibox (the address bar).

To ensure maximum security, Live Page Scanning leverages more system memory for real-time analysis.