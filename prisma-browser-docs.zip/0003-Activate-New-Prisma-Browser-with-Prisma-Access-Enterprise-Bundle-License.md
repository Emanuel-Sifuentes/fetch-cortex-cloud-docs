---
title: "Activate New Prisma Browser with Prisma Access Enterprise Bundle
        License"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/activate-new-prisma-access-browser-with-prisma-access-enterprise-bundle-license"
depth: 2
breadcrumbs: "Home > Prisma Browser > Activate New Prisma Browser with Prisma Access Enterprise Bundle
        License"
updated: "Feb 2, 2026"
---

# Activate New Prisma Browser with Prisma Access Enterprise Bundle
        License
Learn how to activate your Cloud Managed or Panorama Managed Prisma Access Secure Enterprise Browser (Prisma Browser) with Prisma Access bundle license through Common Services.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Panorama | Activation link for your product ; Strata Logging Service (SLS) is needed for activation ; Cloud Identity Engine (CIE) is included and spun up during activation ; Customer Support Portal account |

See the [prerequisites](https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites.html) before you begin this task.

-   [Cloud](/content/techdocs/en_US/prisma-access-browser/activation-and-onboarding/activate-new-prisma-access-browser-with-prisma-access-enterprise-bundle-license/activate-cloud-managed-prisma-access-browser-bundle-license.html#cloud-managed-pab)
-   [Panorama](/content/techdocs/en_US/prisma-access-browser/activation-and-onboarding/activate-new-prisma-access-browser-with-prisma-access-enterprise-bundle-license/activate-panorama-managed-prisma-access-browser-bundle-license.html#panorama-managed-pab)

## Cloud Managed Prisma Browser Bundle License

Learn how to activate your Cloud Managed Prisma Access Secure Enterprise Browser (Prisma Browser) tenants through Common Services.

After you receive an email from Palo Alto Networks identifying the license you're activating, use the activation link to begin the activation process.

1.  Select Activate Subscription in your email.
    
2.  Follow the instructions for [activating a Prisma Access license](https://docs.paloaltonetworks.com/common-services/subscription-and-tenant-management/cloud-managed-prisma-access-and-add-ons-license-activation/activate-a-license-for-cloud-managed-prisma-access-and-add-ons), [allocating a Prisma Access license](https://docs.paloaltonetworks.com/common-services/subscription-and-tenant-management/cloud-managed-prisma-access-and-add-ons-license-activation/activate-a-license-for-cloud-managed-prisma-access-and-add-ons/allocate-licenses-cloud-managed-prisma-access), and [planning service connections](https://docs.paloaltonetworks.com/common-services/subscription-and-tenant-management/cloud-managed-prisma-access-and-add-ons-license-activation/activate-a-license-for-cloud-managed-prisma-access-and-add-ons/plan-service-connections-cloud-managed-prisma-access).
    
3.  Continue to Assign the Prisma Access Secure Enterprise Browser Licenses and Add-ons. Products or Add-ons are enabled by default based on your contract.
    
4.  Select the Secure Enterprise Browser with Prisma Access Enterprise.
    
    This is similar to [allocating PA Mobile User licenses](https://docs.paloaltonetworks.com/content/techdocs/en_US/common-services/subscription-and-tenant-management/cloud-managed-prisma-access-and-add-ons-license-activation/activate-a-license-for-cloud-managed-prisma-access-and-add-ons/allocate-licenses-cloud-managed-prisma-access). You will be able to partially allocate and activate Prisma Browser licenses across multiple Prisma Access tenants. For example:
    
    -   You can purchase 5,000 units of Prisma Browser Enterprise Mobile Users.
        
    -   You can allocate:
        
        -   1,000 to a PoC tenant (this is the minimum quantity required)
            
        -   3,000 to a production tenant
            
        -   Leave 1,000 units unactivated for later use
            
    
5.  Go to the Prisma Browser [Admin Guide](https://docs.paloaltonetworks.com/prisma-access-browser/administration/use-the-prisma-access-browser-dashboards) to manage your Prisma Browser.
    
6.  (Optional) Assign roles so your admins can manage the Prisma Browser.
    

## Panorama Managed Prisma Browser Bundle License

Learn how to activate your Panorama Managed Prisma Access Secure Enterprise Browser (Prisma Browser) tenants through Common Services.

After you receive an email from Palo Alto Networks identifying the license you're activating, use the activation link to begin the activation process.

Not available for Panorama multitenancy.

1.  Select Activate Subscription in your email.
    
2.  Follow the instructions for [activating a Prisma Access (managed by Panorama) license](https://docs.paloaltonetworks.com/common-services/subscription-and-tenant-management/panorama-managed-prisma-access-and-add-ons-license-activation/activate-a-license-for-panorama-managed-prisma-access-and-add-ons).
    
3.  Continue to enable the available add-ons. Products or Add-ons are enabled by default based on your contract.
    
4.  Select the Secure Enterprise Browser with Prisma Access Enterprise.
    
5.  In Panorama, go to the Panorama tabCloud Services PluginPrisma Browser tab.
    
    This launches a new tab with a pared-down version of Strata Cloud Manager that has just the Prisma Browser specific views.
    
6.  Go to the Prisma Browser [Admin Guide](https://docs.paloaltonetworks.com/prisma-access-browser/administration/use-the-prisma-access-browser-dashboards) to manage your Prisma Browser.
    
7.  (Optional) Assign roles so your admins can manage the Prisma Browser.