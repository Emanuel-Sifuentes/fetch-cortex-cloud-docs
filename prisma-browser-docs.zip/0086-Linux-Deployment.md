---
title: "Linux Deployment"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/prisma-access-browser-update-mechanics/linux-deploymwnt"
depth: 3
breadcrumbs: "Home > Prisma Browser > Installers and Updates > Linux Deployment"
updated: "Tue Feb 10 06:48:28 PST 2026"
---

# Linux Deployment
These are the Linux deployment methods

Prisma Access Browser update for the supported Linux distributions is performed via software packages update, together with the entire installed software packages, as part of the packager repository update.

For more information, refer to [Deploy using Linux](/content/techdocs/en_US/prisma-access-browser/deployment/deploy-prisma-access-browser/deploy-using-linux.html).