---
title: "Configure Data Leak Prevention"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/configure-data-leak-prevention"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Data Controls > Configure Data Leak Prevention"
updated: "Mar 12, 2026"
---

# Configure Data Leak Prevention
The Data Leak Prevention Controls

## File Download

Mobile Browser - **Partial support**

For detailed information in File Downloads using the Prisma Browser for Mobile, refer to the [Prisma Access Mobile Browser information](https://docs.paloaltonetworks.com/prisma-access-browser/deployment/prisma-access-mobile-browser?otp=concept-r2j_yym_ldc#concept-r2j_yym_ldc)

File Download control provides multiple capabilities related to downloading files from websites that match a specified URL, application, or website classification. To set the File Download control:

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsData Controls
    
2.  Select File Download.
    
3.  Select one of the following options:
    
    -   Allow - the Prisma Browser will allow all downloads.
        
    -   Allow (Protected) – the Prisma Browser will allow downloads that can open only in the browser.
        
        -   Allow to open outside of the browser - users will be able to unprotect the file, allowing viewing and editing of the file using external applications. This includes any browser and any Desktop application.
            
        -   To unprotect a file:
            
            1.  Click the Download History folder link in the Browser bar.
                
            2.  Select the file to open. It will be indicated by a folder with a slash.
                
            3.  Click on the icon to unprotect the file.
    -   **Save to organizational storage** - Users won't be able to download the files directly. Files will be uploaded to the cloud storage that you selected.
        -   **Select provider** - Select the cloud provider from the list. For more information on configuring cloud storage items refer to **Configuration→Prisma Browser →Integrations→Services→Cloud storage**
            
            Be sure to configure the organizational storage before it becomes available to the users. If you did not configure organizational storage, the option is not available.
            
    -   Block - the Prisma Browser will block all downloads.
    -   Apply on:- select between one of the following options:
        -   -   Any file - the download restrictions will apply to all files.
                
            -   Specific files\- the download restrictions will apply to files that meet the selected specifications (the rule can contain as many of these specifications as needed):
                
            
            -   File size - set the size of the file.
                
            -   File types - set the [file types](/content/techdocs/en_US/prisma-access-browser/administration/file-types-per-category.html) that need to match this rule.
                
            -   File hash - set the SHA-256 hash to be matched for this rule.
                
            -   MIP label - set the level of the [MIP label](https://docs.paloaltonetworks.com/prisma-access-browser/integrations/integrate-prisma-access-browser-with-microsoft-information-protection) that can be used to protect contents with sensitive content.
    -   Prompt\- when there is a restriction, select between one of the following options:
        -   None - there will be no prompts.
            
        -   Before download\- inform the user that there is a restriction and how to bypass it.
            
            -   Warn and allow to proceed anyway - informs users about the risk or sensitivity of downloading files but allowing them to continue.
                
            -   Warn and allow to proceed anyway with a reason - informs users about the risk or sensitivity of downloading files and require them to select a reason to continue.
                
            -   Permission request - allows users to send a permission request to the admin. The user will be informed once the [request](https://docs.console.talon-sec.com/en/articles/465) is approved or denied.
    -   Require MFA - Require users to complete an additional authentication (PIN code, passkey, or IdP authentication) before downloading files. Configure the authentication factor used under **[Browser Security > Browser Hardening > Authentication Factor](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-browser-hardening.html#configure-browser-hardening_task-ydp_f2l_hcc)**
    
4.  When you use this control, you can use your own dialog text to replace the default. To set the text, click Set dialog text.
    
5.  Set.
    
    When downloading PDF files - On Android devices, the PDF may briefly appear in the browser viewer before the system blocks the download. On iOS, the download is blocked immediately, and the viewer does not open.
    

## File Upload

Mobile Browser - **Partial support**

For detailed information in File Upload using the Prisma Browser for Mobile, refer to the [Prisma Access Mobile Browser information](https://docs.paloaltonetworks.com/prisma-access-browser/deployment/prisma-access-mobile-browser?otp=concept-r2j_yym_ldc#concept-r2j_yym_ldc)

The File Upload policy controls whether users can upload files that come from websites that match the URL or from a selected application or category.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsData Controls
    
2.  Select File Upload.
    
3.  Select one of the following options:
    
    -   Allow -the Prisma Browser will allow all uploads.
        
    -   Allow protected files only between the rule’s web applications - Protected files sourced from the Web application of this rule. Only previously downloaded protected files from the Web application of this rule can be uploaded.
        
        Requires setting the File Download control to “Allow (Protected)” .
        
    -   Allow only nonprotected files – only nonprotected files from any source can be uploaded.
        
    -   Block \- the Prisma Browser will block all uploads. You can block uploads from specific file extensions. Other extensions will be blocked.
        
    -   Apply on:\- select between one of the following options:
        -   Any file - the download restrictions will apply to all files.
            
        -   Specific files\- the upload restrictions will apply to files that meet the selected specifications (the rule can contain as many of these specifications as needed):
            
            -   File size - set the size of the file.
                
            -   File types - set the [file types](/content/techdocs/en_US/prisma-access-browser/administration/file-types-per-category.html) that need to match this rule.
                
            -   File hash - set the SHA-256 hash to be matched for this rule.
                
            -   MIP label - set the level of the [MIP label](https://docs.paloaltonetworks.com/prisma-access-browser/integrations/integrate-prisma-access-browser-with-microsoft-information-protection) that can be used to protect contents with sensitive content. Install the Microsoft Information Protection integration to use this feature.
    -   Prompt\- when there is a restriction, select between one of the following options:
        -   None - there will be no prompts.
            
        -   Before upload\- inform the user that there is a restriction and how to bypass it.
            
            -   Warn and allow to proceed anyway - informs users about the risk or sensitivity of uploading or downloading files, but allowing them to continue.
                
            -   Warn and allow to proceed anyway with a reason - informs users about the risk or sensitivity of uploading files, and require them to select a reason to continue.
                
            -   Permission request - allows users to send a permission request to the admin. The user will be informed once the request is approved or denied.
    -   Require MFA - Require users to complete an additional authentication (PIN code, passkey, or IdP authentication) before uploading files. Configure the authentication factor used under **[Browser Security > Browser Hardening > Authentication Factor](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-browser-hardening.html#configure-browser-hardening_task-ydp_f2l_hcc)**.
    
4.  When you use this control, you can use your own dialog text to replace the default. To set the text, click Set dialog text.
    
5.  Click Set.
    

## Clipboard

Mobile Browser - **Partial support**

The Clipboard Policy manages copy and paste functions when using the Prisma Browser. This tool allows you to manage Copy & Paste functions. To configure the Clipboard control:

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsData Controls
    
2.  Select Clipboard.
    
3.  Select the control that you need to configure (both controls can be configured):
    
    -   Copy & Paste data out \- Configure whether users are allowed to copy & paste information from the browser to other applications.
        
        -   Allow (anywhere) - Allow the copied data to be pasted to any web application or external process.
            
        -   Block (permit only within the rule's web applications)\- Block copy and paste data out of the rule's web application.
            
            -   Exclude URL address bar – The URL address bar won't be considered as part of the webpage.
                
        -   Prompt\- Select whether you want to display a prompt.
            
            -   None - Don't require a prompt.
                
            -   Before pasting dat1a out to other web applications(Inform the user of the restriction and allow bypassing it).
                
            -   Pop-up Notifications
                
                1.  Warn and allow to proceed anyway.
                    
                2.  Warn and allow to proceed anyway with a reason.
                    
                3.  Permission request - select a Bypass time frame as well.
                    
    -   Copy & Paste data in\- configure whether or not users are allowed to copy & paste information from other web applications or external processes.
        
        -   Allow \- allow the copied data to be pasted from any web application or external process.
            
        -   Block\- don't allow the copied data to be pasted from any web application or external process.
            
        -   Prompt\- select whether you want to display a prompt before pasting data in.
            
            -   None - don't require a prompt.
                
            -   Before pasting data in (Inform the user of the restriction and allow bypassing it)
                
            -   Pop-up notification -
                
                1.  Warn and allow to proceed anyway.
                    
                2.  Warn and allow to proceed anyway with a reason.
                    
                3.  Permission request - select a Bypass time frame as well.
                    
    
4.  When you use this control, you can use your own dialog text to replace the default. To set the text, click Set dialog text.
    
5.  Click Set.
    

## Webpage Data Masking

Mobile Browser - **No support**

This control allows you to mask textual content within webpages. The masking is set according to either predefined information types (PII or PCI) or a custom regex.

When this is enabled, the browser will inspect and mask any webpage or frame within the webpage. This will be done only in situations where the URL in the browser tab or the URL in the frame is matched. To enable Webpage Data Masking:

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsData Controls
    
2.  Select Webpage Data Masking.
    
3.  Select one of the following options:
    
    -   Enable - the Prisma Browser will mask URLs in tabs or frames that match the conditions. Select the masking pattern:
        
        -   Mask all characters.
        -   Leave the last characters unmasked.
        -   Leave the first characters unmasked.
            
            You can choose to unmask up to 4 characters.
            
    -   Disable - the Prisma Browser won't mask URLs in tabs or frames that match the conditions.
        
    
4.  Prompt - Optionally select one of the following prompt options:
    
    -   None - Do not use pop-up notifications.
    -   Pop-up notifications
        -   Warn and allow to proceed anyway - the prompt will freeze the sensitive information until the user acknowledges the message.
        -   Warn and allow to proceed anyway with a reason - the prompt will freeze the sensitive information until the user acknowledges the message and selects a reason.
        -   Permission request - the prompt will freeze and mask the sensitive information until permission is granted.
    
5.  Click Set.
    

## Typing Guard

Mobile Browser - **No support**

Linux/IGEL Browser - **No support**

Scans manual input made by users in real-time within the browser. It operates based on defined rules that can be customized based on specific organizational requirements. To set the Typing Guard control:

Typing guard is only compatible with basic HTML form fields. It may not function on websites that use complex or JavaScript-based input methods. For complete copy-paste protection, please use the clipboard control.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsData Controls
    
2.  Select Typing Guard.
    
3.  Select one of the following options:
    
    -   Enable \- the Prisma Browser will enable the Typing Guard, blocking the users from entering potentially sensitive data to the policy rule's application.
        
    -   Disable \- the Prisma Browser will disable the Typing Guard, and won't block potentially sensitive data.
        
    
4.  Prompt - Optionally select one of the following pop-up options:
    
    -   Warn and allow to proceed anyway - the prompt will freeze the sensitive information until the user acknowledges the message.
        
    -   Warn and allow to proceed anyway with a reason - the prompt will freeze the sensitive information until the user acknowledges the message and selects a reason.
        
    -   Permission request - the prompt will freeze and mask the sensitive information until permission is granted.
    
5.  When you use this control, you can use your own dialog text to replace the default. To set the text, click Set dialog text.
    
6.  Click Set.
    

The new control enables you to control users typing activities within the context of an Access & Data Control rule. This is designed to restrict the specific content definitions of the rule.

1.  In an Access & Data Control rule, go to the When contains section.
2.  Select Specific content and select the appropriate sensitive information for the rules.
3.  Additionally, you can set custom content types to add content that might not be included in the predefined types.
4.  When users try to type in the sensitive information, the sensitive information will be sanitized.

## Webpage Watermarking

Mobile Browser - **Partial support**

Webpage watermarking enhances Data Loss Prevention (DLP) coverage by providing an additional layer of security. While screenshot restrictions can prevent users from capturing on-screen content, they do not prevent the use of external devices, such as smartphones, to take photos of the screen. This feature applies a visible overlay to webpages, serving as a deterrent against unauthorized information sharing. For optimal protection, it is recommended to use webpage watermarking in conjunction with screenshot control.

**Webpage Watermark control** intelligently applies watermarks exclusively to pages identified as containing **sensitive content**, minimizing user friction. This control is active only when you configure the ‘When Contains’ parameter.

The watermark places information on the page, including:

-   Company Logo (if it's configured in the browser customization)
    
-   Company Name (if it's configured in the browser customization)
    
-   User's Email
    
-   Date and Timestamp
    

You can also specify the opacity of the watermark.

To set the Webpage Watermarking control:

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsData Controls
    
2.  Select Webpage Watermarking.
    
3.  Select one of the following options:
    
    -   Enable - The Prisma Browser will display the watermark information to deter users from taking pictures.
        
        1.  Select the Opacity level from the 5 choices:
            
            -   Low
                
            -   Light
                
            -   Standard
                
            -   Medium
                
            -   High
                
        2.  Rotation – Select the rotation of the watermark. The options are -45, 0, or 45 degrees.
            
        3.  Density - Select the density of the watermark. The options are:
            
            -   Low
                
            -   Standard
                
            -   High
                
        4.  Logo color - Select White to display the logo in a single color, or Standard, to display the logo in using its original color when uploaded.
    -   Disable - The Prisma Browser won't display the watermark.
        
    
4.  Click Set.
    

## Print

Mobile Browser - **Partial support**

This feature controls whether or not users can print from websites that match the URL, application, or category in the rule. To set the Print control:

The Print control can also be used to manage File Downloads by printing to a PDF.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsData Controls
    
2.  Select Print.
    
3.  Select one of the following options:
    
    -   Allow \- the Prisma Browser will permit printing of webpages and files opened in the Prisma Access Browser.
        
    -   Block \- the Prisma Browser will block all printing of webpages and files opened in the Prisma Access Browser.
        
    
4.  If you want to enable Prompting notifications when you allow printing, click the down arrow next to Prompt: Pop-up notifications.
    
    The Prompting notifications are not applicable for the Prisma Browser for Mobile.
    
    1.  Configure the following options:
        
        -   **Warn and allow to proceed anyway** - Informs users about the risk or sensitivity of printing files, but allowing them to continue.
        -   **Warn and allow to proceed anyway with a reason** - Informs users about the risk or sensitivity of printing files, and requires them to provide a reason to continue.
        -   **Permission request** - Allows users to send a permission request to the admin. The user will be informed once the [request](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-requests.html) is approved or denied.
            -   Choose the timeframe for the permission. You can configure the permission to be used once, or for a timeframe ranging from 10 minutes to 90 days.
        
    
5.  When you use this control, you can use your own dialog text to replace the default. To set the text, click Set dialog text.
    
6.  Click Set.
    

## Screenshot

Mobile Browser - **Partial support**

Linux/IGEL Browser - **No support**

This feature controls whether or not users can take screenshots (using snipping tools or Print Screen), record the screen, or share the screen with video conferencing tools from websites that match the URL, application, or category in the rule. To set the Screenshot control:

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsData Controls
    
2.  Select Screenshot.
    
3.  Select one of the following options:
    
    -   Allow \- the Prisma Browser will allow screen capture, screen recording, and screen sharing using video conference tools.
        
    -   Allow (Protected) – the Prisma Browser will allow screen captures only from the Prisma Browser's built-in snipping tool. Any other tool will be blocked.
        
    -   Block \- Prisma Browser will block screen capture, screen recording, and screen sharing using video conference tools. This is the default behavior.
        
        This will also block sharing when using remote session tools.
        
    
4.  If you want to enable Prompting notifications when you allow screenshots, click the down arrow next to Prompt: Pop-up notifications.
    
    The Prompting notifications are not applicable for the Prisma Browser for Mobile. Prompting is only available when you select **Allow**, and not **Allow (Protected)**.
    
    1.  Configure the following options:
        
        -   **Warn and allow to proceed anyway** - Informs users about the risk or sensitivity of the action, but allows them to continue.
        -   **Warn and allow to proceed anyway with a reason** - Informs users about the risk or sensitivity of the action, and requires them to provide a reason to continue.
        -   **Permission request** - Allows users to send a permission request to the admin. The user will be informed once the [request](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-requests.html) is approved or denied.
            -   Choose the timeframe for the permission. You can configure the permission to be used once, or for a timeframe ranging from 10 minutes to 90 days.
        
    
5.  Click Set.
    

The Prisma Browser has a built-in snipping tool that works with the Secured Screenshot tool. This gives your end-users the ability to take screenshots only using the built-in snipping tool, especially in situations where this is the only option for users to take screenshots.

When the tool is set to Allow (Protected), other screenshot, screen share, or recording tools will be blocked. The only available tool for screenshots is the built-in tool.

The control for the snipping tool is located at the bottom of the sidebar. The control for the tool is located at the top of the browser page, in the Tools and Actions section.

To enable the Snipping tool, enable and display the Sidebar. The Snipping Tool icon will be displayed.

When you take a screen capture, the image will be sent to the clipboard. A message to this effect will be displayed for a few seconds.

The file that you save is stored as a protected file - it's stored as an encrypted file in the Clipboard. If the File Download control is set as protected, then the screenshot file will be saved as a protected file. If the Clipboard control is set to block between applications, you won't be able to paste the screenshot to any unapproved applications.

## Read-only Webpage

Mobile Browser - **No support**

You can now configure read-only mode for webpages that are contained within the Rule's scope.

This allows users to browse the information on web applications. Users can read the information, download files, but can't input data to any editable element in the page. This control isn't affected by specific content inspection - the settings in the When contains schedule. To configure the read-only webpage:

Read-only applies to HTML elements that are not editable. It does **not** prevent a web application from listening in to keyboard strokes, paste operations, mouse clicks, and so on.

This means that apps written in JavaScript, may still be fully editable if they are not built from standard HTML components such as HTML Forms.

An example for an app that is not working with Read-only control is Google Docs.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsData Controls
    
2.  Select Read-Only webpage.
    
3.  Select one of the following options:
    
    -   Enable \- the Prisma Browser will allow users to read and download the information on web applications but won't allow users to input information to any editable part of the page. Developer tools will be disabled on any webpage affected by this control.
        
        -   **Exclude Login Elements** - Exclude username and password elements so that the user will be able to log on.
    -   Disable \- the Prisma Browser does not block any user interaction with the web applications, subject to other rules.
        
    
4.  When you use this control, you can use your own dialog text to replace the default. To set the text, click Set dialog text.
    
5.  Click Set.
    

## Camera

Mobile Browser - **No support**

This feature controls whether or not websites that match the URL, application, or category in the rule have access to the device camera. This control isn't affected by specific content inspection - the settings in the When contains schedule. To set the Camera control:

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsData Controls
    
2.  Select Camera.
    
3.  Select one of the following options:
    
    -   Allow \- the Prisma Browser will allow using the camera in specific webpages.
        
    -   Block \- the Prisma Browser will block using the camera in specific webpages.
        
    
4.  Click Set.
    

## Microphone

Mobile Browser - **No support**

This feature controls whether or not websites that match the URL, application, or category in the rule have access to the device microphone. this control isn't affected by specific content inspection - the settings in the When contains schedule. To set the Microphone control:

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsData Controls
    
2.  Select Microphone.
    
3.  Select one of the following options:
    
    -   Allow \- the Prisma Browser will allow using the microphone in specific webpages.
        
    -   Block \- the Prisma Browser will block using the microphone in specific webpages.
        
    
4.  Click Set.