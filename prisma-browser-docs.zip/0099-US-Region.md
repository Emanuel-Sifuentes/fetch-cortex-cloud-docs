---
title: "US Region"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-us"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Browser Prerequisites > US Region"
updated: "Feb 10, 2026"
---

# US Region
The following domains are for clients in the US region.

The following domains are for clients in the US region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   api.wildfire.paloaltonetworks.com
-   wildfire.paloaltonetworks.com
-   cie-api-proxy.us.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.talon-sec.com
-   login.talon-sec.com
-   ext-proxy.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.talon-sec.com
-   auth.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com