---
title: "Integrate Prisma Access Browser with Microsoft Information Protection"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/integrate-prisma-access-browser-with-microsoft-information-protection"
depth: 2
breadcrumbs: "Home > Prisma Browser > Integrate Prisma Access Browser with Microsoft Information Protection"
updated: "Feb 10, 2026"
---

# Integrate Prisma Access Browser with Microsoft Information Protection
Integrate Prisma Access Browser with Microsoft Information Protection to enable Prisma Access Browser to read the labels when downloading and uploading files and enforce an appropriate policy.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Access Browser | Prisma Access with Prisma Access Browser bundle license or Prisma Access Browser standalone license; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html); Microsoft Information Protection |

The Microsoft Information Protection (also known as Microsoft Purview) is an external system that classifies and labels files. By integrating with Microsoft Information Protection, you enable the Prisma Access Browser to read the labels when downloading and uploading files and enforce an appropriate policy.

1.  Find your tenant ID.
    
    1.  Sign in to the [Azure portal](https://portal.azure.com/).
        
    2.  Make sure you're signed in to the correct tenant. If you're not in the correct tenant, [switch directories](https://docs.microsoft.com/en-us/azure/azure-portal/set-preferences#switch-and-manage-directories) .
        
    3.  Under Azure services, select Microsoft Entra ID. If you don't see Microsoft Entra ID, use the search function to find it.
        
    4.  Locate the Tenant ID in the Overview page.
        
    
2.  Obtain your client ID.
    
    1.  Sign in to the [Azure portal](https://portal.azure.com/).
        
    2.  Make sure you're signed in to the correct tenant. If you're not in the correct tenant, [switch directories](https://docs.microsoft.com/en-us/azure/azure-portal/set-preferences#switch-and-manage-directories) .
        
    3.  Under Azure services, select Microsoft Entra ID. If you don't see Microsoft Entra ID, use the search function to find it.
        
    4.  Under Manage, select App registrationsNew registration.
        
    5.  Enter a display Name for your application. Your users will see the display name when they interact with the app.
        
        You can change the display name at any time or use it for multiple app registrations. It doesn't affect the automatically generated Application (client) ID, which uniquely identifies your app.
        
    6.  Specify which users can use the application.
        
    7.  For Redirect URI, select Single Page Application (SPA) and provide the following URI: [https://gdhaibkimkeghllnpodfpoamchapggea.chromiumapp.org](https://gdhaibkimkeghllnpodfpoamchapggea.chromiumapp.org/).
        
    8.  Click Register.
        
        When registration finishes, you can find the Application (client) ID in the app registration's Overview page.
        
    
3.  Configure the required permissions for the app.
    
    1.  After the registration, under Manage, select Authentication. Under Implicit grant, select both Access tokens and ID tokens.
        
    2.  Under API permissions, select Add a permission. Select APIs my organization uses, and search for Microsoft Information Protection Sync Service. Select Delegated permissions and add the UnifiedPolicy.User.Read permission.
        
    3.  Under API permissions, select Add a permission. Select Microsoft APIs, and select Microsoft Graph. Choose Delegated permissions and add the email and openid permissions.
        
    4.  Under API permissions, select Grant admin consent for <Organization Name>.
        
    5.  Under Token configuration, select Add optional claim. Select ID, and add email.
        
    
4.  Enable the integration in Strata Cloud Manager.
    
    1.  Go to ManageConfigurationPrisma Access BrowserAdministrationIntegrationsServices.
        
    2.  Scroll to Microsoft Information Protection Integration and expand it.
        
    3.  Click Enabled, then enter the Tenant ID and Client ID.
        
    4.  Click Save.