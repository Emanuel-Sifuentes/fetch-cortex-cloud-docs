---
title: "Configure Protected Browsing"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-protected-browsing"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Security Controls > Configure Protected Browsing"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure Protected Browsing
Attack Surface reduction

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Anti-exploitation controls enable you to reduce the potential attack surface of the browser. These controls effectively limit usage of browser components that are complex and are occasionally found to contain vulnerabilities. While the latest version of the browser would never include known vulnerabilities, disabling unnecessary components limits the potential exposure between when a vulnerability is found and the time it is fixed.

You should be aware that by disabling these components, you may impact some web page functionality. To minimize the impact on end-users, a non-intrusive dialog will be displayed if a capability is canceled. You need to be aware of these dialogs and the corresponding events in case users report issues with web pages. For example, disabling WebGL may impact functionality of an online maps website. When the users complain, you can identify the issue by looking for corresponding events and dialogs when users browse to these sites.

When a web page is affected by a disabled component, an abbreviated message is shown. The message will pop up again every 2 hours if you revisit the website. The system will also generate a log event.

## **JavaScript v8 JIT & WebAssembly (WASM)**

Mobile Browser - **No support**

You can strengthen browser security by blocking JavaScript V8 JIT & WebAssembly (WASM) to reduce the risk of exploitation.

-   **Block JavaScript v8 JIT** to reduce the risk of exploitation and to enable advanced mitigation techniques such as Control Flow Guard (CFG), Control-flow Enforcement Technology (CET), and Arbitrary Code Guard (ACG).
    
    Blocking JIT may impact overall browser performance.
    
-   **Block WebAssembly (WASM)** to lower the attack surface for modern exploitation techniques.

Disabling the JavaScript V8 Just-In-Time (JIT) compiler helps reduce exploitation risks and enables additional security mitigation techniques, including Control Flow Guard (CFG), Control-flow Technology (CET), and Arbitrary Code Guard (ACG).

Blocking WASM may limit functionality in advanced web applications.

Use this configuration if your security posture prioritizes reduces vulnerability exposure over performance or feature compatibility.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select JavaScript v8 JIT.
    
3.  Select one of the following options:
    
    -   **Enable** - Enable use of JavaScript v8 JIT and WebAssembly.
    -   **Disable JavaScript advanced optimization** \- Disable use of JavaScript v8 JIT. You can optionally select specific domains to exclude.
    -   **Disable JavaScript JIT, including WebAssembly**\- Disable the use of JavaScript JIT and WebAssembly. You can optionally select specific domains to exclude.
        
        To exclude specific applications, enter their domains into the exclusion list. Click [here](https://chromeenterprise.google/policies/url-patterns/) for more information regarding entering URLs.
        
    
4.  Click Set.
    

## WebRTC

Mobile Browser - **No support**

Web Real-Time Communication (WebRTC) is an open-source project that enables real-time voice, text, and video communication capabilities between web browsers and devices.

This anti-exploitation policy controls the use of the WebRTC protocol, which can be potentially exploited.

Disabling WebRTC will prevent some video conferencing tools, such as Microsoft Teams, Google Meet, Zoom, and WebEx from working. To overcome this issue, add their domains to the exclusion list as described below.

When a user attempts to access a domain that is blocked, they will receive an on-screen notification, and a Log event will be created.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select WebRTC.
    
3.  Select one of the following options:
    
    -   1.  **Allow** - Allow the use of WebRTC.
            
        2.  **Block**\- Block the use of WebRTC.
            
        3.  To exclude specific applications, enter their domains into the exclusion list. Click [here](https://chromeenterprise.google/policies/url-patterns/) for more information regarding entering URLs.
            
    
4.  Click Set.
    

## PDFium

Mobile Browser - **No support**

The PDFium library is used to render PDF files in Chromium browsers.

This anti-exploitation policy controls the use of the PDFium library, which can be potentially exploited.

When PDFium is disabled, the Prisma Access Browser will not be able to open regular or protected PDF files.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select PDFium.
    
3.  Select one of the following options:
    
    -   1.  **Allow** - Permit use of the PDFium library to render PDF files.
            
        2.  **Block**\- Block use of the PDFium library to render PDF files.
            
    
4.  Click Set.
    

## WebGL API

Mobile Browser - **No support**

WebGL is a JavaScript-based API that is used for rendering high performance interactive 2-and 3D graphics using hardware graphics acceleration features provided in the user's device.

This anti-exploitation policy controls the use of the WebGL API, which can be potentially exploited.

**Note:** Disabling WebGL API may impact different websites using it in a legitimate way.

When a user attempts to access a domain that is blocked, they will receive an on-screen notification, and a Log event will be created.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select WebGL API.
    
3.  Select one of the following options:
    
    -   1.  **Allow** - Permit use of the WebGL API.
            
        2.  **Block**\- Block use of the WebGL API.
            
    
4.  Click Set.
    

## File System API

Mobile Browser - **No support**

The File System Access API (formerly known as the Native File System API and Writable Files API) enables developers to build powerful web apps that interact with files on the user's local device, such as IDEs, photos, video editors, text editors, and more. After a user grants a web app access, this API allows them to read or save changes directly to files and folders on the user's device. Beyond reading and writing files, the File System Access API allows opening a directory and enumerating its contents.

This anti-exploitation policy controls the use of the File System API, which can be potentially exploited.

**Note:** Disabling File System API may impact different websites using it in a legitimate way.

When a user attempts to access a domain that is blocked, they will receive an on-screen notification, and a Log event will be created.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select File System API.
    
3.  Select one of the following options:
    
    -   1.  **Allow** - Permit use of the File System API.
            
        2.  **Block**\- Block use of the File System API.
            
    
4.  Click Set.
    

## Sensors API

Mobile Browser - **No support**

The Sensors API controls access to several different low-level and high-level device sensor types.

This anti-exploitation policy controls the use of the Sensors API, which can be potentially exploited.

**Note**: Disabling Sensors API may impact different websites using it in a legitimate way.

When a user attempts to access a domain that is blocked, they will receive an on-screen notification, and a Log event will be created.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Sensors API.
    
3.  Select one of the following options:
    
    -   **Allow** - Permit use of the Sensors API.
        
    -   **Block** - Block use of the Sensors API.
    
4.  Click Set.
    

## WebSerial API

Mobile Browser - **No support**

The WebSerial API provides a method for websites to read from and write to serial devices. The devices can be connected via serial port, or by USB or Bluetooth devices that emulate a serial port.

This anti-exploitation policy controls the use of the WebSerial API, which can be potentially exploited.

Disabling WebSerial API may impact different websites using it in a legitimate way.

When a user attempts to access a domain that is blocked, they will receive an on-screen notification, and a Log event will be created.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select WebSerial API.
    
3.  Select one of the following options:
    
    -   **Allow** - Permit use of the WebSerial API.
        
    -   **Block** - Block use of the WebSerial API.
    
4.  Click Set.
    

## WebBluetooth API

Mobile Browser - **No support**

The WebBluetooth API provides a way for websites to communicate over GATT (Generic ATTribute Profile) with nearby user-selected Bluetooth devices in a secure and privacy-preserving way.

This anti-exploitation policy controls the use of the WebBluetooth API, which can be potentially exploited.

Disabling WebBluetooth API may impact different websites using it in a legitimate way.

When a user attempts to access a domain that is blocked, they will receive an on-screen notification, and a Log event will be created.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select WebBluetooth API.
    
3.  Select one of the following options:
    
    -   **Allow** - Permit use of the WebBluetooth API.
        
    -   **Block** - Block use of the WebBluetooth API.
    
4.  Click Set.
    

## WebUSB API

Mobile Browser - **No support**

The WebUSB API is a JavaScript specification for providing secure access from web pages to USB devices.

This anti-exploitation policy controls the use of the WebUSB API, which can be potentially exploited.

Disabling WebUSB API may impact different websites using it in a legitimate way.

When a user attempts to access a domain that is blocked, they will receive an on-screen notification, and a Log event will be created.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select WebUSB API.
    
3.  Select one of the following options:
    
    -   **Allow** - Permit use of the WebUSB API.
        
    -   **Block** - Block use of the WebUSB API.
    
4.  Click Set.
    

## WebHID API

Mobile Browser - **No support**

The WebHID API is used for providing access for Human Interface Devices. This feature permits access to alternative auxiliary devices, such as secondary keyboards and mouse-pointing devices.

This anti-exploitation policy controls the use of the WebHID API, which can be potentially exploited.

Disabling WebHID API may impact different websites using it in a legitimate way.

When a user attempts to access a domain that is blocked, they will receive an on-screen notification, and a Log event will be created.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select WebHID API.
    
3.  Select one of the following options:
    
    -   **Allow** - Permit use of the WebHID API.
        
    -   **Block** - Block use of the WebHID API.
    
4.  Click Set.
    

## Print Preview

Mobile Browser - **No support**

Print Preview displays the print preview in a new tab, a DOM UI page. The print preview page consists of a left pane that allows for printer selection and printer options and a right pane for displaying the preview and page thumbnails.

This anti-exploitation policy controls the use of the print preview, which can be potentially exploited.

If this is disabled, users will not see a preview of the page or file.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Print Preview.
    
3.  Select one of the following options:
    
    -   **Allow** - Permit use of the Print Preview.
        
    -   **Block** - Block use of the Preview.
    
4.  Click Set.
    

## Google Cloud Print

Mobile Browser - **No support**

Google Cloud Print is a discontinued Google service that allows users to print from any Cloud Print-aware application (web, desktop, mobile) on any device in the network cloud to any printer with native support for connecting to Cloud Print services.

This anti-exploitation policy controls the use of the Google Cloud Print API, which can be potentially exploited.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Google Cloud Print.
    
3.  Select one of the following options:
    
    -   **Allow** - Permit use of Google Cloud Print.
        
    -   **Block** - Block use of Google Cloud Print.
        
    
4.  Click Set.
    

## QUIC Protocol

Mobile Browser - **No support**

QUIC (Quick UDP Internet Connections) is a new internet transport protocol developed by Google. QUIC solves several application-layer issues experienced by modern web applications while requiring little or no change from application writers. QUIC is very similar to TCP+TLS+HTTP2 but implemented on top of UDP.

This anti-exploitation policy controls the use of the QUIC protocol, which can be potentially exploited.

**Note**: Disabling QUIC protocol may impact different websites using it in a legitimate way.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select QUIC Protocol.
    
3.  Select one of the following options:
    
    -   **Allow** - Permit use of the QUIC Protocol
        
    -   **Block** - Block use of the QUIC Protocol.
    
4.  Click Set.
    

## Web Clipboard API

Mobile Browser - **No support**

The Clipboard API empowers applications to handle clipboard commands and engage in asynchronous reading from and writing to the system clipboard. This control manages use of the Clipboard API which may be exploited.

When a user attempts to access a domain that is blocked, they will receive an on-screen notification, and a Log event will be created.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Web Clipboard API.
    
3.  Select one of the following options:
    
    -   **Allow** - Permit the Web Clipboard API to access the clipboard.
        
    -   **Block** - Block the Web Clipboard API from accessing the clipboard.
        
    
4.  Click Set.
    

## Local Fonts

Mobile Browser - **No support**

The Local Fonts provides access to the local fonts installed on the device which may be exploited.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Local Fonts.
    
3.  Select one of the following options:
    
    -   **Allow** - Permit the Prisma Access Browser to access local fonts installed on the device.
        
    -   **Block** - Block the Prisma Access Browser from accessing local fonts installed on the device.
        
    
4.  Click Set.
    

## Strict Origin Isolation

Mobile Browser - **No support**

Isolates every origin in its own agent-cluster, preventing scripts on one sub-domain from interacting with another.

The Prisma Browser uses a security model called **agent clustering**, which isolates each browser tab. When **Site Isolation** is enabled, the browser places each unique origin into its own cluster (eTLD), improving security by preventing cross-domain scripting. This change disables older techniques like document.domain.

If Site Isolation is **disabled**, Prisma Browser allows pages with the same eTLD+1 to share a cluster—supporting legacy features but weakening security.

Enable Site Isolation for stronger protection; use the legacy mode only when necessary for older applications.

**eTLD**: The effective public suffix. The eTLD of docs.google.com is google.com.

**eTLD+1**: The eTLD plus the next suffix to the left. The eTLD+1 of google.com can be mail.google.com.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Strict Origin Isolation.
    
3.  Select one of the following options:
    
    -   **Enable** - Enabling stricter cross-origin isolation strengthens defenses against Spectre and XS-Leak attacks and is a necessary step for features like high-resolution SharedArrayBuffer. However, it may break legacy applications that rely on document.domain for cross-subdomain communication.
    -   **Disable** - All pages that share the same eTLD+1 can still join one cluster. While this works for older, multi sub-domain apps, it provides more chance data leaks between sub-domains.
    
4.  Click Set.