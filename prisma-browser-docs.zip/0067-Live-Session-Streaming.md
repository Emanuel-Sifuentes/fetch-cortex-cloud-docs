---
title: "Live Session Streaming"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-devices/co-browsing"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Devices > Live Session Streaming"
updated: "Mar 12, 2026"
---

# Live Session Streaming
Describes how Live session Streaming works

| Where Can I Use This? | What Do I Need? |
| --- | --- |
|  |  |

Live session Streaming enables admins to connect to endpoint users to share a web session in real time. This functionality is commonly employed in customer support, collaborative workflows, and training scenarios. Additionally, Live session Streaming is critical for overseeing sensitive configuration processes frequently performed by external contractors, as these processes can impact secure systems. It creates a continuous record of your users' activities, and provides you with a better view of the user experience.

Existing solutions often depend on third-party applications, introduce latency, or compromise security, and require elevated permission. By embedding Live session Streaming capabilities directly into enterprise browsers, organizations can enhance control, ensure compliance, and deliver a clean user experience. Live session Streaming establishes secure, low-latency peer-to-peer connections, making it an optimal framework for enterprise-grade implementations.

The Prisma Browser

## Why Use Live Session Streaming?

There are many uses for Live session Streaming, all of which are designed to make your management easier.

There are cases when you need to make sure that contractors, using unmanaged devices, and having temporary access to sensitive data or critical systems, are following security protocols. You need real-time monitoring to keep track of these users, and they might not want to install intrusive third-party tools on their machines.

There are also situations where you need live troubleshooting to assist your users with issues that they are having. Live session Streaming allows you to join the user and see exactly what the issues are on their machines. Without this feature, you need a variety of third-party tools that need to be installed on your machine as well as on your user's, and configured properly. With Live session Streaming, all the tools that you need are in the Prisma Browser.

## Using Live Session Streaming

Live session Streaming can be accessed from two places in the Prisma Browser Management Console.

-   From the **Users Directory**.
    1.  Search for the user who needs Live session Streaming. You can search by email.
    2.  Click on the user to open the User drawer.
        
        The information in the drawer lists the available devices. Devices that are online will have a Request Live Stream icon. Click the icon to request live streaming.
        
    3.  Click the icon to send a request to the user, asking for permission to live stream.
-   From the **Devices Directory**.
    1.  Search for the device by the Device name or User,
    2.  Hover on the online device to display the Request Live session icon.
        
        **_OR_**
        
        Click on the device to open the Device drawer. The icon will be displayed.
        

### Making a Live Session Streaming Request

The Live Stream session is limited to 30 minutes.

1.  Once you click the icon, the Live Stream window will display. Click **Request** to begin.
    
2.  When you make the request, the user will receive a button next to the address bar. They can accept the request and select what information that they want to share in the session:
    
    -   **Tab** - Restrict the session to the information displayed in a single tab.
    -   **Window** - Restrict the session to the information displayed in a window (which may contain multiple tabs).
    -   b**Screen** - The Live session Stream will show all the information on the monitor.
    
    A Live Stream session is limited to 30 minutes. It can be terminated by either you or the user.
    
3.  When you're finished with the session, click **Terminate**.
    
    Click Terminate to confirm that you want to end the session.
    
4.  When the session is over, you can download a recording of the session.
    
    The session file is saved in \*.webm format. You can view this file in the Prisma® Access Browser.
    

Relevant information regarding the Live session Recordings are saved to the Audit Log.