---
title: "Manage Prisma Browser Customization Rules"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-customization-rules"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Rules > Manage Prisma Browser Customization Rules"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Manage Prisma Browser Customization Rules
Learn how to manage customization rules for Prisma Access Secure Enterprise Browser (Prisma Browser).

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Browser Customization Rules can be used by organizations to help increase productivity, and to make the browser their own, with a custom look and feel.

To view the rules:

The last rule on the list is the **Browser Customization - baseline**, also known as the Default Rule.

The Default Rule is the policy rule that is used when no other policy rule is applicable. Since this rule must be available for any given user or device, only certain controls can be edited.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyRules.
    
2.  Select the Browser Customization tab.
    
    The Browser Security list displays the following information for each rule:
    
    The information displays changes based on the rule type selected.
    
    -   **Priority** - The order in which the Rules are enforced. Once a Rule is matched, the Browser stops looking for another match.
        
        1.  Select the cog icon to the left of Change priorities to modify which of the following fields you want to display.
        2.  Select Change priorities to reorder the rules in the list. The rules are processed in order, and once a rule is matched, the processing stops.
        
    -   **Name**\- The name of the Rule.
        
    -   **Scope** - The Users and User groups included in the Rule.
        
    -   **Browser Customization controls** - The specific browser customization controls that are used as part of the Rule. If the Rule uses a profile, the name of the profile is highlighted in the display.
        
    -   **Updated** - The date and name of the person who made the most recent update. Hover over the entry to see the full timestamp.
    

## Search and Filter

You can search and filter for specific rules.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyRules.
    
2.  Select the Browser Customization tab.
    
3.  Search for rules by the description.
    
4.  Filter on rules based on specific criteria:
    
    -   **Users** – The Users and User Groups that are included in a Rule.
        
    -   **Device group** - The Device groups that are included in a Rule.
        
    -   **Controls** - The browser security controls that are used in the Rule.
        
    -   **Mode** (available in **Add Filter**) - The filter can include the following options:
        
        -   **Active** - Rules that are active and are used by the Policy Engine.
            
        -   **Disabled** – Inactive Rules are skipped by the Policy Engine.
            
    -   **Profile** - If the Rule uses External Controls (Profiles) as part of the Policy Rules, then you can use this filter to assist the search.
        
    

## Create New Browser Customization Rules

Adding a new Browser customization Rule can be done easily with an understanding of how the Rule will be used and enforced. Each Rule needs to be planned very carefully, taking into consideration the way that each element will be configured.

Browser Customization Rules are used to create a custom look and feel for your browser installation. These controls allow you to create their own customized edition of the browser, unique to their organization.

The Rule parameters allow you to have full control over the entire policy.

When setting up a Rule, you can click on the Wizard controls on the left side or click the **Next:** button at the bottom of the page.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyRules.
    
2.  Select the Browser Customization tab and \+ Add Rule.
    
    1.  Enter a Name for the rule.
        
    2.  Select the Mode.
        
        -   **Monitoring** - Rules that only write an entry to the Events Log. A Rule set to monitoring can be used for testing new rules.
            
        -   **Active** - Rules that are active and are used by the Policy Engine. This is the default action.
            
        -   **Disabled** – These are inactive Rules that are skipped by the Policy Engine.
            
        
    3.  Select Next: Scope.
        
    
3.  On the Scope page, enter the following information:
    
    1.  **Users/User Groups** - Select the Users and User Groups that will be covered by the Rule. It's possible to select multiple Users and User Groups. The default is **Any user**.
        
    2.  **Networks**\- Enter a Public IP address with a subnet, if needed, or a CIDR and Add.
        
    3.  **Location** – Select the geolocation from which to enable the Prisma Browser rule. If the OS Location services are not enabled on the device, the Prisma Browser will use the GeoIP. For more information, refer to [Location-based Policy](/content/techdocs/en_US/prisma-access-browser/administration/location-based-policy.html)
        
    4.  Select Next: Browser Customization controls.
        
    
4.  On the Browser Customization controls page, select the controls that are used in the rule. It can contain multiple controls. For information on configuring the individual controls, refer to [Browser Customization Controls](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization.html).
    
5.  Save.
    

## Configure External Controls

Inline profiles should be configured within the rules in the Controls sections. This allows you to create specialized rules containing different combinations and configurations of controls.

The [Profiles](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles.html) feature is used when you want to use legacy profiles and add them to the rules.

Rules can contain either inline data controls or external controls.

The Controls for the Prisma Browser rules are configured internally, within the body of the individual rule. This means that each rule contains its own unique set of controls.

There are some use cases when you might want to create multiple rules using the same list of controls. To accomplish this task, Prisma Browser has a mechanism to create external controls that are not built into a rule but exist separately. Each control defines a particular use case containing configurations for the policy control types.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyRules.
    
2.  Add rule.
    
3.  Browser Customization controls
    
    You can use these controls to brand the Prisma Browser, customize the homepage, and other components of the user experience.
    
    -   Branding
        
    -   Customization
        
    -   Homepage
        
    -   Upgrade Enforcement