---
title: "Integrate Prisma Access Browser with OPSWAT MetaDefender"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/integrate-prisma-access-browser-with-opswat-metadefender"
depth: 2
breadcrumbs: "Home > Prisma Browser > Integrate Prisma Access Browser with OPSWAT MetaDefender"
updated: "Tue Feb 10 06:48:41 PST 2026"
---

# Integrate Prisma Access Browser with OPSWAT MetaDefender
Integrate the Prisma Access Browser with the OPSWAT MetaDefender to prevent and detect cybersecurity threats in file downloads.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Access Browser | Prisma Access with Prisma Access Browser bundle license or Prisma Access Browser standalone license; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html); OPSWAT MetaDefender |

The OPSWAT MetaDefender uses a Zero Trust policy to scan and sanitize files. Integrate the Prisma Access Browser with MetaDefender to prevent and detect cybersecurity threats across multiple data channels. MetaDefender uses Content Disarm and Reconstruction (CDR) to remove threats from files by scanning, removing malicious content and scripts from the files, and reconstructing them.

After you integrate the Prisma Access Browser with the OPSWAT MetaDefender, your Prisma Access Browser will be able to use it as a file scanning engine. For more information, refer to [Malicious File Protection](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls).

1.  Obtain an API key from MetaDefender.
    
    1.  Sign in to the OPSWAT MetaDefender interface using the Administrator role.
        
    2.  Go to User Management.
        
    3.  ClickAdd User, define the user, and generate the API Key.
        
    4.  Copy the API Key and save it to a text file or another location.
        
    
2.  Enable the OPSWAT MetaDefender integration in Strata Cloud Manager.
    
    1.  Go to ManageConfigurationPrisma Access BrowserAdministrationIntegrationsServices.
        
    2.  Scroll to OPSWAT MetaDefender Integration and expand it.
        
    3.  Click Enabled, then enter the MetaDefender URL and API Key that you saved earlier.
        
    4.  Click Save.