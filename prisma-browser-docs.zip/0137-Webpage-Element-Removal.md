---
title: "Webpage Element Removal"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/webpage-element-removal"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Data Controls > Webpage Element Removal"
updated: "Mar 12, 2026"
---

# Webpage Element Removal
The **Webpage Element Removal** tool gives you granular control over how web content is presented to your end-users.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
|  |  |

The **Webpage Element Removal** tool gives you granular control over how web content is presented to your end-users.

Instead of fully blocking access to a website, this feature allows you to selectively remove specific HTML elements—such as buttons, menus, generative AI prompts, or social interaction controls—before the page is rendered. By modifying the page structure at render time, organizations can reduce risk while preserving access to essential business functionality.

Webpage Element Removal helps bridge the gap between unrestricted access and complete site blocking. This helps you maintain safer workflows and tighter data loss prevention (DLP) without hindering productivity.

## Typical Use Cases

The following are some typical use cases for Webpage Element Removal:

-   **Social Media Risk Management:** Enable analysts to perform due diligence on platforms such as X (formerly Twitter) or LinkedIn while removing the ability to "Like," "Retweet," or "Comment" by removing the buttons. This prevents accidental "virtue signaling" or attribution during investigations.
-   **GenAI Data Exfiltration Prevention:** Block embedded AI tools—such as Grok on X or AI Overviews in Google Search. This will prevent your users from inadvertently submitting sensitive information to public models without blocking the core search engine or platform ability.
-   **Enhanced RBAC for Critical Apps:** Visually enforce Role-Based Access Control (RBAC) on sensitive SaaS platforms. For example, remove the "Delete Repository" button in GitHub or "Terminate Instance" in AWS Console for junior developers.
-   **Data Leakage Protection (DLP):** Hide the "Share" button in Google Docs/Sheets/Slides or the "Open in Desktop App" option in SharePoint Online (SPO) to force users to work within the secure browser environment.

## The Element Removal Selector Tool

To configure a removal policy, you first need to identify the exact code (CSS Selector) of the element you wish to hide. The Prisma Browser contains a user-friendly tool to assist with this procedure.

## 1\. Enable the Selector

The CSS Selector admin tool is available for all end-users. However, the tool will not be available on websites for users that have an active policy to remove elements, ensuring users cannot bring elements back. In addition, when a policy to block developer tools on a website is enabled, the tool will be disabled to reduce risks of unauthorized data exposure.

## CSS Selector Tool Availability

To enable the tool:

1.  Open the Prisma Browser menu.
2.  Navigate to More tools Customize Prisma Browser.
    
3.  Select **Toolbar**.
    
4.  Toggle on **Element Selector**.
5.  The Prisma Browser icon will now appear in your browser toolbar.
    

## Use the Selector

1.  Navigate to the website you wish to modify (e.g. google.com).
    
2.  Click the **Element Selector** icon in the toolbar.
    
3.  Hover over the page; elements will highlight as you move your cursor.
    
4.  Click the specific element you want to remove.
    

## The Selection Popup

Once an element is clicked, a popup will appear offering the following controls:

-   **Copy Snippet:** Copies the specific CSS selector to your clipboard (required for Part 2).
    
-   **Hide/Show:** Toggles visibility to preview what the page looks like without the element.
    
-   **Trim Selector:** Adjusts the snippet from the beginning or end to make the selection more generic (applying to multiple similar items) or more specific.
    
-   **Move selector location:** Use the up/down arrows to move the selector location from the bottom/top right corners when needed to select different elements.
    

## 2\. Configure the Removal Policy

Once you have your CSS selector(s), you can enforce the removal via the Prisma Browser Management Console.

1.  Enable the Control
    1.  Navigate to **Policy Rules** > **Access & data rules** > **Controls and data profiles step**.
    2.  Locate the **Webpage Element Customization** section.
    3.  Switch the mode from **Disabled** (default) to **Enabled**.
2.  Add Elements
    1.  **Click Add element**
    2.  Give the element a name.
    3.  **CSS Element:** Paste the snippet copied from the Selector Tool.
    4.  You can delete CSS elements from the controls by clicking the trashcan icon next to them.
3.  Save and Deploy - Once saved, the policy is active. If you disable the control later, the removal rules will be ignored but saved for future use.

## Webpage Element Removal

## The End-User Experience

**What do your employees see?**

1.  **Seamless Integration** - The targeted elements simply do not render. There are no "blocked" placeholders or error messages where the button used to be.
2.  **Omnibox Indication:**
3.  To ensure transparency, an indicator (featuring your company logo) will appear in the address bar (Omnibox) to inform the user that the webpage layout has been modified by IT policy.
    

## Frequently-Asked Questions

## **Q: Can I use the Selector Tool on a page where I have already enforced a removal rule?**

A: No, this is prevented to avoid cases where users can unhide elements while trying to bypass admin policy

## **Q: Does this block the website entirely?**

A: No. This control is content-agnostic. It only modifies the visual presentation (HTML/CSS) of the page to remove specific functionality while keeping the rest of the site accessible.

## **Q: Can I apply this to specific users?**

A: Yes. Like other Prisma policies, this can be scoped. However, remember that administrators can exclude themselves from rules to ensure they can continue using the Selector Tool for maintenance.