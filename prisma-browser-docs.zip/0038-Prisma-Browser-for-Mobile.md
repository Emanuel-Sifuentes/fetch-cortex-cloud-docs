---
title: "Prisma Browser for Mobile"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/prisma-access-mobile-browser"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Browser for Mobile"
updated: "Feb 10, 2026"
---

# Prisma Browser for Mobile
This provides the information regarding the Prisma Browser for Mobile

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Prisma Browser for Mobile works with both Android and iOS devices. The browser easily integrates with the Prisma Browser and console, allowing you and your end users to include mobile devices in the tool sets.

The Prisma Browser and the Prisma Browser for Mobile share policy rules. However, some controls within the policy rules can operate differently, or are not available. For example, the **File Download** control skips the setting for specific file extensions because it's not supported for mobile use. As a result, enabling this setting causes the Prisma Browser for Mobile to block all file downloads.

The Prisma Browser for Mobile enables you to use the most common functionality from the regular browser. We recommend that you create rules with the appropriate device groups in the Scope. This will allow you to properly manage the Mobile device users. By defining device groups for mobile devices, you can set different rule sets to apply for all mobile devices.

## Onboard Prisma Browser for Mobile from the Strata Cloud Manager

In the onboarding phase, you can install the Android and iOS Prisma Browser for Mobile apps to test on your own devices before sending the links out to your users. Once you're satisfied with your tests, you can install the relevant Android and iOS apps and distribute the links to your users via your mobile device management (MDM) application.

## 

Install the Prisma Browser for Mobile

You can download the Prisma Browser for Mobile from the following locations:

-   iOS [App Store](https://apps.apple.com/us/app/talon-mobile/id1644868543)
    
-   Android [Google Play](https://play.google.com/store/apps/details?id=com.talonsec.talon&pcampaignid=web_share)
    
-   Intune for iOS [Intune for iOS](https://apps.apple.com/be/app/prisma-browser-for-intune/id6755684242)

Additionally, when you access the regular download link [https://get.pabrowser.com/](https://get.pabrowser.com/) from a mobile device, the URL directs you to the relevant app store. This means that you can send a single link to your users, even when you don't know their particular device.

## Create Prisma Browser for Mobile Device Groups

The Prisma Browser has a device group function that allows you to create different groups for different devices. Groups are dynamic. For example, you can set up groups for specific managed devices, different subsidiary devices, or contractors. As an administrator, you can exercise a considerable amount of flexibility in configuring the mobile device groups you need within your organization. For example, groups meet changing business, operational, and organizational circumstances. You can use device groups either with sign-in rules to set the security bar for accessing Prisma Browser for Mobile, or with posture-focused scoping for policy rules.

For more information, see [Manage Device Groups](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-devices?otp=task-hns_lt1_gcc#task-hns_lt1_gcc).

## Configure Mobile Browser Posture Attributes

The Prisma Browser for Mobile allows you to configure the posture requirements for your devices running the Mobile Browser in the same way that it configures posture for your desktop and laptop devices running the Prisma Browser.

For more information on the available Mobile Browser attributes, refer to [Configure Prisma Browser for Mobile Device Posture Attributes](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-devices/prisma-access-browser-mobile-device-posture-attributes).

## Configure Prisma Browser for Mobile Sign-In Rules

Along with the various policy rules, the Sign-in rules act as a security measures. Before relying on the policy rules, the Sign-in rules serve as the first access gatekeeper for Users and Devices.

When you create a Sign-in rule, make sure that the Scope contains the Users and User Groups and Device Groups that are designed for the Mobile Browser.

While the Prisma Browser for Mobile's Sign-in rules are configured the same way as the Sign-in rules for the Prisma Browser, be aware of the following exception:

Starting with _iOS_ browser version 1.4259 and _Android_ browser version 1.4260, the **Prompt** action functions as **Block**. For all earlier versions, it functions as **Allow**.

## Configure Prisma Browser for Mobile Policy Rules

The Prisma Browser for Mobile has various policy rules that you can configure to create rules as you require. The configuration process is exactly the same as for the Prisma Browser. Some of the policy rules contain different functionality due to the restrictions in mobile browsers.

## Mobile Access & Data Control

Mobile Devices support Access & Data Control rules with the following exceptions:

-   The Mobile Browser does not support the **Set dialog text** feature that permits you to customize your text for a particular feature.
    
-   The Web Access section of the rule creation process does not support the following features:
    
    -   **Permission request** (a “Prompt” option) becomes a **Block**.
    -   **Require MFA** becomes a **Block**.
    -   **Pick a Label** is skipped.
-   **Login restrictions** - Not supported and can be skipped.
    
-   **When contains** - Not supported and can be skipped.
    

To see the policy rules that you can use for creating rules in the Prisma Browser for Mobile, open the Controls page, select **Data Control**, and click **Mobile**.

For more information on the available Control sets, refer to the following articles:

-   [File Download](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/configure-data-leak-prevention?otp=task-wcx_qv3_hcc#task-wcx_qv3_hcc)
    
    The following File Download controls operate differently in the Prisma Browser for Mobile:
    
    -   ∫**Allow (Protected)** - The Prisma Browser for Mobile will block all downloads.
    -   **Block** \- The Prisma Browser for Mobile will block all downloads.
    -   **Apply on -** When applied on specific files the Prisma Browser for Mobile will block all downloads.
    -   **Prompt -** Selecting any prompt will block downloads.
    
-   [File Upload](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/configure-data-leak-prevention?otp=task-bm2_fz3_hcc#task-bm2_fz3_hcc)
    
    The following File Upload controls operate differently in the Prisma Browser for Mobile:
    
    -   **Allow** \- The Prisma Browser for Mobile will allow all uploads.
    -   **Allow protected files only between the rule’s web applications** - The Prisma Browser for Mobile will block all file uploads.
    -   **Allow only non-protected files** – The Prisma Browser for Mobile will block all file uploads.
    -   **Block** – The Prisma Browser for Mobile will block all file uploads.
    -   **Apply on:** - Select one of the following options:
        -   **Any file** - The upload restrictions will apply to all files.
        -   **Specific Files** - The Prisma Browser for Mobile supports file specification only for the following Microsoft web-apps:
            -   Teams
            -   Outlook
            -   OneDrive for Business
            -   SharePoint online
                
                For all other applications and URLs, the action will block file uploads for both blocking specific file uploads and allowing specific file uploads.
                
                Additionally, only **File size** and **File type** are supported. The upload restrictions will apply to files that meet the selected specifications (the rule can contain as many of these specifications as needed):
                
                -   **File size** - Set the size of the file.
                    
                -   **File types** - set the that need to match this rule.
                    
                -   **File hash** - The Prisma Browser for Mobile will block all file uploads using File Hash.
                    
                -   **MIP label** - The Prisma Browser for Mobile will block all file uploads requiring an MIP label.
                    
                    -   **Prompt** - Selecting any prompt will block all downloads.
-   [Clipboard](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/configure-data-leak-prevention?otp=task-krf_31j_hcc#task-krf_31j_hcc)
    
    The following Clipboard commands operate differently in the Prisma Browser for Mobile.
    
    -   Cut & Paste Data out:
        -   **Block (Permit only within the rule's web applications)** - The Prisma Browser for Mobile will block Copy and Paste Data out.
            -   **Exclude URL address bar** – Not supported in Prisma Browser for Mobile. If selected, it will be skipped.
        -   **Prompt** \- The Prisma Browser for Mobile will treat this as **Block**. All Copy & Paste Data Out will be blocked.
    -   Copy & Paste Data in:
        -   **Prompt** \- The Prisma Browser for Mobile will treat this as **Block**. All Copy & Paste Data In will be blocked.
-   [Print](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/configure-data-leak-prevention?otp=task-lql_5lj_hcc#task-lql_5lj_hcc)
    
    The Print control can also be used to manage File Downloads by printing to a PDF.
    
-   [Screenshot](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls?otp=task-s4m_xwj_hcc#task-s4m_xwj_hcc)
    
    The following screenshot control operates differently in the Prisma Browser:
    
    -   **Allow** (Protected) – The Prisma Browser for Mobile will block screen capture, screen recording, and screen sharing using video conference tools.

## Mobile Browser Security

To see the policy rules that you can use for creating rules in the Prisma Browser for Mobile, open the Controls page, select **Browser Security**, and click **Mobile Browser**.

## Mobile Browser Customization

To see the policy rules that you can use for creating rules in the Prisma Browser for Mobile, open the Controls page, select **Browser Customization**, and click **Mobile Browser**.

### Prisma Browser for Mobile Troubleshooting

There is a Troubleshooting page for the Prisma Browser for Mobile. You can find it at the following location:

-   **Android** - Click 3 dots → Settings → Scroll down to Troubleshoot → Click Prisma Access Integration.
-   **iOS** - Click 3 dots → Settings → Scroll down to Troubleshoot → Click Prisma Access Integration.

There are two common SSL-related issues on iOS devices:

-   **Outdated Certificates**: iOS enforces certificate validity limits. Certificates valid for more than one year may cause SSL errors. These issues typically affect internal websites, not public ones. [Apple Certificate Requirements](https://support.apple.com/en-il/102028).
-   **Traffic Routing with Decryption**: Routing all traffic through Prisma Access while SSL decryption is enabled is **not** supported.