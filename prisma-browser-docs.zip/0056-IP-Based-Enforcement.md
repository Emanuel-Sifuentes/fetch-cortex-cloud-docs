---
title: "IP Based Enforcement"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/ip-based-enforcement"
depth: 2
breadcrumbs: "Home > Prisma Browser > IP Based Enforcement"
updated: "Feb 10, 2026"
---

# IP Based Enforcement
Ensure that access to SSO-enabled applications is only possible from the Prisma Browser.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Browser | Prisma Access with Prisma Access Browser bundle license or Prisma Access Browser standalone license; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

IP-based enforcement ensures that access to SSO-enabled applications is only possible from the Prisma Browser. Authentication traffic to your IdP flows through a special proxy with a set of known egress IP addresses.

The Prisma Browser uses the Authentication Proxy for the SSO login pages only. It does not use the proxy for any other traffic.

The Prisma Access Gateway acts as a forward proxy with a set of predictable IP addresses. You then need to configure the browser to route the IdP authentication traffic through the Prisma Browser gateway.

You then need to create and establish a conditional access rule in the IdP, making a requirement to only use the Prisma Browser Gateway for authentication. This means that any attempt to authenticate via a different browser will fail.

To begin the process, perform the following actions:

1.  Open the Strata Cloud Manager.
    
2.  Open the Cloud Identity Engine.
    
3.  Select Authentication Types
    
4.  Click **Add New Authentication Type.**
    
5.  Under **SAML 2.0**, click **Set Up**.
    
6.  Set up your IdP. To properly configure the IdP, refer to [Cloud Identity Engine Getting Started](https://docs.paloaltonetworks.com/cloud-identity/cloud-identity-engine-getting-started/authenticate-users-with-the-cloud-identity-engine/configure-an-identity-provider-in-the-cloud-identity-engine).
    
7.  In the Prisma Browser Setup page, click step 4: **Enforce SSO Applications**.
    
8.  Choose the appropriate IdP. All Prisma Browserauthentication traffic to those identity provider tunnels through the Prisma Browser gateway. The options are:
    
    -   Okta
    -   PingID
    -   VMware ONE Workspace Access
    -   Microsoft Azure Active Directory
    -   OneLogin
    
    To integrate the Prisma Access Browser and Okta with the device Posture provider, [see here](https://docs.paloaltonetworks.com/prisma-access-browser/integrations/third-party-integrations/integrate-prisma-browser-aand-okta-with-the-device-posture-provider).
    

## Configure Okta IP-Based Enforcement

Follow these steps to limit access to all or specific apps to the Prisma Browser when you use Okta.

1.  Configure the Prisma Browser Application Enforcement IP Addresses
    
    1.  Configure the Application Enforcement IP Addresses. In the Okta app go to **Security > Networks > Add zone > IP zone**.
        
    2.  Set the name of the zone to the **Prisma Access Authentication Proxy**.
        
    3.  In the **Gateway IP**field, paste the **egress IP Addresses**.
        
    4.  Click **Save**.
        
    5.  Confirm that the new zone appears in the list.
        
    
2.  Select Applications and User Groups to Adhere to the Policy
    
    1.  You need to create a new conditional access; Choose **Applications -> Applications** and click on the app that you want to restrict.
        
    2.  Go to the **Sign On** tab, scroll down to the User Authentication and click **View policy details**.
        
    3.  Click **Add rule** and enter the following information:
        
        -   **Name:** Allow access only from the Prisma Browser.
        -   **Users:** Select the users or user groups to enforce:
        
        -   **User's group membership includes** - make sure that you configure this setting for groups.
        -   **User is** - Allows you to apply rules to some specific users, but not to other specific users.
            
        -   **Device Platform is** - Make sure you select both Windows and macOS.
        -   **User IP is** Select **Not in any of the following zones**, and select **Prisma Access Authentication Proxy**.
        -   **Access is** - Select _Denied_.
        
        -   Click **Save**.
        
    
3.  Enable IdP Enforcement in the Prisma Access Console
    
    1.  In the Strata Cloud Manager, navigate to **Workflows → Prisma Access Setup → Prisma Browser****Configuration → Prisma Browser → Onboarding** .
        
    2.  In the **Onboard Users** section, Locate Prisma Browser and click **View**.
        
    3.  In the Prisma Browser Setup page, click **Step 4: Enforce SSO Applications.**
        
    4.  Select the appropriate IdP. In this case, click **Okta**.
        
        From this point on, users will only be able to access the SSO applications via the Prisma Browser
        
    

## Configure Microsoft Azure Active Directory IP-Based Enforcement

Follow these steps to limit access to all or specific apps to the Prisma Browser when you use Microsoft Azure Active Directory.

The Prisma Browser uses the Authentication Proxy for the SSO login pages only. It does not use the proxy for any other traffic.

You need Microsoft P2 Premium licenses at a minimum, including Microsoft 365 business to enable this enforcement.

## Configure the Prisma Browser Application Enforcement IP Addresses

1.  Create a new **Named Location** from the Azure Active Directory Admin Center.
    
    1.  Search for the **Named Locations** from the Admin Center. If available, select the _New and improved Named Location_.
        
    2.  Click **IP range location**.
        
    3.  In the **New Location <IP> Ranges** section, enter the name of the Prisma Browser IP Range.
        
    4.  Paste the egress IP Addresses into a text file.
        
    5.  **Upload** the file.
        
    6.  Click **Create**.
        
    7.  Confirm that the new Named Location appears on the list.
        
    
2.  Select Applications and User Groups to Adhere to Policy
    
    1.  Navigate to the Azure Conditional Access Portal.
        
    2.  Select **New Policy → Create New Policy** , and enter the following information:
        
        -   **Name -** Enter a name. For example, _Block access not from Prisma Browser_.
        -   **Assignments -** Assign the policy to users or groups. Be sure to include all users who need to connect to applications using the Prisma Browser only.
        -   **Target Resources -** Make sure that the **Control access** includes cloud apps.
        -   **Conditions -** Apply any needed conditions. Include at least one local condition.
        -   **Grant -** Select _Block access_.
        -   **Cloud apps or actions -** Select _Cloud apps_, then include selected applications.
        
        The Prisma Browser can't be a required application for enforcement.
        
        If you select **All apps**, be sure to _exclude_ the Prisma Browser.
        
        -   **Enable policy -** Set this to _On_.
        
    3.  Click **Create**.
        
    
3.  Enable IdP Enforcement in the Prisma Access Console
    
    1.  In the Strata Cloud Manager, navigate to **Workflows → Prisma Access Setup → Prisma Browser****Configuration → Prisma Browser → Onboarding** .
        
    2.  In the **Onboard Users** section, Locate Prisma Browser and click **View**.
        
    3.  In the Prisma Browser Setup page, click **Step 4: Enforce SSO Applications.**
        
    4.  Select the appropriate IdP. In this case, click **Microsoft Azure Active Directory**.
        
        From this point on, users will only be able to access the SSO applications via the Prisma Browser
        
    

## Configure OneLogin IP-Based Enforcement

Follow these steps to limit access to all or specific apps to the Prisma Browser when you use OneLogin.

1.  Configure the Prisma Browser Application Enforcement IP Addresses
    
    1.  In the OneLogin toolbar go to **Security -> Policy** .
        
    2.  Click **New App Policy**.
        
    3.  Enter a name to identify the policy. For example, _Enforce Access from the Prisma Browser only_.
        
    4.  In the **IP Address Whitelist**, copy and paste the egress IP Addresses.
        
    5.  Click **Save**.
        
    
2.  Click Select Applications and User Groups to Adhere to Policy
    
    1.  On the OneLogin toolbar go to **Application → Applications**.
        
    2.  Click **Add App**.
        
    3.  In the **Found Applications** field. search for the application that you need to add.
        
    4.  Click **Save**.
        
    5.  Select **Access**.
        
    6.  In the drop down before the Policy Title, select **Enforce Access from the Prisma Browser only**.
        
    7.  Repeat steps b-f for each application that you want to add enforcement access.
        
        The Prisma Browser can't be a required application for enforcement.
        
    8.  Select **Users**.
        
    9.  Select the Users or Groups that must adhere to the **Enforce Access from the Prisma Browser only** policy.
        
    
3.  Enable IdP Enforcement in the Prisma Access Console
    
    1.  In the Strata Cloud Manager, navigate to **Workflows → Prisma Access Setup → Prisma Browser****Configuration → Prisma Browser → Onboarding** .
        
    2.  In the **Onboard Users** section, Locate Prisma Browser and click **View**.
        
    3.  In the Prisma Browser Setup page, click **Step 4: Enforce SSO Applications.**
        
    4.  Select the appropriate IdP. In this case, click **v** .
        
        From this point on, users will only be able to access the SSO applications via the Prisma Browser
        
    

## Configure PingOne IP Based Enforcement

Follow these steps to limit access to all or specific apps to the Prisma Browser when you use PingOne.

1.  Configure the Prisma Browser Application Enforcement. In the PingOne Admin Console, perform the following steps:
    
    1.  Select **Connection → Application**, select the Prisma Browser application, and click the vertical ellipse.
        
    2.  Click **View**.
        
    3.  Select the **Policy Rules** tab and click the pencil icon.
        
    4.  Click **Add Policy Rules**.
        
    5.  In the Edit Policies window, select **Multi\_Factor**, and click **Save**.
        
    6.  Select **Overview** and click **PingID**.
        
        1.  Click on the **Services +** and add the **PingID** service.
            
        2.  Click on **PingID** and continue the process.
            
        3.  Select the **Policy** tab and click **Add Policy**.
            
        
    7.  In the **New Policy** page, enter the following information:
        
        1.  In the **Name** field, enter an identifying name.
        2.  In the **Application** section, select the applications that you want to apply conditional access enforcement.
        3.  In the **Groups** section, select **All Groups**.
            
        4.  If an application does not appear on the list:
        
        1.  Make sure that the application has multi-factor authentication enabled.
        2.  Under _PingFederate Applications_, click **Add Application** to add the application to the list.
        
    8.  In the Rules section, click **Add Rule**.
        
        1.  For **Select a Condition**, choose **Accessing from a company network**.
            
        2.  For **Action** select **Approve**.
        3.  For the IP addresses, manually copy and paste the egress IP addresses as comma-separated-values.
        4.  In the **Default Action** section, choose **Deny**.
        5.  Click **Save**.
        
    9.  Click the **Configuration** tab and scroll down to the **Policy** section.
        
        1.  Enable **Enforce Policy**.
        2.  Enable **Policy for Windows Login**.
        3.  Click **Save**.
            
        
    
2.  Enable IdP Enforcement in the Prisma Access Console
    
    1.  In the Strata Cloud Manager, navigate to **Workflows → Prisma Access Setup → Prisma Browser****Configuration → Prisma Browser → Onboarding** .
        
    2.  In the **Onboard Users** section, Locate Prisma Browser and click **View**.
        
    3.  In the Prisma Browser Setup page, click **Step 4: Enforce SSO Applications.**
        
    4.  Select the appropriate IdP. In this case, click **PingOne**.
        
        From this point on, users will only be able to access the SSO applications via the Prisma Browser
        
    

## Configure JumpCloud Based IP Enforcement

Follow these steps to limit access to all or specific apps to the Prisma Browser when you use JumpCloud.

1.  Configure the Prisma Browser Application Enforcement. In the JumpCloud Admin Portal, perform the following steps:
    
    1.  Select **Security Management -> Conditional Lists** and click the **+**.
        
    2.  In the **New IP List**, enter the following information:
        
        1.  **List Name -** Prisma Access Authentication Proxy.
        2.  **Description -** Enter an optional description for the list.
        3.  **IP Addresses -** Enter the list of egress IP addresses.
        
        Click **Save**.
        
        A message will display indicating that the list was created.
        
    3.  Select **Security Management -> Conditional Policies** and click the **+**.
        
    4.  Click **User Portal**.
        
    5.  In the **General Info** section, enter the following information:
        
        -   **Policy Name -** Enter a name for the policy, for example - _Allow access only from the Prisma Browser_.
        -   **Description -** Enter an optional description.
        -   **Policy Status -** Make sure that this is set to 'On'.
        
    6.  In the **Assignments** section, click **All Users** or **Select User Groups**.
        
        Admins can select All Users or individual user groups. Additionally, admins can select groups that are to be excluded from the policy.
        
        For example, the policy can be applied to all users, but the admins can be excluded.
        
    7.  In the **Conditions** section, do the following:
        
        -   Click **Add conditions** and select **IP addresses**.
        -   IP address**:** Select **not on list**, and for the list - select **Prisma Access Authentication Proxy**.
        
    8.  In the **Action** section, enter the following information:
        
        -   For **Access**, select **Denied**.
        -   For **Authentication**, select based on your corporate policy.
        
    
2.  Enable IdP Enforcement in the Prisma Access Console
    
    1.  In the Strata Cloud Manager, navigate to **Workflows → Prisma Access Setup → Prisma Browser****Configuration → Prisma Browser → Onboarding** .
        
    2.  In the **Onboard Users** section, Locate Prisma Browser and click **View**.
        
    3.  In the Prisma Browser Setup page, click **Step 4: Enforce SSO Applications.**
        
    4.  Select the appropriate IdP. In this case, click **JumpCloud**.
        
        From this point on, users will only be able to access the SSO applications via the Prisma Browser
        
    

## Configure VMware Workspace ONE IP Based Enforcement

Follow these steps to limit access to all or specific apps to the Prisma Browser when you use VMware Workspace ONE.

1.  Configure the Prisma Browser Application Enforcement. In the Main Access Portal page, perform the following steps:
    
    1.  On the main Access Portal page, select **Resources -> Policies,** and click **Network Ranges**.
        
    2.  Click **Add Network Range**.
        
    3.  Enter a **Name** and **Description** for the Network Range.
        
    4.  manualle enter each row of the egress IP addresses.
        
        The values must be entered as "from -to" without including the subnet mask.
        
    5.  Click **Save**. The new Network Range will be added to the list.
        
    
2.  Select Applications and User Group to Adhere to Policy
    
    1.  On the main Access Portal page, select **Resources -> Policies,** and click **Add Policy**.
        
    2.  On the **Definition** page, enter a name and a description for the **Policy**.
        
    3.  Select the relevant application in the **Applies to** field.
        
        The Prisma Browser cannot be a required application for enforcement.
        
    4.  Click **Next**.
        
    5.  On the **Configuration** page, click **Add Policy Rule**, and provide the following information:
        
        1.  **If a user's network range is -** Select the **Range Name** defined in the previous step.**If a user's network range is** – Select the **Range Name** defined in the previous step.
        2.  **and the user accessing content from** – All Device Types.
        3.  **and the user belongs to a group** – Select the affected group (optional).
        4.  **Then perform this action** – Authenticate using…
        5.  **then the user may authenticate using** – Password (Local Directory)
        
    6.  Click **Save**. The new policy will be displayed,
        
    7.  Click **Next** and review the **New Access Policy Summary**.
        
    8.  Click **Save**. The new policy will be added to the policy list.
        
    
3.  Enable IdP Enforcement in the Prisma Access Console
    
    1.  In the Strata Cloud Manager, navigate to **Workflows → Prisma Access Setup → Prisma Browser****Configuration → Prisma Browser → Onboarding** .
        
    2.  In the **Onboard Users** section, Locate Prisma Browser and click **View**.
        
    3.  In the Prisma Browser Setup page, click **Step 4: Enforce SSO Applications.**
        
    4.  Select the appropriate IdP. In this case, click **VMware Workspace ONE**.
        
        From this point on, users will only be able to access the SSO applications via the Prisma Browser.