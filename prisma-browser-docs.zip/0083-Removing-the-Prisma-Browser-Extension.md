---
title: "Removing the Prisma Browser Extension"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/deploy-the-prisma-access-browser-extension/removing-the-prisma-access-browser-extension"
depth: 3
breadcrumbs: "Home > Prisma Browser > Deploy the Prisma Browser Extension > Removing the Prisma Browser Extension"
updated: "Tue Feb 10 06:48:28 PST 2026"
---

# Removing the Prisma Browser Extension
Instructions on removing the Prisma Access Browser Extension

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

There are times when you may need to remove the Prisma Browser Extension from your browser. If you need to remove the extension, please refer to the following detailed instructions:

1.  JAMF Installations
    
    1.  Open the JAMF application.
        
    2.  Select **Configuration Profiles**.
        
    3.  Locate the appropriate profile - it should be called **Prisma Browser Extension** profile.
        
    
2.  Google Workspace Installations
    
    1.  Navigate to **Devices → Chrome → Settings → Users and Browsers**.
        
    2.  Click Organizational Units.
        
    3.  Select the organizational unit to install the extension.
        
    4.  Navigate to **Devices → Chrome → Apps & Extensions**.
        
    5.  Search for _Prisma Browser Extension ID_ (\`dbpnkcjkchadgbgihmmolkjcgjkodoaf\`), click it and move it using the Trash icon.
        
    6.  In the confirmation pop-up, click **Delete**.
        
    7.  Wait for the **Application deleted** message at the bottom of the screen for confirmation.
        
    
3.  Windows MDM and Manual Installations
    
    1.  Run the following commands:
        
        -   Remove-Item -Path "HKLM:\\Software\\Policies\\Google\\Chrome\\ExtensionSettings\\dbpnkcjkchadgbgihmmolkjcgjkodoaf" -Force -Recurse
        -   Remove-Item -Path "HKLM:\\Software\\Policies\\Google\\Chrome\\3rdparty\\extensions\\dbpnkcjkchadgbgihmmolkjcgjkodoaf" -Force -Recurse
        -   Remove-Item -Path "HKLM:\\Software\\Policies\\Microsoft\\Edge\\ExtensionSettings {PABX\_EXTENSION\_ID}" -Force -Recurse
        -   Remove-Item -Path "HKLM:\\Software\\Policies\\BraveSoftware\\Brave\\ExtensionSettings{PABX\_EXTENSION\_ID}" -Force -Recurse
        -   Remove-Item -Path "HKLM:\\Software\\Policies\\BraveSoftware\\Brave\\3rdparty\\extensions\\dbpnkcjkchadgbgihmmolkjcgjkodoaf" -Force -Recurse
        -   Remove-Item -Path "HKLM:\\Software\\Policies\\Chromium\\ExtensionSettings {PABX\_EXTENSION\_ID}" -Force -Recurse
        -   Remove-Item -Path "HKLM:\\Software\\Policies\\Chromium\\ExtensionSettings {PABX\_EXTENSION\_ID}" -Force -Recurse
        
    
4.  macOS Manual Installation
    
    1.  Go to **Settings**.
        
    2.  Search the **Profiles**.
        
    3.  Delete the Prisma Browser Profile (PABX)
        
    
5.  For all Installation types, once you are done, please restart the browser. When you restart the browser, any internal files on the local system will be totally removed.