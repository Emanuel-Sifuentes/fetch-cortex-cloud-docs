---
title: "Overview: What is the Prisma Browser?"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-overview"
depth: 2
breadcrumbs: "Home > Prisma Browser > Overview: What is the Prisma Browser?"
updated: "Feb 10, 2026"
---

# Overview: What is the Prisma Browser?
Prisma Access Secure Enterprise Browser (Prisma Browser) secures both managed and unmanaged devices by placing the security directly in the browser.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Prisma Browser is designed to enhance security for both managed and unmanaged devices. It provides a natively integrated enterprise browser that extends protection to unmanaged devices, helping safeguard business applications and data by implementing security directly within the browser.

Prisma Browser supports various use-cases, including:

-   **Third-Party Access:** Enables secure access to SaaS or private web applications for contractors, partners, consumers, or students using unmanaged devices.
-   **Bring Your Own Device (BYOD) Access:** Enables secure access to SaaS or private web applications for contractors, partners, consumers, or students using unmanaged devices.
-   **Temporary Secure Access:** Facilitates access to critical applications such as Human Resources and Payroll during system transitions like agent rollouts or network mergers.
-   **Secure Access for Managed Devices:** Ensures protection for employees using work devices to handle highly sensitive data.

Designed specifically for enterprise environments, Prisma Browser incorporates security features aimed at mitigating risks such as phishing, Malware, eavesdropping, and data exfiltration. It retains the familiar interface and functionality of Google Chrome while integrating additional security measures to address potential vulnerabilities, offering a balance between usability and protection.

For more information, please see [the Prisma Access Browser page for more information.](https://www.paloaltonetworks.com/sase/prisma-access-browser)