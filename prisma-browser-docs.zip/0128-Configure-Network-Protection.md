---
title: "Configure Network Protection"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-network-protection"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Security Controls > Configure Network Protection"
updated: "Mar 12, 2026"
---

# Configure Network Protection
Configure Network Protection.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Pages with SSL Errors

Mobile Browser - **Full support**

This feature manages how the Prisma Browser will react when it encounters a page with an SSL error. In general, most browsers ask for permission to "Proceed to \[FQDN\] (unsafe)".

Since SSL errors can occur during an SSL MitM attack, you can use this control to block the "Proceed..." functionality.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Pages with SSL Errors.
    
3.  Select one of the following options:
    
    -   **Allow** - Allow users to bypass the blocking page when an SSL issue is identified.
        
    -   **Block** – The Prisma Browser will block the "Proceed..." option when an SSL issue is identified.
        
    
4.  Click Set.
    

## DNS-Over-HTTPS

Mobile Browser - **No support**

This feature manages the DNS resolution over the HTTPS protocol. It is used for encrypting requests.

This assists in preventing MitM attacks.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select DNS-Over-HTTPS.
    
3.  Select one of the following options:
    
    -   **Enable** \- Enter the following information:
        
        **Upon DNS over HTTPS resolve failure:**
        
        -   **Fail-open:** Resolve using plain DNS.
            
        -   **Fail-close:** Do not resolve.
            
    -   Enter the **DNS-over-HTTPS resolver's** URL.
        
    -   **Disable** – Prisma Browser will not enable DNS over HTTPS resolution.
        
    
4.  Click Set.
    

## Trusted Certificate Authorities

Mobile Browser - **Partial support**

This feature manages how the Prisma Browser manages certificates.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Trusted Certificate Authorities.
    
3.  Select the certificate authorities that are to be trusted by the Prisma Browser (this limits the trust to certificates that are already trusted):
    
    -   **Device trust store** - Trust the certificate authorities installed in the device's certificate store.
        
    -   **Prisma Access Browser trust store** - Trust only certificate authorities that are trusted by Palo Alto Networks, and ignores certificates installed in the Device trust store.
        
    -   **None** - Do not trust certificates in any trust store.
        
        Prisma Browser for Mobile rules using this control **must** use one of the Trust Stores. The **None** option is ignored.
        
    
4.  **Additional trusted certificate authorities**\- Add customer-provided certificates not already trusted by the Prisma Browser.
    
    1.  Enter a name for the certificate.
        
    2.  Drag or Browse a certificate in .pem, .der, .crt, or .cer formats.
        
    
5.  Click Set.
    

## Basic Authentication over HTTP

Mobile Browser - **Full support**

This feature controls whether the Prisma Browser can use Basic Authentication over HTTP websites.

Since Basic Authentication sends authentication tokens in clear text, sending them over HTTP can be visible to attackers as part of a MitM attack.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Basic Authentication over HTTP.
    
3.  Select one of the following options:
    
    -   **Allow** - allow Prisma Browser to use Basic Authentication over HTTP websites.
        
    -   **Block** – block Prisma Browser from using Basic Authentication over HTTP websites.
        
    
4.  Click Set.
    

## Pages with Insecure Content

Mobile Browser - **No support**

This feature controls whether users can load insecure content (data located on HTTP servers) to secure websites (located on HTTPS servers).

You can choose to exclude specific domains from this feature when there are specific applications that need an exception to the rule.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Pages with Insecure Content.
    
3.  Select one of the following options:
    
    -   **Allow**\- Prisma Browser will allow insecure content.
        
        1.  **Exclude specific domains** - list domains that will receive an exception to the rule.
            
    -   **Block** – Prisma Browser will not allow insecure content.
        
        1.  **Exclude specific domains** - list domains that will receive an exception to the rule.
            
    
4.  Click Set.
    

## Force HTTPS

Mobile Browser - **Partial support**

You can force the use of the **HTTPS protocol**, minimizing the risk of [MitM attacks](https://en.wikipedia.org/wiki/Man-in-the-middle_attack).

You will be able to force HTTPS for all domains, force HTTPS but exclude certain domains, or disable forced HTTPS and work without any restrictions.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Force HTTPS.
    
3.  Select one of the following options:
    
    -   **Enable**\- Prisma Browser will require use of the HTTPS protocol.
        
        You can enter specific domains that will be excluded from this requirement in the **Exclude specific Domains** field.
        
        **Exclude specific domains** is not available for the for Prisma Browser for Mobile.
        
    -   **Disable** – Prisma Browser will not require use of the HTTPS protocol.
        
    
4.  Click Set.
    

## Post-Quantum Key Support

Mobile Browser - **No support**

This feature manages the ability to enable or disable the use of post-quantum key agreement protocols within TLS (Transport Layer Security). Post-quantum cryptography refers to algorithms designed to be secure against quantum computer attacks, which could potentially break traditional cryptographic methods. While enabling this feature enhances security by preparing for future quantum threats, it may cause compatibility issues with existing network security products that do not yet support or recognize post-quantum algorithms. Disabling it may help avoid these conflicts, but it reduces future-proofing against emerging quantum-based vulnerabilities.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select **Post-Quantum Key Security**.
    
3.  Select one of the following options:
    
    1.  **Enable** - Permits the use of Post Quantum Key Security.
        
    2.  **Disable** - Disables the use of Post Quantum Key Security.
        
    3.  **Not set** - The feature is not enabled. This is the default setting.
        
    
4.  Click **Set**.
    

## Kerberos Delegation Allowlist

Mobile Browser - **No support**

List the hosts that may forward a user’s Kerberos ticket to downstream services. When this is enabled, the Kerberos ticket is used in place of your SSO so that back-end services are easier yo use.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select **Kerberos Delegation Allowlist** .
    
3.  Select one of the following options:
    
    1.  **Enable** - Activates real-time host scanning of the selected hosts. For information on specifying hosts in the correct pattern, refer to [this page](https://chromeenterprise.google/policies/url-patterns/). of t.
        
    2.  **Disable** - Disables the use of the real-time host scanning.
        
    
4.  Click **Set**.
    

## Remote Host Firewall Traversal.

Mobile Browser - **No support**

This policy controls whether the Remote Desktop can bypass firewalls. When enabled, users can connect remotely from any network. When disabled, access is limited to the same local network or VPN, enhancing security by restricting remote access.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select **Remote Host Firewall Traversal** .
    
3.  Select one of the following options:
    
    1.  **Allow** - Allow users to connect remotely from any network.
        
    2.  **Block** - Remote connection is only permitted from the same local network or VPN.
        
    
4.  Click **Set**.
    

## Local Network Access Restrictions

Mobile Browser - **No support**

The local network access permission prompt and restrictions feature is targeted to affect browsers versioned 146.xx and above.

**Local Network Access Restrictions** is a security control that allows you to govern how websites interact with devices located on your users local networks. This manages the underlying _[LocalNetworkAccessRestrictionsEnabled](https://chromeenterprise.google/policies/#LocalNetworkAccessRestrictionsEnabled)_, _[LocalNetworkAccessAllowedForUrls](https://chromeenterprise.google/policies/#LocalNetworkAccessAllowedForUrls)_, _[LocalNetworkAccessBlockedForUrls](https://chromeenterprise.google/policies/#LocalNetworkAccessBlockedForUrls)_ policies for Chromium-based browsers.

The default value for desktop devices is 'Use default restrictions' meaning, a user will be prompted to manage all local network access.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyProfilesBrowser Security
    
2.  Select **Local Network Access Restrictions** .
    
3.  Select one of the following options:
    
    1.  **Configure Restrictions** - Decide where to allow or block local network access requests. You will then need to enter the **Auto Allow Local Network Access List** _or_ the **Block Local Network Access List**.
        
        If a Local Network is configured to be blocked and allowed, the block takes precedence.
        
    2.  **Use default restrictions** - Users will be prompted for all local network access.
        
    
4.  Click **Set**.