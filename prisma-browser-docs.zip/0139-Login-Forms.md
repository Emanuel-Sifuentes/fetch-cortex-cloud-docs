---
title: "Login Forms"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules/login-controls/login-form"
depth: 5
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Rules > Manage Prisma Browser Access and Data Control Rules > Login Controls > Login Forms"
updated: "Mar 12, 2026"
---

# Login Forms
The new login controls for Access and Data Control Rules

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Select Login Form to configure this method:

Use the feature as follows:

1.  The Login Controls sub-page allows you to control logging into the applications and websites using the Prisma Browser. Use the feature as follows:
    
    1.  Select the **Login Form**.
        
    2.  In the **Control form-based login** page, select the following login type:
        
        1.  **Allow** - Allow login to the selected sites using any username and password.
            
        2.  **Block** - Block login to the selected sites.
            
        3.  **Allow specific email domains** - Allow login to the selected sites with usernames that are from specific email domains only.
            
        4.  **Block specific email domains** - Block login to the selected sites with usernames that are from specific email domains only.
            
        
    3.  In the **Email domains** tab, enter the email domains that will be used.
        
        This step is only available if you selected **Allow specific email domains**, or **Block specific email domains**.
        
        1.  Enter the email domain in the form "@example.com."
        2.  Click **Add email domain**.
        3.  Repeat as needed.
        
    4.  In the **Prompt** tab, select one of the following options:
        
        1.  **None:** No prompt is needed for this rule.
        2.  **Pop-up notification** \- Select one of the following options:
            
            1.  **Warn and allow to proceed anyway** - Users will receive a warning but they can proceed anyway.
                
            2.  **Warn and allow to proceed anyway with a reason** - Users will receive a warning but they can proceed if they provide a reason.
                
            3.  **Permission Request** – You will receive a message requesting permission.
                
        3.  **Bypass timeframe** – Indicate how long any bypass will be valid.
            
        
    5.  **MFA** - Require users to complete an additional authentication (such as a PIN code, Passkey, or IdP authentication) before allowing form login to the scoped websites. Configure the authentication factor used under **[Browser Security > Browser Hardening > Authentication Factor](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-browser-hardening.html#configure-browser-hardening_task-ydp_f2l_hcc)**then select this option.
        
    6.  Set the **Account Protection** – Ensure that login is only possible from the browser by protecting the password during password reset.
        
        1.  **Enable account protection for shared accounts:** Users will be able to use shared accounts without needing to share the same actual password All shared accounts will have the same password protection.
        
    7.  If you want to configure a custom **Dialog text** that will appear when the user is blocked, you can enter the message title and description here.
        
    8.  Click **Set**.
        
    9.  Select Next: Data controls.