---
title: "Deploy the Prisma Browser Extension"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/deploy-the-prisma-access-browser-extension"
depth: 2
breadcrumbs: "Home > Prisma Browser > Deploy the Prisma Browser Extension"
updated: "Feb 10, 2026"
---

# Deploy the Prisma Browser Extension
This article describes how to deploy the popular Prisma Access Browser Extension.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

The Prisma Browser Extension is a tool that you can install on commercial browsers such as Google Chrome and Microsoft Edge browsers, running on Windows, macOS, and ChromeOS Operating Systems.

IT and security teams can enhance organizational security by implementing Prisma Browser with a hybrid strategy, using the Prisma Browser Extension to bridge current browsing practices with advanced protections. This approach enables employees to continue using familiar browsers while administrators gain greater visibility and control over all browsers across the enterprise.

The extension actively monitors user activity on commercial browsers, helping to mitigate Shadow IT risks and providing real-time phishing protection. By centralizing visibility and allowing consistent enforcement of Security policy rules, the Prisma Browser Extension integrates smoothly with existing tools while guiding users to the enterprise browser when accessing sensitive applications.

## Supported Installation and Deployment

**Mobile device management (MDM)**

-   Intune
    
-   Jamf
    
-   Google Workspace
    

**Manual installation with the supplied extension files for macOS and Windows**

-   The primary uses for manual installations are PoC and Installation on managed Windows devices.
    

### Prisma Browser Extension Software Download

You can download the Prisma Browser Extension from the Strata Cloud Manager.

1.  Open the Strata Cloud Manager, and select Workflows -> Prisma Access Setup -> Prisma Access BrowserConfiguration → Onboarding. .
    
2.  In the **Onboard Users** section, locate Prisma Browser and click **View**.
    
3.  Click Step 5 Download and Distribute.
    
4.  Click **Deploy PABX (Prisma Browser Extension) for Streamline Visibility & PA Browser Enforcement**.
    
5.  In the Generate Configurationsection, select the following information from the drop-downs:
    
    1.  Identity provider (IdP) - Select the IdP that you use in your environment. This is the tool that authenticates your users. The available identity providers (IdP) are:
        
        -   Okta
        -   Azure
        -   Google
        
    2.  Device Management - Select the mobile device management (MDM) that you will use to deploy the Prisma Access Browser Extension to managed devices. The available MDMs are:
        
        -   Jamf
        -   Google Workspace
        -   Windows Registry
        -   Manual Deployment (local)
        
    3.  Browser - Select the browser where the Prisma Browser Extension will be installed. The available browsers are (you can select any combination of the browsers listed):
        
        -   Chrome
        -   Edge
        -   Brave
        -   Arc
        -   AI Browsers
            -   Comet
            -   Dia
            -   ChatGPT Atlas
        
        The proper combination of these three controls will create the necessary files for the selected deployment method.
        
    
6.  Click **Generate**.
    

### Deploy the Prisma Browser Using PowerShell

If you need to deploy Prisma Access Browser Extension using a PowerShell script, you need to make the following changes to the above steps.

-   In Step 4, select the following options:
    -   **Identity provider:** Azure.
    -   **Device management:** Windows MDM.
    -   **Browser:** Select the relevant browser from the list.
-   Click **Generate.**
    
-   Click **Download .ps1 file.**
    
-   Click **Done.**
-   Open Step 2 and follow the directions to set the hostname.

### Deploy the Prisma Access Browser Extension Using Intune

Microsoft Intune™ is a cloud-based endpoint management solution. It manages user access to organizational resources app and device management across your many devices, including desktop and laptop computers, mobile devices, and virtual endpoints.

For this example, we will generate a configuration with the following parameters:

-   Identity provider - Okta
-   Device Management - Windows Registry
-   Browser - Chrome, Edge

1.  Select the parameters from the dropdown lists.
    
    1.  Click Generate.
        
    2.  Click Download .reg file
        
    3.  Click Done.
        
    
2.  Copy the generated script, and run it in Intune to identify the devices by hostname. Click Done.
    
    The script is generated according to the selections that you made. If you change the parameters (for example, adding a new browser) you will need to generate a new script and rerun it in Intune.
    
3.  Optionally, go to the [Device Management](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-devices?otp=task-yrh_lp1_gcc#task-yrh_lp1_gcc) page to make sure that the new devices are displayed.
    

### Manually Deploy the Prisma Browser Extension

Manual installations of Prisma Browser Extension are primarily intended for proof of concept (PoC) purposes. The primary Prisma Browser Extension deployment will be on managed devices via a mobile device management (MDM) platform, enabling scalable distribution to a large number of users.

#### macOS Deployment

To manually install the Extension for iOS, follow these steps:

1.  Go to System Settings, and search for Profiles. Approve the Profile (It will have a warning mark beside it) .
    
2.  Download the extension configuration file to the extension PAB-install-locally.mobile.confif.
    
3.  Go to System Settings, and search for Profiles. Approve the Profile (It will have a warning mark beside it) .
    
4.  Restart the browser to apply the settings.
    
5.  To install, navigate to your Download folder. Right-click and select Open with > Profile Installer.appi
    
6.  Go to System Settings, and search for Profiles.
    
7.  Double-click the object to open the installation option.
    
8.  Click Install...
    
9.  Follow the instructions to verify the installation. You may be asked to authenticate as part of the installation.
    
10.  You will need to restart after the installation is complete.
     
11.  The Prisma Browser Extension will be visible in the browser. Click the extension to Connect Before Logon.
     

#### Windows Deployment

To manually install the Extension for Windows, follow these steps:

1.  Download the generated registry file.
    
2.  Install the registry file on Windows 10 or Windows 11.
    
    1.  Double-click on the .reg file.
        
    2.  If User Account Control is enabled, you might be asked if you want to allow the program to make changes to your computer. If it does, click **Yes**.
        
    3.  You will be asked "Are you sure you want to continue?" Click **Yes**.
        
    
3.  You can also manually deploy the Prisma Browser Extension by doing the following:
    
    1.  Send the registry file to your users via email.
        
    2.  Save the registry file on a shared network location.
        
    3.  Add a command to your users' login script.
        
    4.  Add the registry command to your command prompt.
        
    5.  Specify the name and path of the registry file that needs to be copied into the registry.
        
    
    After importing the registry file on Windows machines, users will need to restart their browser to make sure that the Prisma Browser Extension installed on their browser.