---
title: "Cloud Provider - Google Drive"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/cloud-storage-integrations/cloud-provider-google-drive"
depth: 3
breadcrumbs: "Home > Prisma Browser > Cloud Storage Integrations > Cloud Provider - Google Drive"
updated: "Feb 10, 2026"
---

# Cloud Provider - Google Drive
This document contains the directions for integrating Google Drive as the cloud provider

## Google Drive Prerequisites

These are the prerequisites for configuring Google Drive as your cloud provider:

-   Super Admin role in the Google Workspace Admin Console.
-   Role on a Google Cloud Platform (GCP) project. You need one of the following toles:
    -   **Service Account Creator** (roles/iam.serviceAccountCreator)
    -   **Service Account Key Admin** (roles/iam.serviceAccountKeyAdmin)
    -   **Service Usage Admin** (roles/serviceusage.serviceUsageAdmin)
    -   **Project Editor** role (roles/editor)

End users require a valid Google Workspace License. The supported SKUs include:

-   Google Workspace Business Starter
-   Google Workspace Business Standard
-   Google Workspace Business Plus
-   Google Workspace Enterprise Standard
-   Google Workspace Enterprise Plus

## Configure Google Drive as the Cloud Provider

This document outlines the steps required to onboard Google Drive as a cloud Storage Provider for use with Prisma Browser’s **Save to Cloud** feature. This process involves configuring access through Google Cloud Platform (GCP) and delegating domain-wide authority in the Google Workspace Admin Console.

1.  Enable the Google Drive API in GCP.
    
    1.  Open a browser tab and navigate to the Google Cloud Console.
        
    2.  **Select or create** a project that will be used for the integration.
        
    3.  In the left side menu, go to **APIs & Services → Enabled APIs and Services**.
        
    4.  Click Enable **APIs & Services**.
        
    5.  Select **Google Drive API** and click **Enable** on the details page.
        
    
2.  The Service Account allows the browser to upload files by generating a one-time token per upload, eliminating the need for the user to log in each time.
    
    Create a Service Account.
    
    1.  In the **Google Cloud Console**, go to the project you selected in the previous step.
        
    2.  Navigate to **IAM & Admin** and select **Service Accounts**.
        
    3.  Click **\+ Create service account**.
        
        1.  Enter a Service account name. This name will be displayed in the Google Cloud Console.
        2.  Click **Create** and continue to generate the Service account ID. You can edit it, if needed.
        3.  Optionally, enter a Service Account description.
        4.  Click **Done**.
            
        
    4.  Continue through the steps until the service account is created.
        
    
3.  Generate a Private Key (JSON)
    
    1.  Locate your newly-created service account in the list.
        
    2.  Click the **More (⋮)** icon under the Actions field, and select Manage Keys.
        
    3.  Click **ADD KEY** → **Create new key**.
        
    4.  Choose **JSON** as the key type and click **Create**.
        
    5.  The system downloads a private key file to your computer. **Store this file securely**; it authenticates the service account.
        
    
4.  Retrieve the Client ID
    
    1.  Go back to the **Service Accounts** page in the Cloud Console.
        
    2.  Click the name of your service account to open its details.
        
    3.  Under the **Details** tab, locate the **Client ID** and copy it. You will use this in the next step.
        
    
5.  Delegate Domain-Wide Authority in Google Workspace.
    
    1.  Open a browser and navigate to the[**Google Admin Console**](https://admin.google.com).
        
    2.  Sign in using a **Super Admin** account.
        
    3.  From the left-hand menu, go to **Security** → **API Controls**.
        
    4.  Scroll to the **Domain-wide delegation** section and click **Manage Domain Wide Delegation**.
        
    5.  Click **Add new** to add a new Client ID.
        
    6.  In the **Client ID** field, paste the ID you copied from your service account.
        
        In the **OAuth Scopes** field (comma-delimited), enter the following scopes:
        
        -   https://www.googleapis.com/auth/drive.file
        -   https://www.googleapis.com/auth/drive.metadata.readonly
        
    7.  These scopes allow the service account to access and manage Google Drive files on behalf of users within the domain.
        
    8.  Click **Authorize** to complete the delegation process.
        
        **Why are the Scopes required?**
        
        ​​These scopes adhere to the principle of least privilege, ensuring the application only has the permissions required to perform its core functions — securing connections and managing file downloads effectively to the organizational cloud.
        
    9.  These scopes allow the service account to access and manage Drive files on behalf of users within the domain.
        
        | drive.metadata.readonly | Used to list folders in the user's drive |
        | --- | --- |
        | drive.file | Used to upload files to the user's drive |
        
        By using **domain-wide delegation**, Prisma Browser can upload files to an end-user's Google Drive without any user interaction. This process leverages the user's browser sign-in context, eliminating the need for them to be actively signed into Google.
        
        For security, Prisma Browser uses a **short-lived access token** to upload files to Google Drive. This token is created only when a file download triggers a matching cloud storage rule and is strictly scoped to the signed-in user, which prevents extensive access.
        
    
6.  Create the integration with the Prisma Browser Console.
    
    1.  Go to the Prisma Browser admin console and select **Integrations**.
        
    2.  Select **Cloud Storage**.
        
    3.  Click on either **+add provider** or **Connect your first provider**.
        
    4.  Select **Google**.
        
    5.  Insert a descriptive name for connection; for example, your Google tenant name.
        
    6.  Upload the JSON file.
        
    7.  Enter an email to verify permissions.
        
        -   This step secures your organization’s data and enhances user productivity by integrating with your managed cloud storage services. Instead of allowing direct file downloads to user devices, our **'Save to Cloud'** feature automatically redirects them to your organization’s cloud storage.
            
            This method ensures that you can enforce your data protection policies and give users seamless access to their files across all their devices, which supports better collaboration and a smoother workflow.
            
        -   To ensure that you have configured the permissions correctly, you must use the email of an active, licensed user in your organization. The system uses this email solely for a permissions check; it **will not** send emails or upload any files to the account.
        
    8.  Click **Test provider connection** to verify the connection with Google.
        
    9.  Once the test is successful, click **Add Provider**.
        
    

## Known Limitation

HTML sites will be compressed using zip format and saved in a folder. The Prisma Browser does not support unzipping files. As a result, this is not recommended.