---
title: "Configure Prisma Browser Device Posture Attributes"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-devices/prisma-access-browser-device-posture-attributes"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Devices > Configure Prisma Browser Device Posture Attributes"
updated: "Mar 12, 2026"
---

# Configure Prisma Browser Device Posture Attributes
Define the device posture attributes that determine device group membership.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

In Prisma Browser, you can add attributes as match criteria when you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc). Because Prisma Browser policy rules are enforced at the device group level, the attributes provide granular security that ensures the devices that Prisma Browser allows to access your apps are adequately maintained and adhere with your security standards before they are allowed access to your network resources. For example, before allowing access to your most sensitive apps, you might want to ensure that the devices accessing the apps have encryption enabled on their hard drives. In this case, you would create a device group with an attribute that only allows devices that have encryption enabled. The following sections detail the attributes you can use to determine device group membership for Windows, macOS, and Linux devices. Please use the relevant filter (Windows/macOS/Linux/IGEL) to filter relevant and supported device group attributes per OS ”

With this feature, you can also select negative attributes. This means that you can create a device group that does not include devices made by Dell.

To learn about the attributes for controlling device group membership for mobile devices, see [Configure Prisma Browser Mobile Device Posture Attributes](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices/prisma-access-browser-mobile-device-posture-attributes.html).

## Negative Postures

In some cases, you may want to **exclude** certain device attributes rather than require them. This is called creating a **negative posture**.

For example, you might normally create a rule that **requires** devices to run a specific operating system. However, if a new rule requires that devices **must not** use that operating system, you can use a negative posture instead.

This feature allows you to define rules that **explicitly exclude** certain attributes—such as a particular operating system—from being allowed.

## OS Versions

Creating a device group that uses the device's operating system as a posture is a good way to make sure that users have specific versions of the OS. If you add an OS version attribute as match criteria for a device group, Prisma Browser checks the device OS version matches the attribute you defined before allowing membership in the device group.

Define the list of acceptable operating system versions for the Prisma Browser posture mechanism to check as follows.

1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), add the OS version attribute.
    
2.  Select the Windows, macOS, or Linux versions, editions, and build numbers to allow into the device group and then click Save.
    
    Windows build numbers should include the revision number as well. This helps ensure that the most up-to-date security patches and features are installed.
    
3.  Click **Save**.
    
    **What does the Prisma Browser check?**
    
    _Windows devices_
    
    -   Run the command WIINVER to open the About Windows information.
        
    -   The command WMIC OS GET VERSION will also display the information, however if the version on the device was upgraded (for example, Windows 10 to Windows 11), the result may not be correct. In this case, use the WINVER command.
    
    _macOS devices_
    
    -   In the System Settings, search or select "macOS."
    -   Click **About**.
        
    
    _Ubuntu devices_
    
    -   Via GUI settings - Go to _Show_
    -   _Applications->Settings->System->About_
        
    
    Via command line - using following command - _cat /etc/os-release_
    
    _Fedora devices_
    
    -   Via GUI settings - Go to _Show Applications->Settings->System->About_
        
    -   Bia command line - use the following command. _cat /etc/os-release_
    

## Serial Number

Creating a device group that uses device serial numbers as match criteria is a good way to ensure that only specific devices have access to the Prisma Browser. Before you can add a serial number attribute to a device group, you must create a .txt or .csv file containing the list of serial numbers. The file you create can't exceed 600 KB.

1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), add the serial number attribute.
    
2.  Drag and drop or browse for the file containing the list of serial numbers. The file must be in CSV or TXT format. The serial numbers must be separated by commas or semicolons, or in a file with one serial number per line.
    
3.  If necessary, remove any serial numbers that you do not want to include in the group.
    
4.  Click Set.
    
    **What does the Prisma Browser check?**
    
    While the serial number often appears on a sticker or label on the device, these numbers aren't always accurate. Use the following methods to get the correct serial number.
    
    _Windows devices_
    
    -   Open a Command Prompt and enter the command wmic bios get serialnumber
        
    
    _macOS devices_
    
    1.  In the System Settings, search or select "macOS."
    2.  Click **About**.
        
    

## Issuer Certificate

To ensure that only devices that use a client certificate signed by your organization for authentication, create a client certificate attribute as match criteria for your device groups so that you can distinguish between managed and unmanaged devices. To use a client certificate attribute, you must upload the intermediate certificate or intermediate or root certificate to create the attribute. When determining if a client certificate matches the issuer certificate in the attribute, Prisma Browser matches against the authorityKeyIdentifier. If you need to trust multiple CAs, you can upload multiple certificates.

Device groups can match against multiple certificates. To add a new Issuer (root or intermediate) certificate:

1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), add the client certificate attribute.
    
2.  Drag and drop one or more certificate .PEM files to the Issuer certificates dialog.
    
3.  Click Set.
    
    You need to upload **issuer certificates** that issued the **client certificates** located on the devices.
    
    **Client Certificate Requirements:**
    
    -   Stored in the **Current User → Personal** stopr. \[Windows only\].
    -   Valid Client Certificate with a private key attached.
    
    **Issuer Certificate Requirements**
    
    -   Contains either the intermediate or both the intermediate and root chains that signed the client certificate.
    -   It must not be the actual client certificate and should not contain a private key.
    
    -   If you need to trust multiple CAs, then you can upload multiple certificates.
    -   Prisma Browser matches the certificates' **authorityKeyIdentifier** when matching an issuer certificate to a client certificate
    
    **What does the Prisma Browser check?**
    
    _Windows devices_
    
    1.  To manually verify a device meets the criteria, open the current user store, and select **Start > Manage user certificates**.
    2.  Navigate to **Personal → Certificates** and validate:
        -   Yjhe client certificate exists here.
        -   The certificate contains a private key.
        -   The issuer matches the issuer f the certificate.
        -   You can compare the thumbprint of the certificates.
            
        
    
    The authority key identifier matches the issuer certificate identifier.
    
    _macOS devices_
    
    1.  From the Launcher, search for Keychain Access.
    2.  Click **Certificates** and search for the required certificate.
        
    3.  Validate that the company client certificate exists.
    4.  Validate that the authority key identifier matched the issuer certificate identifier.
    

## Disk Encryption

**Disk encryption** is a data security feature that converts data on a storage device (like a hard drive or solid-state drive) into an unreadable format. This process, known as **cryptography**, uses an algorithm to scramble the data and an encryption key to lock and unlock it. Without the correct key, the encrypted data appears as gibberish, making it incomprehensible and unusable to unauthorized individuals.

**Key benefits:**

-   **Data Confidentiality:** The primary benefit of disk encryption is protecting sensitive information, such as **Personally Identifiable Information (PII)** and financial records. If a device is lost or stolen, the data on the drive remains secure and unreadable to anyone without the key.
    
-   **Regulatory Compliance:** Many industries and government regulations, such as **HIPAA** or **GDPR**, require strict data protection measures. Disk encryption is a fundamental tool for meeting these compliance standards and avoiding legal penalties.
    
-   **Breach Prevention:** By encrypting data at rest, you significantly reduce the risk and impact of a data breach. Even if an attacker bypasses other security layers, the stolen data will be useless without the encryption key.
    
-   **Security for Portable Devices:** Devices like laptops and external hard drives are highly susceptible to loss or theft. Disk encryption provides a crucial layer of security, ensuring that the data on these devices is protected wherever they are.
    
    If you previously used File System Encryption, you will be migrated to this feature as follows:
    
    -   If **File System Encryption** was _Enabled_, then the **Disk Encryption** will be set to **Any Vendor**. You can then change it as needed.
    -   If **File System Encryption** was _Disabled_, then the **Disk Encryption** will not be set, and you will need to configure it as needed.
    
    A device will be matched if at least one of the disks is encrypted.
    

1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), enable the you can enable Disk Encryption.
    
2.  Click the Disk Encryption check box, choose whether you need a positive (IS) or negative (IS NOT) and click **Select Vendors**.
    
3.  Select the appropriate vendors you require for devices accessing your network.
    
    -   Select **Any vendor** to include all vendors to include in the device group.
    -   Filter by **Common vendors** to select from the most common vendors.
    -   Filter by Selected only to create your own custom group of vendors.
    
4.  Click Set.
    

## Screen Lock

Active screen lock mechanisms limit device access to authorized users only, preventing malevolent players from gaining access to confidential information on the device in the event that the user steps away from the device. When you enable the Active screen lock attribute in a device group, Prisma Browser verifies that the device is enabled with an automatic screen lock, password, PIN, biometric, or similar lock feature before allowing access to the group. To pass this check, a device must meet the following requirements:

_Windows device_

There are two locations where you can set the options for an active screen lock:

1.  **Screen saver settings** - this setting can be left as _None_.
2.  **Windows Power Settings**
    
    1.  Open the **Screen Saver** settings (either option can be selected.
        
    2.  Select On resume, display logon screen.
    3.  Select a time in the **Wait** **_n_** **minutes**. This will be the time that the device will wait before activating the screen lock.
    4.  Click **Apply**.
    
    The Active Screen Lock is now activated.
    
3.  **Sign-in Options**
    -   In the **Accounts > Sign-in** options, scroll to Additional settings.
    -   In the field _If you've been away, when should Windows require you to sign in again?_, select one of the options.
        
        Selecting **Never** does not activate the screen lock.
        
        The Active Screen Lock is now activated.
        
        In Windows 10 devices, this option is found under Require sign-in.
        

_macOS devices_

The active screen lock for macOS devices is based on code that the Prisma Browser developers contributed to the Chromium project.

1.  From the Apple menu select **System Preferences > Security & Privacy**.
2.  If the lock icon on the lower left is locked, click it and enter the password.
3.  In the **General** tab, in the Lock Screen section, select **Require password after screen saver begins or display is turned off**, and make sure there is a time value set.
    

## Endpoint Protection

Devices secured with active endpoint protection have antivirus, anti-malware, firewall protection, and intrusion detection and prevention features, which work in concert to identify and block malicious activity. If you enable the endpoint protection attribute within the device group, Prisma Browser checks for active endpoint protection before allowing the device into the device group. A device must meet the following requirements to pass this check:

When configuring attributes to check for endpoint protection, you can select specific endpoint protection vendors to check for on the device as follows:

1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), enable the endpoint protection attribute.
    
2.  Select the endpoint protection vendors you require devices accessing your network to use. You can select **Any vendor** to include any endpoint protection vendor,
    
3.  (Optional) Enable Verify definitions are up to date (supported vendors only) to add an additional check to ensure that the endpoint protection software on the device is up-to-date.
    
4.  Click Set.
    
    **What does the Prisma Browser check?**
    
    _Windows devices_
    
    Prisma Browser checks the Endpoint Protection in the Windows Security Center. The posture check is made by checking that the Virus & threat protection is turned on.
    
    The **Security at a glance** page displays the Endpoint protection status of the device.
    
    Clicking on one of the icons above will display more detailed information regarding the installed EPP.
    
    _macOS devices_
    
    For macOS devices, Prisma Browser looks at the **Extensions** in the **System Preferences**.
    

## Device Type

Use the device type attribute to ensure that the device group only contains specific types of devices—such as laptops or desktops—as follows:

-   **Windows devices**—Prisma Browser checks to see if the device is a laptop or desktop based on whether or not it has a battery.
    
-   **macOS devices**—Prisma Browser checks the hardware device machine type.
-   **VM Detection**—Prisma Browser looks at the way the particular operating system views the CPU. The result is based on the CPU internal datasets.
-   **Unknown**—This is an atypical result. It is only applicable if the posture mechanism cannot determine the hardware properties.

If Prisma Browser can not determine the device type it identifies it as unknown.

You can select the device type to include in your group by selecting the appropriate type.

## CrowdStrike ZTA Scores

CrowdStrike Zero Trust Assessment (ZTA) delivers real-time security posture assessments across all endpoints regardless of location, network, or user. CrowdStrike ZTA enables enforcement of dynamic conditional access based on device health and compliance checks that mitigate the risk to users and the organization. Prisma Browser can use the ZTA assessment score as access criteria.

To use the ZTA score as part of the device posture assessment for determining access to Prisma Browser you must:

1.  Enable the ZTA score calculation for all devices (Host setup and managementZero trust assessmenthosts).
    
2.  Find your CrowdStrike Customer ID.
    
    You can find this inside your CrowdStrike user profile. Click on the account email to view this information.
    
3.  Open a support ticket with CrowdStrike to enable the ZTA feature flag.
    
    This allows Prisma Browser to access the CrowdStrike Agent ID. To open the support ticket, you will need the customer ID you just obtained.
    
4.  Integrate the ZTA score with Prisma Browser.
    
    After CrowdStrike enables the ZTA feature flag, you can integrate with as follows:
    
    1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), select CrowdStrike ZTA Score.
        
    2.  Select the type of score you want to use:
        
        -   Basic—Use the overall score that CrowdStrike assigns to the device, based on a range of Low (at least 65), Medium (at least 70), Strict (at least 80), or Very Strict (at least 95).
        -   Advanced—Fine-tune the configuration to select either a specific Overall security score, or a Score breakdown, based on the OS and sensor values. Use the sliders to select the required score.
        
    
5.  Enter the CrowdStrike customer identification number associated with the CrowdStrike agent.
    
    Add additional CrowdStrike IDs as needed to connect to all agents.
    
6.  Click Set.
    

## OS Password Protection

Use the OS password protection attribute to restrict device group membership to devices that are password protected. You can also specify that the device must have additional password policy enforced, such as password complexity, maximum age, or maximum length. To determine this, Prisma Browser looks for the following settings on the device:

-   **Windows devices**—Prisma Browser checks the following Password Policy settings in the local Security Settings (Security SettingsAccount PolicyPassword Policy): Maximum password age, Minimum password length, and Password must meet complexity requirements.
    
-   **macOS devices**—Prisma Browser checks the local password requirements in the management configuration profile (ManagementConfiguration profilesAddmacOSPassword): Allow simple value, Require alphanumeric value, Minimum length, Munimum number of complex characters, Expiration age, or History restriction.
    

1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), enable the OS password policy attribute.
    
2.  Select the endpoint protection vendors you require devices accessing your network to use.
    
3.  Select the password policy settings that must be enforced on devices for inclusion in the device group.
    
4.  Click Save.
    

## Device Manufacturer

Use the device manufacturer attribute to restrict device group membership to Windows or macOS devices from selected manufacturers.

1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), enable the device manufacturer attribute.
    
2.  Select the device manufacturers you want to support in the device group.
    
3.  Click Save.
    

## System Integrity

Use the system integrity attribute to ensure that the device group only allows devices that have advanced system integrity protection enabled. Prisma Browser determines if a device qualifies as follows:

-   **Windows devices**—Prisma Browser checks to ensure that driver test signing is off and no kernel debugger is present. Additionally, on UEFI computers, it verifies that secure boot is enabled.
-   **macOS devices**—Prisma Browser checks to ensure that System Integrity Protection (SIP) and Gatekeeper are enabled.

## Normal OS Boot Mode

Enable this attribute to create a device group that requires the devices to run in full boot mode. This excludes devices that are running in safe mode, recovery mode, or devices running in a pre-installation environment.

## Privileged Process

This attribute allows you to create device groups where the Prisma Browser runs without any elevated or root permissions.

## Device Management

This attribute allows you to create device groups that use approved device management systems. The Prisma Browser supports the following systems:

-   Microsoft Intune
-   Azure AD
-   Active Directory (Windows only)
-   Jamf (macOS only)

1.  When you [add or edit a device group](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#task-hns_lt1_gcc_substeps-lrz_dz4_gcc), enable the device management attribute.
    
2.  Select the device management systems you want to allow in the device group.
    
3.  Click Set.
    

## **Registry Keys (Windows only)**

The Registry Key attribute allows you to create policy and posture rules based on the existence of a particular custom attribute that is placed in the Registry Keys. Using this feature, you can use more than one key as part of the device group; Prisma Browser will make sure that the devices will have all of the keys that were selected.

1.  Select _is / is not_ to determine if the requirement is a positive attribute (the key exists in the device) or a negative (the key does not exist in the device).
2.  Click **Configure**.
    
3.  Enter the full path of the key that forms the group. For example - HKEY\_CURRENT\_USER\\Control Panel\\Desktop.
4.  Enter the Value name (optional) and a Value type (optional).
    
5.  Click **Set**.

## Processes

The Processes attribute allows you to create device posture rules based on whether or not specific processes are running. This feature allows you to create Device Posture Attribute rules for computers running both Windows and macOS systems. This means that you can create one attribute for both.

When this attribute is selected, the Prisma Browser will make sure that the specified process is running (or not running) as you require.

1.  Select **Processes**.
2.  Select _is / is not_ to determine if the requirement is a positive attribute (the process is running in the device) or a negative (the process is not running in the device).
    
3.  Click **Configure**.
4.  In the **Processes** window, do the following for each process that you need to add:
    1.  Click **Add Process**.
    2.  Select the operating system related to the process. You can select Windows or macOS.
    3.  Enter the Process name on the process path.
    4.  Optionally enter the **Team ID** (macOS) or the **Certificate Thumbprint** (Windows):
        -   For machines running **macOS**:
            1.  Open the Terminal.
            2.  Enter the code codesign -dv followed by the full file path.
                -   For example codesign -dv '/Applications/Prisma Access Browser.app/Contents/MacOS/Prisma Access Browser' will provide te Team ID for the Prisma Browser.
        -   For machines running **Windows**:
            1.  Locate the Process.
            2.  Right-click on the process and select Properties.
                1.  On the Digital Signature tab, select the required certificate and click Details.
                2.  The Digital Signature Details window is displayed. Click View Certificate.
                3.  On the Details tab, save the Thumbprint.
    5.  Click **Set**.
        

**Locating Processes on macOS machines**

Open the Activity Monitor, locate the process, double click, and copy the executable path,

Or use the process name from the Activity Monitor.

**Locating Processes on Windows machines**

Process must have a .exe extension.

Open the Task Manager, right click on one of the columns, and copy the information from the Process Name column.

## Files

The Files attribute allows you to create device posture rules based on whether or not specific files located on the machine. This feature allows you to create Device Posture Attribute rules for computers running both WIndows and macOS systems. This means that you can create one attribute for both.

When this attribute is selected, the Prisma Browser will make sure that the specified files are located on the machine.

1.  Select **Files**.
2.  Select _is / is not_ to determine if the requirement is a positive attribute (the file is located on the device) or a negative (the file is not located on the device).
    
3.  Click **Configure**.
4.  In the **Files** window, do the following for each file:
    
    1.  Click **Add File**.
    2.  Select the operating system related to the process. You can select Windows or macOS.
    3.  Enter the File Path.
    4.  Optionally enter the **Team ID** (macOS) or the **Certificate Thumbprint** (Windows):
        -   For machines running **macOS**:
            1.  Verify that a process is running on the device and is signed by the specified Apple Team ID.
                
            2.  Enter the code codesign -dv followed by the full file path.
                
                -   For example codesign -dv '/Applications/Prisma Access Browser.app/Contents/MacOS/Prisma Access Browser' will provide te Team ID for the Prisma Browser.
                
                ```
                codesign -dv '/Applications/Prisma Access Browser.app/Contents/MacOS/Prisma Access Browser' 
                ```
                
        -   For machines running **Windows**:
            1.  Locate the Process.
            2.  Right-click on the process and select Properties.
                1.  On the Digital Signature tab, select the required certificate and click Details.
                2.  The Digital Signature Details window is displayed. Click View Certificate.
                3.  On the Details tab, save the Thumbprint.
    5.  Click **Set**.
    

## Browser Version

In some cases, administrators may not have full control over browser deployment through MDM services and must rely on users to manage their own browser updates. Additionally, browser end-of-life status can sometimes be overlooked or forgotten. As a result, outdated browser versions may continue to run, exposing systems to vulnerabilities and other risks.

To address this, Prisma Browser now lets you create device groups based on whether a browser has reached its end of life.

Browser Version support is available on Windows and macOS platforms.

## OS Location Services

The Prisma Browser uses two methods to detect a user's location:

-   OS Location Service (requires specific permissions)
-   GeoIP

The Location Service uses system-level APIs to obtain precise, real-time geographic coordinates, provided the necessary permissions are granted. This method is preferred for its high level of accuracy and consistency. Prisma Browser can now enforce the use of the operating system’s native Location Services to ensure more reliable and precise location data.

In contrast, GeoIP-based location determination relies on IP address mapping, which is inherently less accurate. GeoIP results can be affected by various external factors, leading to potential inaccuracies.

OS Location Services support is available on Windows and macOS platforms.

### Locating the OS Location Service Configuration

**macOS**

Open **System Settings → Privacy and Security → allow applications to access your location**.

**Windows**

Open **Settings → Privacy and Security → App permissions → Location → Let apps access your location**.

## Firewalls

This feature gives you greater security and compliance control over device access. Now, you can configure granular access policies using a new **"Firewall"** device group attribute.

This new attribute allows you to permit any firewall vendor or select specific, approved vendors from an expanded, categorized list. The system also gives you a more comprehensive view of all detected firewall products and their status.

Older browser versions will continue to detect only native firewalls until you install a new version.