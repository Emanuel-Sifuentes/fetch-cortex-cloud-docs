---
title: "Deploy the Prisma Browser via MDM"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/deploy-prisma-access-browser"
depth: 2
breadcrumbs: "Home > Prisma Browser > Deploy the Prisma Browser via MDM"
updated: "Feb 10, 2026"
---

# Deploy the Prisma Browser via MDM
## Deploy using IGEL

deploy PAB using IGEL

Prisma Browser installation and update over IGEL OS is performed via the **IGEL App Portal**. For more information, refer to the [IGEL App Portal](https://app.igel.com/).