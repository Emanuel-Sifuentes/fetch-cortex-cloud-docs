---
title: "Configure Printers"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-printers"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Security Controls > Configure Printers"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure Printers
The is the Browser Security Network configuration

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Allowed Printers

Mobile Browser - **No support**

The Prisma Browser allows you to configure particular printers for users who need to print from the browser. This provides an additional level of security, where end-users will only be able to print to permitted devices, such as printers in the office.

This feature does not preclude users from printing from other devices when using applications not managed through the Prisma Browser.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Allowed Printers.
    
3.  Select one of the following options:
    
    -   **No printers** – end-users cannot print from the browser.
        
    -   **Set printers** - Click **Add Printer** to enter the network location of each printer that end users will be able to select when printing is required.
        
    
4.  Click Set.