---
title: "Prisma BrowserClear"
url: "https://docs.paloaltonetworks.com/prisma-access-browser"
depth: 0
breadcrumbs: "Home > Prisma Browser"
updated: "Jan 11, 2026"
---

# Prisma BrowserClear
Updated on

Jan 11, 2026

Focus

1.  [Home](/)
2.  [Prisma Browser](/content/techdocs/en_US/prisma-access-browser.html)

Prisma Browser

* * *

_The only SASE-native secure browser that empowers secure work for any user, any device, any app, anywhere._

The modern workspace is defined by agility, device choice (BYOD), and the use of GenAI—all while facing a surge in threats hidden within encrypted traffic and unmanaged endpoints. **Prisma Browser** provides the strategic solution to this challenge, fundamentally transforming the browser into the primary, secure interface for work.

Prisma Browser extends Zero Trust principles across the entire application stack, from the network to the last mile. It uniquely addresses the security blind spots of web-based activity by integrating best-in-class Palo Alto Networks Cloud-Delivered Security Services (CDSS) and advanced data controls **without requiring decryption**. The result is a highly secure, frictionless, and cost-effective workspace that enables secure access to all SaaS, web, and private applications.

## Getting Started with Prisma Browser

* * *

1.  [Prerequisites for the Prisma Browser](/content/techdocs/en_US/prisma-access-browser/getting-started/prisma-access-browser-prerequisites)
2.  [Activate and Onboard the Prisma Browser](/content/techdocs/en_US/prisma-access-browser/activation-and-onboarding)
3.  [Configure the Prisma Browser](/content/techdocs/en_US/prisma-access-browser/administration)
4.  [Deploy the Prisma Browser](/content/techdocs/en_US/prisma-access-browser/deployment)

## Important Resources

* * *

1.  [General info about Secure Enterprise Browsers](https://www.paloaltonetworks.com/cyberpedia/what-is-an-enterprise-browser)
2.  [Marketing info about Prisma Browser](https://www.paloaltonetworks.com/sase/prisma-access-browser)