---
title: "File Handling and Analysis in Advanced WildFire"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/first-party-integrations/file-handling-and-analysis-in-advanced-wildfire"
depth: 3
breadcrumbs: "Home > Prisma Browser > First-Party Integrations > File Handling and Analysis in Advanced WildFire"
updated: "Feb 10, 2026"
---

# File Handling and Analysis in Advanced WildFire
How to Manage WildFire

Advanced WildFire is a cloud-delivered malware analysis service that uses a tiered approach to file inspection. This design prioritizes both strong security controls and optimal performance, especially in terms of latency

## File Size Thresholds and Reputation Checks

Wildfire is also able to scan documents via the Prisma Access Browser Extension (PABX).

Advanced WildFire evaluates all submitted files against a maximum size threshold of **300 MB**

-   **Files over 300 MB**
    -   These files bypass reputation-based scanning and never enter the WildFire knowledge base.
    -   The system applies the fall back **policy rule** configured by the administrator, which determines whether to **enable (permissive)** or **block (protective)** the file.
-   **Files 300 MB or smaller**
    -   WildFire checks the file's hash against the reputation database.
        -   If the reputation database indicates that the file is **benign**, then the system enables it.
        -   If the reputation database indicates that the file is **malicious**, then the system blocks it.
    -   For **files 20 MB or smaller**, the browser waits for a **Static Analysis verdict** before proceeding. This step mitigates security risks while minimizing end-user latency.
    -   For **unknown files between 20 MB and 300 MB**, the system defers to the administrator’s fall back policy rule to determine access, as waiting for analysis results could degrade performance.

## Dynamic Analysis of Unknown Files

The system submits all **unknown files under 300 MB** to **Dynamic Analysis**, which executes the files in a controlled environment to detect advanced threats. Although this enhances the accuracy of the WildFire reputation database, **Dynamic Analysis currently does not support file quarantine-**a capability planned for a future release.

By integrating multiple analysis layers, Advanced WildFire enables organizations to maintain robust security while minimizing disruption to end users.

## Password-Protected File Handling

Advanced WildFire attempts to scan password-protected files using a **brute-force unlocking mechanism**, subject to format compatibility and defined limitations.

## Supported File Types for Brute-Force Unlocking

The brute-force process supports the following password-protected formats:

-   .rar archive files
-   .pdf document files
-   Microsoft Office files (2007 or later), including
    -   .docx
    -   .xlsx
    -   .pptx

The system blocks scanning for password-protected files that fall outside of these formats under all circumstances.

**Brute Force Failure Handling**

If the brute-force attempt **fails** to unlock the file:

-   The file won't be scanned.
-   The returned scan verdict will be "Unknown."
    -   This ‘Unknown’ status is currently treated as **benign**, enabling the file to pass without further inspection.

## Administrator-Defined Fallbacks

You can set your own fallback policy rule when one of the following events occurs:

-   File size exceeded
-   Connection error or service unavailable
-   Unsupported file type

In all of these cases, you can decide whether to treat the file as Benign and enable it, or as Malicious and block it.

## Supported File Types

| **Extension** | **File Type** | **Extension** | **File Type** |
| --- | --- | --- | --- |
| **.7z** | 7zip Archive | **.pptx** | Microsoft PowerPoint Document |
| **.swf** | Adobe Flash File | **.slk** | Microsoft Symbolic Link |
| **.apk** | Android APK | **.iqy** | Microsoft Web query |
| **.dex** | Android DEX.bat | **.doc** | Microsoft Word 97-2003 Document |
| **.bz** | bzip2 archive | .**docx** | Microsoft Word Document |
| **.csv** | comma separated values | **.ods** | OpenDocument Spreadsheet Document |
| **.dll** | DLL/DLL64 | **.odf** | Open~Document Text Document |
| **.elf** | ELF | **.pdf** | Portable Document Format |
| **.gz** | Gzip archive | **.exe** | PE/PE64 |
| **.hta** | HTML application | **.pl** | Perl script |
| **.iso** | ISO | **.png** | Portable Network Graphics |
| **.class** | JAVA class | **.ps1** | PowerShell |
| **.jar** | JAVA jar | **.py** | Python Script |
| **.js/.jse/.wsf** | Javascript/Scipt | **.pap** | RAR Archive |
| **.jpg** | Joint Photographic Experts Group | **.rtf** | Rich Text Format |
| **.elink** | Link | **.sh** | Shell Script |
| **.macho** | Mach-o | **.tar** | TAR Archive |
| **.pkg** | macOS App Installer | **.vbs/.vbe** | VBScript |
| **.zbundle** | macOS App Bundle in ZIP Archive | **.msi** | Windows Installer Package |
| **.fat** | macOS Universal Binary File | **.Inl** | Windows Link File |
| **.dmg** | macOS Disk Image | **.wsf** | Windows Script |
| **.xls** | Microsoft Excel 97-2003 | **.zip** | ZIP Archive |
| **.xlsx** | Microsoft Excel | **.asp** | Active Server Pages |
| **.one** | Microsoft One Note Document | **.aspx** | Active Server Packages Extended |
| **.ppt** | Microsoft PowerePoint 97-2003 | **.xml** | Extensible Markup Language |
| **.html** | HyperText Markup Language |  |  |

Nested Archives are supported in zip, rar, 7z, bzip2, iso, gz, tar, vhd, docx, pptx, xlsx, jar.