---
title: "Configure Routing"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-routing"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Customization Controls > Configure Routing"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure Routing
PAB Customization Routing controls

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Proxy Auto-Configuration (PAC)File

Mobile Browser - **No support**

This feature allows you to configure the Prisma Browser to use a Proxy Auto-Configuration (PAC) file to pass some of the web traffic through a proxy or gateway. This feature overrides the system PAC file.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Proxy Auto-Configuration (PAC) File.
    
3.  Select one of the following options:
    
    -   **Set PAC File** - Configure the Prisma Browser to use a PAC file.
        
    -   **No PAC File** - Do not require a PAC file.
    
4.  Click Set.
    

## Traffic Flow

Mobile Browser - **Partial support**

The Traffic Flow control allows you to manage the way that the Prisma Access Browser handles network traffic.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Traffic Flow.
    
3.  Select one of the following options:
    
    -   **Only route private application traffic through Prisma Access.**
        
    -   **Route all traffic through Prisma Access.**
        
        Mobile Devices: To ensure an optimal experience with Network Detection and Prisma Access, either route only Private App traffic, or exclude the Mobile Device group from routing.
        
    -   **Do not route traffic through Prisma Access**
        
    
4.  Click Set.
    

## Internal Network Detection

Mobile Browser - **No support**

This feature allows you to configure internal network detection to ensure that traffic is routed in an optimal way

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Customization
    
2.  Select Internal Network Detection.
    
3.  Click **Add Extension**.
    
4.  Select one of the following options:
    
    -   Enable \- Enable Internal Network Detection. Select and configure the methods.
        -   **Internal Host Detection** \- Identify the internal network by establishing a connection with a host that is only available inside the network. Enter the following information:
            -   FQDN to resolve
            -   Expected IP addresses
        -   **Agent detection** \- Identify the internal network by detecting whether the Global Protect or the Prisma Access agent is running on the device.
    -   Disable \- Disable Internal Network Detection.
    
5.  Click Set.