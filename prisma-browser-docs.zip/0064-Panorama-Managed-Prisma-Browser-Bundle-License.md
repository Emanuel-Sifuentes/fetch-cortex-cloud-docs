---
title: "Panorama Managed Prisma Browser Bundle License"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/activate-new-prisma-access-browser-with-prisma-access-enterprise-bundle-license/activate-panorama-managed-prisma-access-browser-bundle-license"
depth: 3
breadcrumbs: "Home > Prisma Browser > Activate New Prisma Browser with Prisma Access Enterprise Bundle
        License > Panorama Managed Prisma Browser Bundle License"
updated: "Mon Feb 02 09:23:11 PST 2026"
---

# Panorama Managed Prisma Browser Bundle License
Learn how to activate your Panorama Managed Prisma Access Secure Enterprise Browser (Prisma Browser) tenants through Common Services.

After you receive an email from Palo Alto Networks identifying the license you're activating, use the activation link to begin the activation process.

Not available for Panorama multitenancy.

1.  Select Activate Subscription in your email.
    
2.  Follow the instructions for [activating a Prisma Access (managed by Panorama) license](https://docs.paloaltonetworks.com/common-services/subscription-and-tenant-management/panorama-managed-prisma-access-and-add-ons-license-activation/activate-a-license-for-panorama-managed-prisma-access-and-add-ons).
    
3.  Continue to enable the available add-ons. Products or Add-ons are enabled by default based on your contract.
    
4.  Select the Secure Enterprise Browser with Prisma Access Enterprise.
    
5.  In Panorama, go to the Panorama tabCloud Services PluginPrisma Browser tab.
    
    This launches a new tab with a pared-down version of Strata Cloud Manager that has just the Prisma Browser specific views.
    
6.  Go to the Prisma Browser [Admin Guide](https://docs.paloaltonetworks.com/prisma-access-browser/administration/use-the-prisma-access-browser-dashboards) to manage your Prisma Browser.
    
7.  (Optional) Assign roles so your admins can manage the Prisma Browser.