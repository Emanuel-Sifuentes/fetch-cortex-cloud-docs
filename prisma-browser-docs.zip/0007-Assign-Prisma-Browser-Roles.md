---
title: "Assign Prisma Browser Roles"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles"
depth: 2
breadcrumbs: "Home > Prisma Browser > Assign Prisma Browser Roles"
updated: "Mon Feb 02 09:23:11 PST 2026"
---

# Assign Prisma Browser Roles
Learn which RBAC roles and privileges are available for (Prisma Browser) administrators.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license ; [Role](https://docs.paloaltonetworks.com/common-services/identity-and-access-access-management/manage-identity-and-access/about-roles-and-permissions): Multitenant Superuser or Superuser with access to the [Customer Support Portal](https://support.paloaltonetworks.com/Support/Index) |

You can create and manage role-based access control for different types of administrators of the Prisma Browser. This allows the main administrator in a large organization to appoint additional administrators with relevant permissions for their specific roles, including visibility and access.

After activating your Prisma Access Browser license, you can manage admin user access and assign one of the following roles that are specific to Prisma Browser.

| Enterprise Roles | Permissions |
| --- | --- |
| Prisma Browser Access & Data Administrator | Read-write access: setting and managing access and data policies ; defining custom and private applications ; handling end user requests related to policies Read-only permission to inventory aspects: users ; devices ; extensions ; applications ; any visibility aspects within the Prisma Browser management section:-   dashboards; end-user events |
| Prisma Browser Customization Administrator | Read-write access to set and manage browser customization policies. Read-only permission to inventory aspects: users ; devices ; extensions ; applications ; any visibility aspects within the Prisma Browser management section:-   dashboards; end-user events |
| Prisma Browser Permission Request Administrator | Read write access to handle end user requests related to policies. Read-only permissions to visibility aspects within the Prisma Browser management section" dashboards; end-user events |
| Prisma Browser Security Administrator | Read-write access to set and manage browser security policies. Read-only permission to inventory aspects: users ; devices ; extensions ; applications ; any visibility aspects within the Prisma Browser management section:-   dashboards; end-user events |
| Prisma Browser Security & Device Posture Administrator | Read-write access to set and manage browser security policies ; manage device posture groups ; set sign-in rules Read-only permission to inventory aspects: users ; devices ; extensions ; applications ; any visibility aspects within the Prisma Browser management section:-   dashboards; end-user events |
| Prisma Browser View Only Analytics | Read-only permission to inventory aspects: users ; devices ; extensions ; applications ; any visibility aspects within the Prisma Browser management section:-   dashboards; end-user events |