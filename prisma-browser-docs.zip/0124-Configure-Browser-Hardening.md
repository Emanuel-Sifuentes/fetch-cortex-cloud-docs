---
title: "Configure Browser Hardening"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-browser-hardening"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Security Controls > Configure Browser Hardening"
updated: "Mar 12, 2026"
---

# Configure Browser Hardening
Configure browser security controls for Prisma Access Secure Enterprise Browser (Prisma Browser).

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Cast

Mobile Browser - **No support**

This feature controls the ability to screencast a tab or the desktop via the Prisma Access Browser.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Cast.
    
3.  Select **Allow** to permit casting or **Block** to deny casting.
    
4.  Click Set.
    
5.  Restart the browser to apply this feature.
    

## Developer Tools

Mobile Browser - **No support**

This feature actively controls users' ability to open Developer Tools or manually load browser extensions in "Developer Mode" via "load unpack". It can also assist with preventing users from running unauthorized JavaScript code in the Developer Tools console.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Developer Tools.
    
3.  Select **Allow** to permit the Developer options, or **Block** to deny their use.
    
4.  Click Set.
    
    Restart the browser to apply this feature.
    

## Native Messaging Hosts

Mobile Browser - **No support**

Native Messaging Hosts allows the software installed on the device to communicate with Prisma Browser and its installed extensions, and vice versa. Enterprise software that interacts with the browser typically requires you to select "Allow only hosts installed with admin permissions."

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Native Messaging Hosts.
    
3.  Select one of the following options:
    
    -   **Allow** – the browser will **be** able to communicate with Native Messaging Hosts.
        
    -   **Allow only hosts installed with admin permissions**
    -   **Block** – the browser’s use of Native Messaging Hosts will be restricted.
        
    
4.  Click Set.
    

## JavaScript Running from Omnibox

Mobile Browser - **No support**

This feature determines whether or not users will be able to run JavaScript code from the browser omnibox (Address Bar). Users may exploit this functionality to manipulate web pages using JavaScript.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select JavaScript Running from Onmibox.
    
3.  Select one of the following options:
    
    -   **Allow** – the Prisma Browser will allow JavaScript to run from omnibox..
        
    -   **Block** – the Prisma Access Browser will restrict JavaScript from running from omnibox.
        
    
4.  Click Set.
    

## Keylogging Protection

Mobile Browser - **No support**

Linux/IGEL Browser - **No support**

This policy allows you to determine if keylogging protection will be enabled. Keylogging tools can monitor and report a user's actions as they interact with the computer. As the name suggests, a keylogger records what the user types, and reports the information back to whoever installed the logger.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Keylogging Protection.
    
3.  Select one of the following options:
    
    -   **Allow** – Keyloggers will be prevented from listening to keystrokes typed on Prisma Browser.
        
    -   **Block** – Keylogging protection is turned off.
        
    
4.  Click Set.
    

## Browser self-protection

Mobile Browser - **Support for Windows only.**

The **Browser self-protection** control enhances the security of Prisma Browser in high-risk environments, particularly on unmanaged or contractor devices (BYOD). These devices often grant users administrative privileges, increasing exposure to insider threats and malware.

For additional background information, refer to [Prisma Browser Self-Protection for Windows](/content/techdocs/en_US/prisma-access-browser/administration/prisma-browser-self-protection-fpr-windows.html).

To mitigate these risks, Prisma Browser introduces an advanced **runtime protection mechanism** based on a Windows kernel-level driver. This ensures the browser process remains protected from tampering and unauthorized interference during operation.

You can remotely enable or disable this driver-based protection. This control is disabled by default, and applied only when Prisma Browser is installed with Administrative privileges on Windows, and the user is running the browser as Administrator.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Browser self-protection.
    
3.  Select one of the following options:
    
    -   **Enable** – Browser self-protection will be enabled and will run whenever the browser is called. In addition, you are able to define the browser's enforcement action when the self-protection module cannot be started. The options are:
        
        -   Do not enforce - Browser runs normally.
        -   Prompt and proceed anyway - Browser runs normally, but a warning is displayed.
        -   Block browser access - Browser shuts down and message is displayed
        
    -   **Disable** – Browser self-protection will be disabled, and will not function.
        
    
4.  Click Set.
    

## Popups

Mobile Browser - **Support for iOS only.**

With this feature, you can control the display of popups in the browser.

The popups can be allowed, allowed with exceptions, blocked, or blocked with exceptions.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Popups.
    
3.  Select one of the following options:
    
    -   **Allow** – Popups will be permitted in the browser. You can specifically exclude domains from being allowed. This will block popups from those domains only.
        
    -   **Block** – Popups will be blocked. You can specifically exclude domains from being blocked. This will allow popups from those domains only.
        
    
4.  Click Set.
    

## Notifications

Mobile Browser - **No support**

You can use this feature to control notifications being displayed within the browser. The notifications can be allowed, allowed with exceptions, blocked, or blocked with exceptions.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Notifications.
    
3.  Select one of the following options:
    
    -   **Allow** - Notifications will be permitted in the browser. You can specifically exclude specific domains. This will block notifications from these domains.
        
    -   **Block** - Notifications will be blocked. You can specifically exclude specific domains from the rule. This will allow popups from those domains only.
        
    
4.  Click Set.
    

## Authentication Factor

Mobile Browser - **No support**

The Authentication Factor is used to configure the authentication method used by the Prisma Access Browser to trigger authentication for step-up MFA authentication, browser lockscreen and unlocking the password manager. A single authentication factor is used for all actions.

The Authentication factor is triggered by one of the following actions (if configured):

-   Web access > Require MFA
-   Login controls . Login Form > MFA
-   Data controls > Data Leak Prevention > File Download > Prompt > Require MFA
-   Data controls > Data Leak Prevention > File Upload > Prompt > Require MFA
-   Browser Security > Browser Session > Browser Lock

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Authentication Factor.
    
3.  Select one of the following options:
    
    -   **PIN Code**
        
        -   Configure the PIN code length (between 4-6 digits) and the number of attempts that can be made before the account will be locked out.
        -   If the user is locked out, or they forget their PIN code, they need to re-authenticate with their identity provider to reset the PIN code.
            
            PIN codes are not synced between devices. Users need to create a separate PIN code on each device.
            
        
    -   **Passkey**
        
        -   Select the type of passkey that the users can create:
            -   Internal authenticator - Passkeys stored locally on the device such as Windows Hello or macOS keychain
            -   External authenticator - Passkeys stored externally, on other devices, such as the user’s mobile phone, security key (for example, a yubikey), or smartcard
                
                Passkeys are not synced between devices. Users need to create a separate Passkey on each device.
                
        
    -   **IdP Authentication**
        -   Prisma Browser authentication profile – Re-authenticates the user with the same IdP authentication profile they used to log in to Prisma Browser.
        -   Choose profile – Gives admins flexibility by allowing them to choose a dedicated authentication profile with different IdP authentication factors from the standard Prisma Browser login process (e.g. require Microsoft Authenticator).
            
            All Prisma Browser users must be provisioned in the identity provider and assigned to the application in the selected authentication profile. Otherwise, they will be unable to complete actions that require MFA.
            
    
    To configure a dedicated profile:
    
    -   Follow the instructions to create a new application in the identity provider that will be used to authenticate users (Entra ID, Okta, Other IdP)
        
        When creating an authentication type in CIE, select **Dynamic service provider metadata**
        
    -   Create a SAML authentication profile in CIE associated to the application you created in the identity provider.
    -   Choose the newly created profile in the Authentication Factor control.
    -   **Use isolated browser session (incognito)** - Starts each authentication attempt in a clean and isolated session, without cookies or cache. Admins can turn it off if they need to retain other cookies during IdP MFA. Turning this option off is required to enable _pass-through_ authentication via Microsoft SSO - as an isolated browser session doesn't support it. This feature is enabled by default.
    -   Force Re-authentication - Prevents silent re-authentication by requiring users to enter credentials each time.they have an active IdP session
        -   Asks the identity provider to forcibly re authenticate (ForceAuthn=true) the user even if they had a pre-existing session with the IdP.
    
    **Important:** When creating an authentication type in CIE, select “Dynamic service provider metadata”
    
4.  Click Set.
    

## Open Links in External Apps

Mobile Browser - **Mobile only**

While most of the time we want to keep the Prisma Browser as a secure bubble, that all work is done only in the browser. This is not possible for a few reasons. First of all, some applications can't be opened in a browser, such as Zoom, Teams, Slack, among others. Blocking these apps would result in a terrible user experience. Second, most mobile devices are BYOD. Third, Some URLs can only be opened in a native app.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Open Links in External Apps.
    
3.  Select one of the following options:
    
    -   **Always** – External apps will always open in native applications.
        
    -   **Only for specific apps** – Only selected links will open in external apps. The following apps can be selected:
        
        -   MS Teams
        -   MS Outlook
        -   Microsoft 365
        -   Slack
        -   Zoom
        -   Salesforce
        -   Gmail
        -   Google Workspace (Sheets, Docs, Slides)
        -   Google Drive.
        
    -   **Never** - External apps will never open in native applications.
        
    -   **Users decide when to open links in native apps** - End users will be able to decide when to open links in Prisma Browser and when to use a native app.
        
    
4.  Click **Save**.
    

## Advanced Browser Protection

Stops zero-day WebAssembly attacks in real time by monitoring in-browser memory behavior and terminating malicious execution before any impact occurs.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Advanced Browser Protection.
    
3.  Select one of the following options:
    
    -   **Enable** – Enable Advanced Browser Protection.
        
    -   **Disable** – Disable Advanced Browser Protection.
        
    
4.  Click **Set**.