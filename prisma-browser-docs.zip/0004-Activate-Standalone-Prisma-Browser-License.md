---
title: "Activate Standalone Prisma Browser  License"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/activate-standalone-prisma-access-browser-license"
depth: 2
breadcrumbs: "Home > Prisma Browser > Activate Standalone Prisma Browser  License"
updated: "Feb 2, 2026"
---

# Activate Standalone Prisma Browser  License
Learn how to activate your Cloud Managed standalone Prisma Access Secure Enterprise Browser (Prisma Browser) with Prisma Access bundle license through Common Services.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager | Activation link for your product ; Cloud Identity Engine (CIE) is included and spun up during activation ; Customer Support Portal account |

See the [prerequisites](https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites.html) before you begin this task.

After you receive a notification from Palo Alto Networks identifying the license you're activating, use the activation link to begin the activation process.

1.  Log in to the **Activate Subscription** window.
    
    -   If you have a Palo Alto Networks Customer Support account, then enter the email address you used when you registered for that account and select Next.
    -   If you do not have a Palo Alto Networks Customer Support account, then Create a New AccountPasswordNext.
    
    The service uses this email address for the user account assigned to the tenant that you use for this license. This tenant, and any others created by this email address, will have the Superuser role.
    
2.  Allocate the product to the Recipient of your choice.
    
    The name provided matches your Customer Support Portal account for convenience. You can use the name provided or change it.
    
3.  Choose the data ingestion Region where you want to deploy your product.
    
4.  Assign the Prisma Access Secure Enterprise Browser Licenses and Add-ons
    
    1.  Select Prisma Access Secure Enterprise Browser.
        
    2.  This is similar to [allocating PA Mobile User licenses](https://docs.paloaltonetworks.com/content/techdocs/en_US/common-services/subscription-and-tenant-management/cloud-managed-prisma-access-and-add-ons-license-activation/activate-a-license-for-cloud-managed-prisma-access-and-add-ons/allocate-licenses-cloud-managed-prisma-access). You will be able to partially allocate and activate Prisma Browser licenses across multiple Prisma Access tenants. For example:
        
        -   You can purchase 1,000 units of Standalone Prisma Browser
            
        -   You can allocate:
            
            -   200 to a PoC tenant (this is the minimum quantity required)
                
            -   600 to a production tenant
                
            -   Leave 200 units unactivated for later use
                
        
    
5.  Add [Strata Logging Service](https://docs.paloaltonetworks.com/strata-logging-service/administration/overview) (formerly known as Cortex Data Lake) for storing tenant data such as configuration, telemetry logs, system logs, and stats. You can select an existing instance or create a new instance.
    
6.  Select [Cloud Identity Engine](https://docs.paloaltonetworks.com/cloud-identity) or create a new CIE instance to identify and verify all users across your infrastructure.
    
7.  Agree to the terms and conditions, and Activate.
    
8.  Go to the Prisma Browser [Admin Guide](https://docs.paloaltonetworks.com/prisma-access-browser/administration/use-the-prisma-access-browser-dashboards) to manage your Prisma Browser.
    
9.  (Optional) Assign [roles](https://docs.paloaltonetworks.com/common-services/identity-and-access-access-management/manage-identity-and-access/about-roles-and-permissions) so your admins can manage the Prisma Browser.