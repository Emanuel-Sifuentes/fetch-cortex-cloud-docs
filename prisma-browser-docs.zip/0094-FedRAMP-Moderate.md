---
title: "FedRAMP Moderate"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-fedramp-moderate"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Browser Prerequisites > FedRAMP Moderate"
updated: "Tue Feb 10 06:48:12 PST 2026"
---

# FedRAMP Moderate
The following domains are for clients in the FedRAMP Moderate domain.

The following domains are for clients in the FedRAMP Moderate domain only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   api.pubsec-cloud.wildfire.paloaltonetworks.com
-   pubsec-cloud.wildfire.paloaltonetworks.com
-   cie-api-proxy.gov.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.gov.talon-sec.com
-   assets.gov.talon-sec.com
-   users-assets.gov.talon-sec.com
-   releases.talon-sec.com

Refer to the FedRAMP documentation for a complete list of supported [FedRAMP Moderate and High FQDNs](https://docs.paloaltonetworks.com/fedramp/prisma-sase/fedramp-moderate-and-high-requirements/fedramp-moderate-and-high-fqdns).