---
title: "Privacy Datasheet"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/privacy-datasheet"
depth: 2
breadcrumbs: "Home > Prisma Browser > Privacy Datasheet"
updated: "Tue Feb 10 06:48:28 PST 2026"
---

# Privacy Datasheet
This topic provides a link to the Privacy Datasheet.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Browser | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

The purpose of the Prisma Browser Privacy Datasheet is to provide customers of Palo Alto Networks with information needed to assess the impact of this service on their overall privacy posture by detailing how Personal Data is captured, processed, and stored by and within the service.

For more information, and to see the whole document, please refer to the [Prisma Access Browser Privacy Datasheet](https://www.paloaltonetworks.com/apps/pan/public/downloadResource?pagePath=/content/pan/en_US/resources/datasheets/prisma-access-browser-privacy-datasheet).