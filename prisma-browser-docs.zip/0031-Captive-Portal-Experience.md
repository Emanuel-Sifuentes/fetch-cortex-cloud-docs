---
title: "Captive Portal Experience"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/captive-portal-experience"
depth: 2
breadcrumbs: "Home > Prisma Browser > Captive Portal Experience"
updated: "Feb 10, 2026"
---

# Captive Portal Experience
Prisma Browser Captive Portal Experience

| Where Can I Use This? | What Do I Need? |
| --- | --- |
|  |  |

Prisma Browser provides a captive portal experience that maintains security posture while giving users a reliable way to connect to networks that require sign-in. The browser aims to deliver a seamless captive portal experience and enforce enterprise-grade security controls. It replicates familiar browser behaviors where possible but introduces additional safeguards to prevent policy bypass in untrusted network states.

When a device connects to a new network (for example, public Wi-Fi), most browsers and operating systems try to detect captive portals by performing lightweight connectivity checks (e.g., http://connectivitycheck.gstatic.com/generate\_204).

If the request is redirected instead of returning a “no content” (HTTP 204) response, the browser infers that a captive portal is present. It then opens a Wi-Fi sign-in window automatically to direct the user to authenticate or accept terms. Once authenticated, the connection becomes unrestricted and normal browsing resumes.

In some cases, the automatic captive portal detection flow is not sufficient.

Common recovery actions include:

-   Manually visiting known captive portal domains (for example, wifi.airline.com).
-   Navigating to a popular website (for example, example.com) to trigger a redirection from the default gateway.

## The Secure Wi-Fi Sign-in Window

To accommodate restricted network states, Prisma Browser provides a dedicated Wi-Fi Sign-In Window. This window allows users to safely reach captive portal pages in situations where existing security policies or conditions prevent standard recovery patterns from working. Examples include:

-   A strict policy that only allows navigation to specific websites.
-   Stale or outdated policy states that temporarily block navigation in the main browser window.

**Manual Trigger**

If automatic detection and normal recovery paths fail, users can open the Wi-Fi Sign-In Window manually:

**Path**

Menu (…)More ToolsWi-Fi Sign-In Window

**Window features:**

-   The address bar is editable, allowing users to navigate directly to captive portal pages (for example, wifi.airline.com or a hotel login page).
-   All browsing occurs in a secure, sandboxed session to ensure that no user data is exposed and no security policies are bypassed.

****After authentication and restored connectivity:****

-   Prisma Browser detects that the internet connection is active.
-   The browser displays a notification informing the user that the Wi-Fi Sign-In Window is no longer needed.
-   The user is prompted to close the Wi-Fi Sign-In Window and return to the main browser window, which now operates under validated Prisma Access policies.