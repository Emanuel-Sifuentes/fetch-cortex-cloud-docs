---
title: "SGP Region"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-sgp"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Browser Prerequisites > SGP Region"
updated: "Tue Feb 10 06:48:12 PST 2026"
---

# SGP Region
The following domains are for clients in the SGP region.

The following domains are for clients in the SGP region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   sg.api.wildfire.paloaltonetworks.com
-   sg.wildfire.paloaltonetworks.com
-   cie-api-proxy.sg.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.sgp.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.sgp.talon-sec.com
-   users-assets.sgp.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com