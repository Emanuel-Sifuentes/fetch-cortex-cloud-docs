---
title: "Configure Saved Data"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-saved-data"
depth: 4
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles > Configure Prisma Browser Browser Security Controls > Configure Saved Data"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Configure Saved Data
Saved Data Security Controls

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Password Manager

This control allows you to enable the Prisma Browser Enterprise Password Manager to manage and secure company passwords and logins.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Password Manager.
    
3.  Select one of the following options:
    
    -   **Enable** - Enable the Password Manager to manage users passwords and logins.
        
        -   **Require MFA to obtain or autofill logins** - Select this option to determine how often your users will need to re-enter their MFA for a new login. You can require that the MFA be entered every time the information from the Password manager is accessed, or they will need to enter their MFA for a new login every selected time period. The current range is between 1 and 30 minutes.
    -   **Disable** - Do not enable the Password Manager .
        
    

## Password Saving

Mobile Browser - **Full support**

This feature determines whether the browser will be able to save passwords for websites.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Password Saving.
    
3.  Select one of the following options:
    
    -   **Allow** - Users will be able to save passwords in the browser.
        
    -   **Block** - Users will be restricted to save passwords in the browser.
        
    
4.  Click Set.
    

## Autofill of Forms

Mobile Browser - **No support**

This feature determines whether or not the browser will store information to autofill forms.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyProfilesBrowser Security
    
2.  Select Autofill of Forms.
    
3.  Select one of the following options:
    
    -   **Allow** – The browser will save information to autofill forms in the future.
        
    -   **Block** – The browser will not save form information to be filled automatically in the future.
        
    
4.  Click Set.
    

## Autofill of Credit Cards

Mobile Browser - **No support**

This feature determines whether or not the browser will allow users to store credit card information.

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyControlsBrowser Security
    
2.  Select Autofill of Credit Cards.
    
3.  Select one of the following options:
    
    -   **Allow** – Prisma Browser will be able to save credit card details.
        
    -   **Block** – Prisma Browser will be restricted from saving credit card details for future use.
        
    
4.  Click Set.