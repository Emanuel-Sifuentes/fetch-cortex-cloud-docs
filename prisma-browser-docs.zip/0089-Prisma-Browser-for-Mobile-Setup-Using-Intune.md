---
title: "Prisma Browser for Mobile Setup Using Intune"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/prisma-access-mobile-browser/prisma-access-browser-setup-using-intune"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Browser for Mobile > Prisma Browser for Mobile Setup Using Intune"
updated: "Feb 10, 2026"
---

# Prisma Browser for Mobile Setup Using Intune
This is a guide on how to set Prisma Browser mobile as a default browser for applications that are managed by Intune MaM

This discusses how to set up Prisma Browser for Mobile using Intune.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
|  | Admin access to the Intune console - : [Intune Admin Center.](https://intune.microsoft.com/#view/Microsoft_Intune_DeviceSettings/AppsMenu/%7E/overview); Existing Intune users that are part of a group |

## Set Prisma Browser for Mobile as the Default Browser for Intune-Managed Applications

Intune enables you to set a default browser for organization-managed apps. You can apply this globally through App Protection policy rules, or selectively for specific, critical applications. This is relevant for mobile devices (iOS and Android), as they are often employee-owned. However, enforcing a company browser as the default for all apps might raise employee concerns.

Enforcing the Prisma Browser for Mobile for your Intune-managed apps significantly enhances your organization's Data Security. You can safeguard against phishing and identity theft by limiting how URLs are opened. You will be minimizing the risk of exposure to malicious links by enforcing the use of the Prisma Browser for Mobile.

Furthermore, Intune’s clipboard control adds another layer of protection. It prevents users from copying and pasting links into unmanaged apps. This ensures that organizational data is always accessible through trusted and controlled applications.

In essence, designating the Prisma Browser for Mobile for Intune apps mitigates the risks associated with phishing and other identity-based attacks, along with data leak exposure.

## Android Setup

### Before you start:

Before you begin, you need the following prerequisites:

-   Admin access to the Intune Console (in this document - the access belongs to admin@pabsandbox.com.
-   Access to the [Intune Admin Center.](https://intune.microsoft.com/#view/Microsoft_Intune_DeviceSettings/AppsMenu/%7E/overview)

### Setup in the Admin Center

The first step is to set the Android Enrolment profile (If it wasn’t done previously):

1.  In the Admin Center, click **Devices > Android > Android Enrolment**.
    -   Set Managed Google Play.
    -   For the Admin user, in the examples, we are using the name John.Smith@pab-lab.com.
2.  Click **Apps → Android**, and then add the application that you would like the users to have:
    -   Prisma Browser - Managed Google Play Store app.
    -   Outlook - Managed Google Play Store app.
    -   In the Properties section, assign the Mobile Test group so that the apps will be included for the user.
3.  Create the default Browser policy:
    -   Select **Apps →App Protection Policies → Create Policy → Android**
    -   Target policy.
    -   In the Data Protection tab, define the browser.
        
        The Unmanaged Browser ID should be com.talonsec.talon
        
        The Unmanaged Browser Name should be **prisma**.
        
    -   Assign this policy to your group.

### Android Device Setup

1.  Using Google Play, download the application **Company Portal** and login using the user credentials.
2.  In the Company Portal, select the **Device** tab, click on your device, and complete the work profile (You may need to do this several times). Your device will now have a new tab entitled **Work**.
    
3.  The **Work** tab will include all applications that were added in the console.
4.  To test the feature, click the Outlook link. The app should open using the Prisma Browser.

## Android Troubleshooting

1.  If the application you added in the Admin center doesn't exist in the Play Store or isn't installed on the device, try syncing from the company portal settings.
2.  If Outlook is not able to log in, try deleting the application and reinstalling it.
3.  If the Prisma Browser does not open when you click the link and suggests opening another browser, reinstall the Prisma Browser Module.

## iOS Setup

### Before you start:

Before you begin, you need the following prerequisites:

-   Admin access to the Intune Console (in this document - the access belongs to admin@pabsandbox.com.
-   Access to the [Intune Admin Center:](https://intune.microsoft.com/#view/Microsoft_Intune_DeviceSettings/AppsMenu/%7E/overview)

## Setup in the Admin Center

**Create the default Browser Policy:**

1.  In the Admin Center, click **Apps > App Protection Policies > Create Policy > iOS**.
2.  In the Data Protection tab set the Unmanaged browser protocol to **prisma**.
    
3.  Assign the policy to your groups.

### iOS Troubleshooting

-   If the application that you added in the Admin Center does not exist in the Apple Store or isn't installed on the device, try syncing from the company portal settings.
-   If the Prisma Browser does not open when you click the link, and another browser is suggested, reinstall the Prisma Browser for Mobile.
-   There is a Troubleshooting page for Prisma Browser for Mobile. You can find it at the following location - Click the three dots → Settings → Scroll down to Troubleshoot → click Prisma Access Integration.

There are two common SSL-related issues on iOS devices:

-   **Outdated Certificates**: iOS enforces certificate validity limits. Certificates valid for more than one year may cause SSL errors. These issues typically affect internal websites, not public ones. Apple Certificate Requirements.
-   **Traffic Routing with Decryption**: Routing all traffic through the enforcement point (EP) while SSL decryption is enabled is **not** supported.
    
    Since the Prisma Browser provides network and CDSS, SSL issues (usually related to decryption) are rare.