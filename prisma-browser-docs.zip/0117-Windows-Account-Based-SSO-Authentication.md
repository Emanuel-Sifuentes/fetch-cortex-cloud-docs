---
title: "Windows Account Based SSO Authentication"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/third-party-integrations/windows-account-based-sso-authentication"
depth: 3
breadcrumbs: "Home > Prisma Browser > Third-Party Integrations > Windows Account Based SSO Authentication"
updated: "Feb 10, 2026"
---

# Windows Account Based SSO Authentication
This article discusses using the new Account based sso Authentication

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Browser | Prisma Access with Prisma Access Browser bundle license or Prisma Access Browser standalone license; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html); Microsoft 365 |

This feature is available for Microsoft Windows and macOS devices.

Because this feature uses local logged in users for authentication against web applications, we advise that you use this feature on managed devices only, to avoid unexpected logins from unmanaged domains.

This update supports local account-based authentication via Microsoft Single Sign-On (SSO) and Active Directory (AD) integration, addressing key needs:

-   **Passwordless Authentication** - Enables secure access for users without traditional passwords, improving accessibility and reducing friction.
-   **Stronger Admin Controls** - Allows IT admins to enforce authentication through corporate-managed SSO accounts, minimizing unauthorized access and reducing reliance on passwords.

Taking advantage of this new capability, Prisma Access Browser now has a method for incorporating the Microsoft solution into our commitment to secure solutions that align with modern enterprise needs, especially as hybrid and remote work models grow.

## Login to Browsers with Local Windows Accounts

You can enable browser logins using local Windows accounts linked to Active Directory.

**How It Works:**

You need to set a local registry key on managed devices to configure this feature. The key is

```
reg add "HKLM\\Software\\Policies\\Palo Alto Networks\\PrismaAccessBrowser" /v
          ForceEnableMsSSO /t REG\_DWORD /d 1 /f  
```

Using this, your users only need to enter their username (e.g., richarddorlinger@example.com). When they log in, their credentials are authenticated against the local machine. This ensures that the enter username matches the locally logged-in user.

## Automatic Web Application Sign-In Using Microsoft Entra ID

You can leverage Prisma Access Browser’s capabilities to enable seamless authentication during Microsoft SSO flows for web applications.

**How It Works:**

Enable the Microsoft SSO control when you create a Browser Customization rule. From Strata Cloud Manager, select **Configuration**\>**Prisma Access Browser**\> **Policy**\>**Profiles**\>**Browser Customization**, and select **Microsoft Auto-SSO**.

Once this is done, your users will be able to navigate to web applications and experience automatic sign-in using Microsoft SSO, authenticated via corporate Active Directory connections.

## Support for Microsoft Entra on macOS Devices

Prisma Browser now supports Microsoft Enterprise SSO plug-in for Apple devices. This allows users to seamlessly authenticate to Microsoft Entra web apps.

**What you need to do:**

1.  Deploy and configure the Enterprise Single Sign On plug-in for Apple configured on macOs devices. The information can be found on the [Microsoft Entra site](https://learn.microsoft.com/en-us/entra/identity-platform/apple-sso-plugin).
2.  Make sure that the device is enrolled and has the Intune Company Portal, version **5.2504.0** or higher.
3.  Make sure that the minimum Prisma Browser version is **136**.