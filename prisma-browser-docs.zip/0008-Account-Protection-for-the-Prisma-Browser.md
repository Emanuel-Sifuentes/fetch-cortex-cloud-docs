---
title: "Account Protection for the Prisma Browser"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/account-protection-for-the-prisma-access-browser"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Account Protection for the Prisma Browser"
updated: "Mar 12, 2026"
---

# Account Protection for the Prisma Browser
This article describes how to perform the Account Protection deployment.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Many applications can’t integrate with a company’s Single Sign-On (SSO) solution via an Identity Provider (IdP), such as Okta or Azure Active Directory (AAD), despite handling sensitive data or enabling critical operations that impact the organization. Examples of such applications include:

-   **Virtual Data Rooms (VDRs):** Platforms for collaborating on contracts and documents between financial institutions.
-   **Company Social Media Accounts:** Company social network accounts managed by marketing teams.
-   **Third-Party or Partner-Managed Applications:** Services like secure file shares operated by external partners or vendors.

Organizations encounter significant challenges in achieving visibility and securing these unmanaged services, leading to vulnerabilities caused by:

-   **Lack of Security Oversight:** Applications not managed through an IdP often lack IT governance, creating uncertainties for security teams.
-   **Weak Access Controls:** These services typically don’t support SSO integration or centralized authorization systems. Credential sharing is common, and multi-factor authentication (MFA) is frequently absent.
-   **Limited Security Measures:** Without auditing and enforcement capabilities, these systems lack transparency and control over user access.
-   **Inadequate Data Protection:** Security teams are unable to enforce stringent identity and data protection policies.

In many cases, users independently create, manage, and modify credentials for such applications, or rely on third-party IT teams to handle security — introducing significant risks.

**Account Protection** provides a solution by enabling security teams to regain control over unmanaged, third-party, and non-SSO-enabled services. It achieves this by ensuring all access occurs through a Privileged Access Broker (PAB), delivering:

-   **Gain full visibility** into user actions within these systems.
-   **Record sessions and events** for compliance and audit.
-   **Apply advanced data loss prevention (DLP) controls** to protect sensitive data.
-   **Implement modern step-up MFA** for applications that don’t support SSO.

By deploying **Account Protection**, organizations eliminate security gaps, enhance oversight, and protect critical assets across all applications — whether managed within the company’s SSO framework or not.

## How Does It Work>

How does account protection work

**Account Protection** introduces an additional security layer for unmanaged services by enhancing password management through the **Protected Access Broker**. The process is as follows:

1.  **Password creation / reset via Protected Access Broker:**
    -   Users must create or reset their passwords exclusively through the Protected Access Broker.
    -   Without resetting the password via PAB, users can’t log in to the application through the enterprise browser.
2.  **Secure password generation:**
    -   Prisma Browser employs a proprietary algorithm to generate a secure password by combining:
        -   **User-Selected Password:** A password chosen by the user, which is never stored in PAB.
        -   **Secret Token:** A unique, system-generated token created by Prisma Browser, which is not disclosed to the user.
3.  **Password Swapping:**
    -   PAB replaces the user-selected password with the combined secure password.
    -   The combined password is then set as the new application password during the password reset process.

**Key Benefits**

-   Users retain knowledge only of their selected password, while the **Prisma Browser** securely stores and appends the secret token during authentication.
-   On subsequent logins, Prisma Browser appends its secure token to the user password, ensuring authentication success.
-   **Access Restriction:** Logins from non-enterprise browsers are blocked because the secure token is absent, ensuring that access is limited to the enterprise browser environment.§

**Administrative Control**

You can enforce Prisma Browser policy rules, including visibility and security measures, for unmanaged, third-party, and non-SSO-enabled services.

1.  **Supported Login Methods:** Only password-based authentication methods are supported.
2.  **Password Reset Requirement:** The application must support resetting user passwords before login (e.g., via a "Forgot Password" feature).
3.  **Shared Account Handling:** For shared accounts, the same secure token is applied for all users. This configuration must be explicitly selected when enabling Account Protection for such applications.

This process ensures stronger security for unmanaged services while maintaining usability and control.

### Configure the Account Protection

Account Protection uses an Access & Data Control rule for configuration. You can set up Account Protection in the **Login Controls** step.

To configure Account Protection:

1.  **Create an Access & Data Control rule**. For more information, refer to [Manage Prisma Access Browser Access & Data Control Rules](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules?otp=task-pqd_js3_hcc#task-pqd_js3_hcc).
    
2.  **Configure the Login Controls**.
    
    -   Navigate to the **Login Control** step and do the following:
        1.  **Click "Login Form"** to define login behavior.
            
        2.  Select the desired **Login Control behavior** from the available options.
        3.  Enable Account Protection:
            1.  Click **Account Protection** to enforce access restrictions and secure application passwords.
            2.  Check **Activate Account Protection** to enable the feature.
                
            3.  If shared accounts need to be supported, check **Enable Account Protection for shared accounts** to allow Prisma Browser to use the same secret token for all users of the application.
                .
    
3.  **Finalize configuration:**
    
    -   Once configured, users will only be able to access the protected application via the **Prisma Browser**.
    -   Users will need to reset their password for the application, which will then be secured by Account Protection.
        
    -   For shared accounts, the same secret token will be applied to all users, enabling account sharing securely.
    

## End-User Experience

1.  **First-Time Login:**
    
    -   When Account Protection is enabled, users attempting to log in to a protected application for the first time will receive a prompt to reset their password or create an account.
    -   The account will automatically be added to Account Protection upon password reset or account creation.
    
2.  **Access Restriction Before Password Reset:**
    
    -   Users can’t log in to the application until they reset their password via Prisma Browser.
    
3.  **Visual Indications:**
    
    -   A dedicated browser **omnibox indicator** will show that Account Protection is active.
    -   For some applications, additional indicators will appear during login attempts, offering guidance if login fails or when using a protected account.
    
    By configuring Account Protection, administrators ensure enhanced security for unmanaged services, allowing only secure access through the Prisma Access Browser.