---
title: "Integrate Prisma Browser with CrowdStrike Falcon Intelligence"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/third-party-integrations/integrate-prisma-access-browser-with-crowdstrike-falcon-intelligence"
depth: 3
breadcrumbs: "Home > Prisma Browser > Third-Party Integrations > Integrate Prisma Browser with CrowdStrike Falcon Intelligence"
updated: "Tue Feb 10 06:48:41 PST 2026"
---

# Integrate Prisma Browser with CrowdStrike Falcon Intelligence
Integrate Prisma Browser with CrowdStrike Falcon Intelligence to scan files and URLs for malicious actors.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Browser | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html); CrowdStrike Falcon Intelligence |

You can integrate the Prisma Browser with CrowdStrike Falcon Intelligence to enable you to scan files and URLs for malicious actors by using the Falcon Intelligence API.

After you integrate the Prisma Browser with CrowdStrike Falcon Intelligence, your Prisma Browser users will be able to use it as a file scanning engine. For more information, refer to [Malicious File Protection](https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls).

The Falcon Intelligence Quick Scan will scan only the following file types. It will ignore other file types.

-   doc, docx
    
-   pdf
    
-   xls, xlsx, xlsm
    
-   ppt, pptx, pptm
    
-   exe
    
-   dll
    
-   mach-0
    

Before you begin, ensure that you have access to the Falcon user interface with an Administrator role.

1.  To enable the CrowdStrike Falcon Intelligence integration in Strata Cloud Manager.
    
    1.  Go to ConfigurationPrisma BrowserAdministrationIntegrationsServices.
        
    2.  Scroll to CrowdStrike Falcon Intelligence Integration and expand it.
        
    3.  Click Enabled, then enter the following information (obtained from CrowdStrike):
        
        -   Client ID
        -   Client Secret
        -   Gateway API URL
        
    4.  Click Save.
        
    5.  If Falcon CrowdStrike Intelligence does not recognize a file, you can optionally submit the file to Falcon CrowdsStrike Intelligence Quick Scan and Sample Uploads. To enable this option, select If the file is unknown to Indicators (Falcon Intelligence), submit it to Falcon Intelligence QuickScan.