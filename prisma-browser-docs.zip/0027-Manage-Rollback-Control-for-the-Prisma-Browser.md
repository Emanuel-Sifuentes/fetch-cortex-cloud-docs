---
title: "Manage Rollback Control for the Prisma Browser"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/rollback-control-for-the-prisma-access-browser"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Rollback Control for the Prisma Browser"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Manage Rollback Control for the Prisma Browser
This is the Rollback Control

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## Rollback Control - Overview

The Rollback Control feature in the Administration Console allows you to revert browsers to a specific version using the existing upgrade control interface (rollback is currently supported only for Windows). This capability ensures a stable and controlled browser environment by enabling quick rollbacks in case of compatibility issues, performance regressions, or unexpected errors after an update.

## Managing Rollbacks

To manage rollbacks, you need to use the **Pinned Version** update option. When you select a compatible device, the feature will display a check box, **"Force rollback to this version."** Enabling this option will force newer browser versions to downgrade to the selected versions, after browser relaunch by the end users.

## Rollback Workflow

1.  Open an existing upgrade policy or create a new one with a higher rule.
2.  Navigate to the **Pinned Version** section.
3.  Select the target version for rollbacl (Only version 134.x and above support rollbacl).
4.  Enable the check box labeled **"Force Windows instances to rollback to selected version.**
5.  A warning message will appear:“_Using the browser rollback feature will restore browsers to the selected version. This might result in loss of data, customizations, or recent settings. Proceed at your own risk._”
6.  Apply the policy to execute the rollback.

## Rollback Behavior

-   Browsers with a **higher version** than the pinned version are rolled back to the selected version.
-   Browsers with an **older version** than the pinned version update to the pinned version.

By implementing rollback control, you gain the flexibility to quickly revert browser versions across managed devices, ensuring stability and minimizing disruptions caused by unintended updates.

## Known Limitations

When you select the rollback version for Windows, you also need to select a pinned version for Mac devices. This allows you to select a specific version for the Mac machines to remain on.

## Potential Data Loss Risks

Rolling back to an earlier version of the Prisma® Access Browser might lead to data loss due to changes in how newer versions store and manage data. You need to carefully consider the following risks before proceeding:

1.  **Loss of Browser Data:** Newer versions of the Prisma Browser could update the formats used to store:
    
    -   History
    -   Bookmarks
    -   Cookies
    -   Cached files
    
    Rolling back could render some of this data unreadable or incompatible, leading to loss.
    
2.  **Loss of Security Features**
    
    -   Newer versions typically include **security patches** and updates.
    -   Rolling back to an earlier version could expose systems to **vulnerabilities** that were patched in later versions.
    
3.  **Compatibility Issues:**
    
    -   Some **websites and applications** only support newer versions of browsers.
    -   Older browser versions can impact functionality and prevent access to some services.
    
4.  **Extension/Plugin Incompatibility**
    
    -   Updated extensions and plugins could only work with newer browser versions.
    -   Rolling back could result in some extensions becoming **nonfunctional**.
    

## Recommendations

Before enforcing a rollback, administrators should carefully evaluate whether the need to revert outweighs the risks associated with data loss and security vulnerabilities. We recommend testing the rollback in a controlled environment before applying it to all managed devices.

By understanding the Rollback Control feature effectively, you can maintain a stable and secure browsing environment while minimizing disruptions for users.