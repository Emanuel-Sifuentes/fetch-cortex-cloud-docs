---
title: "Deploy the Prisma Access Browser Extension"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/deploy-prisma-access-browser-extension"
depth: 2
breadcrumbs: "Home > Prisma Browser > Deploy the Prisma Access Browser Extension"
updated: "Feb 10, 2026"
---

# Deploy the Prisma Access Browser Extension
Learn about deployment methods for the Prisma Access Secure Enterprise Browser (Prisma Access Browser) based on your organization’s policies and preferences.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Access Browser standalone | Prisma Access with Prisma Access Browser bundle license or Prisma Access Browser standalone license; Superuser or Prisma Access Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

The Prisma Access Browser Extension is a tool that you can install on Google Chrome and Microsoft Edge browsers, running on Windows, macOS, and ChromeOS Operating Systems.

The extension deployment is based on the operating system and the browser type.

For information on deploying the Prisma Access Browser Extension, contact your SE.