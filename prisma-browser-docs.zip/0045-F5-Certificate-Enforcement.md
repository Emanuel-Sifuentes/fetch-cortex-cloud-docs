---
title: "F5 Certificate Enforcement"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/f5-certificate-enforcement"
depth: 2
breadcrumbs: "Home > Prisma Browser > F5 Certificate Enforcement"
updated: "Feb 10, 2026"
---

# F5 Certificate Enforcement
Ensures that your F5 Certificate-based applications can only be accessed via the Prisma Access Browser

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Access Browser | Prisma® Access with Prisma® Access Browser bundle license or Prisma Access Browser standalone license; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## How Does F5 Certificate Enforcement Work?

This feature ensures that access to applications integrated with F5 Certificates is only possible using the Prisma® Access Browser.

Prisma Access comes with a dedicated public key infrastructure (PKI) used for enforcement. Once enabled, each browser is provisioned with a dedicated, unique client certificate issued by the PKI (each tenant has a unique root CA used to sign the client certificates). Certificate enforcement ensures that login to the identity provider is only allowed when the client certificate signed by the dedicated root CA is provided.

The Prisma Access Browser solution uses an mTLS solution that generates a unique certificate for each user and browser. This certificate, signed by the Prisma Access Browser certificate authority, is stored directly in the user's browser.

When a user connects to the F5 gateway from an external location, the F5 initiates mTLS authentication by requesting the user's certificate and verifying it against the Prisma Access Browser certificate authority.

## Obtain the Prisma Access Browser Root Certificate

1.  Obtain the Prisma Access Browser Root Certificate.
    
    1.  Go to the Prisma Access Management Console and select **Administration > Integrations**.
    2.  Select and enable **Google Workspace Integration**.
    3.  In the first section, click Prisma Access Certificate to download the unique tenant root certificate.
    4.  Save the certificate to the Base-64 encoded (X.509) - .cer format.
    
    -   Windows - Select **Open the certificate > details > copy to file** and save it in the new format.
    -   macOS / Linux - Use OpenSSL.
    

## Create the Virtual Server

The virtual server for VPN access on an F5 system is a configuration component designed to provide secure remote access to internal network resources for users outside the corporate network. Note the following important points:

-   The destination IP address is the public IP address that your users can access via the internet. This address allows your users to establish secure remote access to the network.
-   The source IP addresses are the allowed IP ranges that can access the virtual server.
-   Port 443 is the Listening TCP port on the virtual server.

### Attach an Access Policy to the Virtual Server

You need to create an Access policy and attach it to the virtual server. Users will then be able to establish a secure VPN remote access. The policy will perform the following:

-   User authentication and authorization.
-   Perform checks on the connecting device to ensure it meets security requirements.
-   Establish encrypted VPN tunnels.
-   Control access to internal resources by applying ACLs.

## Enable Mutual Authentication

**Attach a client SSL profile to allow mutual authentication.**

### Enable Server Authentication

The client SSL profile enables the virtual server to present its certificate, allowing external users to establish a secure connection. This enables external users to do the following:

-   Verify the virtual server certificate against the public certificate authorities.
-   Initiate an SSL/TLS handshake.
-   Establish a secure and encrypted connection to the virtual server.

.

### Enable Client Authentication

You can set up a Client SSL profile to request and verify client certificates during the SSL/TLS handshake. This mutual authentication process ensures that both the client and server are authenticated through digital certificates.

An example use case - the Prisma Access Browser client certificate is required during the SSL handshake process. The client certificate must make sure that:

-   The certificate's dates are valid.
-   The certificate has not been revoked.
-   The certificate has been signed by the Prisma Access Browser authority.

When the conditions listed above are successfully verified, the F5 gateway considers the user to be successfully authenticated and using the Prisma Access Browser..