---
title: "The Prisma Browser Extension"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/the-prisma-access-browser-extension"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > The Prisma Browser Extension"
updated: "Mar 12, 2026"
---

# The Prisma Browser Extension
The Prisma Browser Extension is a tool that allows organizations to apply some of the Prisma Access Secure Enterprise Browser functionality without installing the full browser.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

The Prisma Browser Extension is a tool that you can install on consumer browsers such as Google Chrome and Microsoft Edge browsers, running on Windows, macOS, and ChromeOS Operating Systems

IT and security teams can enhance organizational security by implementing Prisma Browser with a hybrid strategy, using the Prisma Browser Extension to bridge current browsing practices with advanced protections. This approach enables employees to continue using familiar browsers while administrators gain greater visibility and control over all browsers across the enterprise.

The extension actively monitors user activity on commercial browsers, helping to mitigate Shadow IT risks and providing real-time phishing protection. By centralizing visibility and allowing consistent enforcement of security policies, the Prisma Browser Extension integrates smoothly with existing tools while guiding users to the enterprise browser when accessing sensitive applications.

Designed as a foundational layer in a phased deployment, the Prisma Browser Extension supports a secure transition toward full adoption of the Prisma Browser. For scenarios requiring heightened protection, such as critical applications or high-risk users, a full enterprise browser deployment offers unparalleled control and functionality, setting a gold standard for security. This hybrid solution thus delivers immediate security benefits while preparing organizations for comprehensive, enterprise-grade browser security.

## Deploy the Prisma Browser Extension

The Prisma Browser Extension can be installed on chromium-based browsers (Chrome, Edge, Arc, Brave), running on Windows, macOS, and ChromeOS Operating System.

The extension deployment is based on the operating system, the IdP, and the browser type. Currently, Okta, Azure, and Google are the supported IdP applications.

For more information regarding Prisma Browser Extension Deployment, see [Deploy the Prisma Access Browser Extension](https://docs.paloaltonetworks.com/prisma-access-browser/deployment/deploy-the-prisma-access-browser-extension).

## Prisma Browser Extension Login Enforcement

Currently, the Prisma Browser Extension utilizes an automatic login feature that detects the user names from the most recent login to a web Identity Provider (IdP) application before applying Prisma Browser Extension policies. In some cases, the user name may not be recognized, preventing the Browser Extension from logging in and enforcing the admin policy. This occurs mainly in cases where the user has not yet logged into any IdP applications on their browser.

To avoid situations like this, the Prisma Browser Extension includes a feature that you can configure that requires logging into the Prisma Browser Extension before accessing specified sites. This prevents users from bypassing the administrative policies by using applications without the proper login.

To configure the Login Enforcement Policy, follow the procedures for creating a new [Data Control](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules.html#manage-prisma-access-browser-access-and-data-control-rules_task-create-access-rule) rule. Take note of the following requirements:

1.  In the **Scope** section, select the user **_Anonymous PABX._**
    
    When you select the Anonymous PABX user, several sections in the Add rule wizard will be unavailable. Some of the options in the available sections will also be unavailable.
    
2.  In the **Destinations** section, configure the applications and URLs that users will be _allowed_ to access without being logged in to the IdP.
3.  In the **Web Access** section, select **Allow**.
    
    Now you will create the second part of the Login Enforcement:
    
4.  In the **Scope** section, select the user **_Anonymous PABX._**
5.  In the **Destinations** section, configure the applications and URLs that users will be _not be allowed_ to access without being logged in to the IdP.
6.  In the **Web Access** section, select **Block**

Please **do not** block the IdP URLs in the Web application step. This will prevent users from logging into the Prisma Browser Extension.

## Prisma Browser Extension Posture Attributes

The Prisma Browser Extension allows you to configure the posture requirements for your devices running the Prisma Browser Extension in the same way that it configures posture for your desktop and laptop devices running the Prisma Browser.

For more information on the available Posture attributes, refer to [Configure Prisma Browser Extension Posture Attributes](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices/prisma-access-browser-extension-device-posture-attributes.html).

## Prisma Browser Extension Policy

### Access & Data Control Rules

Features of supported Access & Data Control policies are supported for devices running the Prisma Browser Extension. The following exceptions should be noted:

-   The **Set dialog text** feature, that permits you to customize your own text for a particular feature, is supported for the extension.
-   Note the following feature functionality in the Web Access section:
    -   Prompt options:
        -   Permission request - Acts as **Block.**
        -   Warn and allow to proceed anyway - **Supported.**
        -   Warn and allow to proceed anyway with reason - **Supported.**
    -   Require MFA - **Not supported.**
    -   Pick A Label - **Not supported (skipped)**.
    -   **Enforce Prisma Browser Extension traffic redirection to Prisma Browser** allows you to redirect users to the Prisma Browser when accessing web applications. The Allow/Prompt/Block settings will still be enforced, regardless.
-   Login restrictions - **Not supported (skipped)**.
-   When contains... - **Not supported (skipped)**.

## Data Controls - Data Leak Prevention

You need to be aware of the differences between the Prisma Browser and the Prisma Browser Extension policies.

## **File Download**

For more information, see [File Download](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/configure-data-leak-prevention.html#configure-data-leak-prevention_task-wcx_qv3_hcc).

File Download control provides multiple capabilities related to downloading files from websites that match a specified URL, application or website classification.

To set the File Download control:

-   **Allow** - the Prisma Browser Extension will allow all downloads.
    
-   **Allow (Protected)**) - Will be treated as **Block**.
    
-   **Block** - The Prisma Browser Extension will block all downloads.
    
-   Apply on:- Select between one of the following options:
    
    -   **Any file** - the download restrictions will apply to all files.
    -   **Specific files**\- the download restrictions will apply to files that meet the selected specifications (the rule can contain as many of these specifications as needed):
        -   **File size** - set the size of the file.
        -   **File types** - set the [file types](https://docs.console.talon-sec.com/en/articles/346) that need to match this rule.
        -   **File hash** - Not supported.
        -   **MIP label** - Not supported.
    -   **Prompt**\- when there is a restriction, select between one of the following options:
        -   **None** - there will be no prompts.
        -   **Before download** \- Not supported; treated as **Block**.
    -   **Require MFA** - Not supported.

## **File Upload**

For more information, see [File Upload.](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/configure-data-leak-prevention.html#configure-data-leak-prevention_task-bm2_fz3_hcc) .

File Download control provides multiple capabilities related to downloading files from websites that match a specified URL, application or website classification.

To set the File Download control:

-   **Allow** - the Prisma Browser Extension will allow all downloads.
    
-   ****Allow protected files only between the rule’s web applications****) - Treated as **Block**.
    
-   **Allow only non-protected files** - Treated as **Block**.
    
-   **Block** - The Prisma Browser Extension will block all downloads.
    
-   Apply on:- Select between one of the following options:
    
    -   **Any file** - the download restrictions will apply to all files.
    -   **Specific files**\- the download restrictions will apply to files that meet the selected specifications (the rule can contain as many of these specifications as needed):
        -   **File size** - set the size of the file.
        -   **File types** - set the [file types](https://docs.console.talon-sec.com/en/articles/346) that need to match this rule.
        -   **File hash** - Not supported.
        -   **MIP label** - Not supported.
    -   **Prompt**\- when there is a restriction, select between one of the following options:
        -   **None** - there will be no prompts.
        -   **Before Upload** \- Not supported; treated as **Block**.
    -   **Require MFA** - Not supported.

[Clipboard](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls/configure-data-leak-prevention.html#configure-data-leak-prevention_task-krf_31j_hcc) - Only works for visibility in the selected Scope

## Browser Security - Extensions

The following policies are supported:

[Allowed or Blocked Extensions](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-extensions.html#configure-extensions_task-ydr_5hl_hcc)

[Block Extensions by Permission](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security/configure-extensions.html#configure-extensions_task-tff_23l_hcc)

## Browser Customization - Branding

The following policies are supported:

[Theme Color](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-branding.html#configure-branding_task-qgz_hxk_hcc)

[Brand Color](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-branding.html#configure-branding_task-rtz_jcr_hcc)

[Company Logo](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-branding.html#configure-branding_task-edc_qcr_hcc)

[Company Name](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-branding.html#configure-branding_task-q3r_3dr_hcc)

[Custom Texts](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-branding.html#configure-branding_task-ijb_4dr_hcc)

[Browser Icon](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-branding.html#configure-branding_task-zvj_c2r_hcc)

## Browser Customization - Customization

The following policy is supported:

[Search Engine Content Filtering](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization/configure-customization.html#configure-customization_task-rl2_gfn_2dc)