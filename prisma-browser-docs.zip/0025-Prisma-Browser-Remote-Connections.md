---
title: "Prisma Browser Remote Connections"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/prisma-access-browser-remote-connections"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Prisma Browser Remote Connections"
updated: "Mar 12, 2026"
---

# Prisma Browser Remote Connections
How to use Remote connections and PRA

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Prisma Access (Managed by Panorama or Strata Cloud Manager); Prisma Access 5.2.1 ; Prisma Access Dataplane - minimum version 11.2.4 ; Privileged Remote Access (PRA) Add-On License ; Prisma Access License with a Mobile User Subscription; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Remote Connections in Prisma Browser enable secure, browser-based access to RDP, SSH, or VNC sessions for both unmanaged and managed devices. This document explains how to enable and configure Remote Connections, manage policies, and set up user access.

## Remote Connection Overview

Enterprises often host critical infrastructure—including desktops, servers, and databases—within private networks, restricting access to IT-managed devices via RDP or SSH. However, employees and contractors may require secure access from unmanaged or personal devices. Prisma Browser’s Remote Connections enable controlled RDP, SSH, or VNC access directly from the browser, enforcing security through Prisma Browser policies.

**Key Benefits**

-   Browser-based access to remote hosts via RDP, SSH, or VNC.
-   No need to distribute or expose host credentials (when needed).
-   Seamless integration with Prisma Access for secure data transfer and traffic inspection.
-   Granular policy controls (e.g., watermarks, clipboard, device posture checks).

## Main Use Cases

1.  **Credential-Protected Access:** Organizations require a secure method for granting contractors access to specific remote hosts without exposing host credentials. Administrators must configure remote connections—whether credential-based or credential-free—and assign them to designated user groups while enforcing appropriate data controls and monitoring measures.
2.  **BYOD for IT Teams:** IT personnel often need to connect to various hosts from their personal devices. To accommodate this while maintaining security, administrators establish policies that allow designated user groups to access necessary destinations while ensuring compliance with security controls.
3.  **Sensitive OT Machines:** In critical environments, such as operational technology (OT) systems, administrators must enforce restricted access for contractors while continuously monitoring their activities. By configuring secure remote connections, enabling real-time session monitoring via Live Sessions, and retaining the ability to take control when necessary, organizations can ensure both security and operational integrity.

## Configure Remote Connections

1.  Go to **Configuration** → **Prisma Browser** → **Remote Connections**.
2.  Click **Enable.**
    -   If you don’t have any Mobile Users (MU) already deployed, ensure you configure traffic flow properly in Prisma Access.
3.  Modify additional parameters as needed:
    -   **Maximum Concurrent Sessions**: Maximum number of remote connections a user can open simultaneously.
    -   **Session Inactivity Timeout (minutes)**: Automatically ends a session after the specified idle period.
4.  Click **Save.**

After you first enable the Remote connection, a new policy is added with a lower priority (above the baseline rule) that **blocks all users** from using remote connections. Add new policy rules to allow required user groups to access remote hosts.

## Update Prisma Access Security Rules

Follow the instructions in the UI and add the relevant rules in Prisma Access to allow traffic destined for your remote hosts.

If you are using Global Protect in full tunnel mode, please add both rules.

## Configure Applications for Privileged Remote Access

**Add Remote Connections**

Remote Connections let your users access Windows desktops (RDP), servers (SSH), or other machines (VNC). You can optionally provide credentials so users don’t need to know them.

1.  Go to **Configuration** → **Prisma Browser** → **Applications** → **Remote Connections**.
    
2.  Click **Add Remote Connection**.
    
3.  Enter basic information:
    
    -   **Name** and (optional) **Description**
    -   **Destination FQDN/IP** (must be reachable via your Service Connection/ZTNA)
    -   **Protocol (RDP, SSH, or VNC)**
    -   **Port** (if different from default)
4.  (Optional) Configure authentication:
    -   **RDP**: Provide _User Name_ and _Password_, or leave both empty.
    -   **SSH**: Provide _User Name_ and _Password_ or use a _Private Key_ (and _Passphrase_ if encrypted). Optionally, provide a list of _Host Key_ entries for server fingerprint verification.
        
    -   **VNC**: Optionally provide _User Name_ and _Password_.
5.  (Optional) **Enable File Transfer** (for VNC) to allow SFTP-based file upload and download.
    
    -   Provide SFTP user credentials, SFTP port, or SFTP key details as appropriate.
6.  Click **Save**.
    

You can group multiple remote connections and other Saas/Private applications into **Application Groups** to streamline policy enforcement and assignment to user groups.

## Policy Management

Configure remote connections policies just like you do for SaaS and private applications.

1.  Go to **Rules** → **Add a New Rule**.
    
2.  In **Destination**, select **Remote Connections**.
    
3.  Define which remote connections to **Allow** or **Block** for a given scope:
    
    -   **Admin-defined connections** (specific or any).
    -   **Manual connections** (allowing end users to create their own connections).
    -   Any combination of the above.

### How Does Policy Work for Remote Connections?

-   **URL Parsing vs. IP/Protocol**: PAB enforces RDP/SSH/VNC connections based on extracted IP, port, and protocol, _not_ the standard URL pattern used for SaaS apps.
-   **Rule Prioritization**: Higher priority rules take precedence.
-   **Example**
    -   Rule 1: _Allow_ Remote Connection A, **enable** watermark, **allow** clipboard.
    -   Rule 2: _Allow_ all manual connections but **block** clipboard.
    -   **Outcome**: Remote Connection A uses Rule 1’s settings (clipboard allowed, watermark on). Manual connections not covered by Rule 1 fall under Rule 2 (clipboard blocked).
        

#### Policy Limitations

-   **Unsupported Data Controls** for remote sessions:
    
    -   Data masking
    -   Typing Guard
    -   Read-only mode
    
-   **Clipboard Controls**: If policy blocks clipboard, users only see a blocking notice once at session start. No events are generated for each clipboard use attempt.
    

## 

Manual Connections

**Why use Manual Connections?**

You might need flexible access to many hosts, or you may not want to configure each server individually in Prisma Browser.

**How this works?**

-   You grant _Manual Connection_ permissions via policy.
-   Users can create, edit, and delete their own connections.
-   Users **cannot** share these connections; the link is user-specific.
-   If the policy later revokes _Manual Connection_, all user-defined apps become inaccessible.
    
    An admin sets a policy allowing certain user groups to create their own RDP/SSH/VNC connections without pre-registering them in the console.
    
    **What if I need to restrict the access to a specific protocol or an IP range?**
    
    You can create a rule in the PA Security Policy to allow the specific user group only a specific protocol (defined applications) or a defined IP range (in the Destination of the rule).
    

## Visibility

-   **Event Page Display:**
    -   The **URL column** displays IP:Port (Protocol) for remote sessions.
    -   _Admin-Defined Connections_: These appear with a clickable link to a defined application.
    -   _User-Defined Connections_: Displayed without a link to a defined application.
-   **Event Recording & Live Streaming**:
    -   Remote sessions support event recording and real-time monitoring via **Live Sessions**.

## Just-in-Time Control (User Requests)

-   **Requests Page**: The URL column shows IP:Port (Protocol) for the requested connection.
-   **Approved Request**: Grants access to the specific remote connection only.
-   **Manual Connection Behavior**: If you select “Approval Required” for manual connections, the user must request approval for each new app they create .

## Permissions

-   **Remote Connections Page**
    -   Requires “Application” permission. If you can create applications, you can also create remote connections.
        
-   **Remote Connections Settings Page**
    -   Same permissions as other settings.
        
-   **Policy, User Requests, and Visibility**
    -   No additional special permissions beyond existing mechanisms.
        

## End-Users

-   **Accessing Assigned Connections:** Users can access their assigned remote connections from the Home Page or the Remote Connections page within the browser. Additionally, they have the option to bookmark any assigned or manually created connections for quick access.
-   **Logging In:** If administrator-provided credentials are available, users are logged in automatically. Otherwise, they will be prompted to enter their credentials manually.
-   **Manual Connections:** If permitted, users can create, edit, and delete their own remote connections. These manually created connections remain private and cannot be shared with other users.

If your organization doesn’t use the standard Prisma Browser homepage, users can still access the portal from the extension’s menu.