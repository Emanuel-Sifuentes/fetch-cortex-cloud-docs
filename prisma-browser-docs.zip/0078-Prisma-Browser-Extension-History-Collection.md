---
title: "Prisma Browser Extension History Collection"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/the-prisma-access-browser-extension/prisma-access-browser-extension-history-collection"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > The Prisma Browser Extension > Prisma Browser Extension History Collection"
updated: "Mar 12, 2026"
---

# Prisma Browser Extension History Collection
Describes the PABX history collection

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Browser | Prisma Access with Prisma Access Browser Extension ; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

## History Collection Overview

Installing the extension is simple, and it operates transparently for end users. The tool allows efficient collection of valuable data without disrupting workflows. The extension retrieves and presents historical data, providing customers with immediate insights into security risks based on past application usage and download history. These insights encourage Prisma® Access Browser adoption and support broader deployment.

During the proof of concept (PoC), the immediate goal is to deliver instant security insights as soon as you install the Strata™ Cloud Manager tenant. This ensures that security gaps and the value of Prisma Browser are demonstrated in the initial customer conversation without delays.

## How Does the Extension History Collection Function?

The History Collection rule enables gathering URLs and downloaded files accessed by users on all devices within the defined scope. Key functionalities include:

-   Collecting history data only from logged-in PABX devices.
    
-   Retrieving historical data from the 30 days preceding PABX installation.
    
-   Updating history data in the dashboards and events section within minutes.
    

### History Collection Use Cases

The Prisma Browser History Collection allows you to see information on the different dashboards. This allows you to examine how certain key elements are operating.

-   **Access to Malicious Sites:** Use the overview dashboard to highlight incidents involving access to malicious websites.
-   **Access to Risky Categories:** Display visits to potentially risky website categories, such as AI, gambling, and gaming, in the Web Security dashboard under “Top 10 Most Visited Web Classifications.”
-   **Data Downloaded from Top Applications:** Use the Data Leakage Prevention dashboard to showcase the volume of data downloaded from the top five SaaS applications, ensuring there are no insider risks.
-   **Downloads from Unknown websites:** Highlight downloads from unfamiliar or rarely used websites within the organization in the Data Leakage Prevention dashboard under ‘Top 10 Most Active Apps on websites.’

#### Demonstrating the Extension’s Capabilities

To conduct a successful demo:

-   Install the extension for the first time within a designated profile.
    
-   The order of configuring the rule or installing the extension does not affect the functionality.
    

If the rule's scope includes more than 50 users, you will not be able to save it. You will receive a warning explaining the reason why.