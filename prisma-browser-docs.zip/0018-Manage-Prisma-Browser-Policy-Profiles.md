---
title: "Manage Prisma Browser Policy Profiles"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Policy Profiles"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Manage Prisma Browser Policy Profiles
Learn how to manage policy profiles or external controls for Prisma Access Secure Enterprise Browser (Prisma Browser).

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Profiles (or external controls) can be used when you want to save reusable (or legacy) profiles and attach them to the rules later. The controls for the Prisma Browser rules can also be configured within the body of the individual rule instead when you [manage inline policy rules](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules.html).

## Create a Policy Profile

1.  From Strata Cloud Manager, select ConfigurationPrisma Browser PolicyProfiles
    
2.  Select the Profile (Control) type you will be using and click the + next to the group.
    
3.  Enter a name for the Profile and Create.
    
4.  Configure the controls that will be included in the Profile.
    
    It is possible to select more than one control per profile:
    
    1.  [Configure Data Controls](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-data-controls.html)
    2.  [Configure Browser Security](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-security.html)
    3.  [Configure Browser Customization](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-profiles/configure-prisma-access-browser-browser-customization.html)
    
5.  After the Profile Controls are configured, Save X changes, located on the lower right of the browser. The button will "shake" to remind you to save the changes.
    

## Attach a Policy Profile to a Rule

After you create profiles, you can attach them to rules. When you create a new Profile Rule, you can select a preconfigured Policy Profile instead of using the Control step in the rule creation Wizard.

1.  Create the rule according to the regular procedure, such as [create an Access and Data Control Rule](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-access-and-data-control-rules.html#manage-prisma-access-browser-access-and-data-control-rules_task-create-access-rule).
    
2.  At the Controls step, select the Profile from the Saved profiles list.
    
3.  Save.
    
4.  To indicate that the Rule is using a Policy Profile, the name of the Profile will be displayed in a highlighted background.