---
title: "How Is Synched Data Stored?"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/how-is-synched-data-stored"
depth: 2
breadcrumbs: "Home > Prisma Browser > How Is Synched Data Stored?"
updated: "Tue Feb 10 06:48:41 PST 2026"
---

# How Is Synched Data Stored?
This is a legacy topic that needs to be included

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Browser | Prisma Access with Prisma Access Browser bundle license or Prisma Access Browser standalone license; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Syncing with Prisma Access Browser's sync service is automatic. Every user's identity is assigned a unique key that encrypts the data that is sent and stored.

Neither Palo Alto employees nor console administrators have access to these keys. Encryption keys are stored in a secret store that is only accessible with a token associated with the user account.

A record of each access to the encryption key is maintained.