---
title: "Integrate Prisma Access Browser with Google Workspace"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/integrations/integrate-prisma-access-browser-with-google-workspace"
depth: 2
breadcrumbs: "Home > Prisma Browser > Integrate Prisma Access Browser with Google Workspace"
updated: "Feb 10, 2026"
---

# Integrate Prisma Access Browser with Google Workspace
Learn how to integrate the Prisma Access Browser with Google Workspace.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Standalone Prisma Access Browser | Prisma Access with Prisma Access Browser bundle license or Prisma Access Browser standalone license; Role: [Prisma Access Browser Roles](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html); Google Workspace |

You can use Google Workspace with custom or third-party applications to enrich existing Google Workspace services or to use new features with Google Workspace. After you integrate Prisma Access Browser with Google Workspace, your users will be able to open only the applications that you’ve assigned to the Prisma Access Browser.

Before you begin, ensure that you complete the following tasks:

-   Deploy the Context-Aware Access feature in Google Workspace, which is available for Enterprise and Education accounts or with Cloud Identity Premium.
-   Set up SSO authentication to Prisma Access Browser with Google.

1.  Enable the Google Workspace integration in Strata Cloud Manager and obtain the Prisma Access Browser certificate:
    
    1.  Go to ManageConfigurationPrisma Access BrowserAdministrationIntegrationsServices.
        
    2.  Scroll to Google Workspace Integration and expand it.
        
    3.  Click Enabled.
        
    4.  In part 1, select Prisma Access Browser Certificate. The certificate will download.
        
    
2.  Add the certificate for Prisma Access Browser in the Google Admin console.
    
    1.  Go to [Google Admin consoleDevicesNetworks](https://admin.google.com/ac/networks).
        
    2.  Click Certificates, then ADD CERTIFICATE, and upload the Prisma Access Browser certificate that you downloaded.
        
    3.  Select Endpoint Verification and click ADD.
        
    
3.  Create a new access level in the Google Admin console.
    
    1.  Go to [Google Admin ConsoleSecurityAccess and data controlContext-Aware Access](https://admin.google.com/ac/security/context-aware).
        
    2.  If Context-Aware Access is disabled, enable it.
        
    3.  Click Access levels, then CREATE NEW ACCESS LEVEL.
        
    4.  Name the new access level Prisma Access Browser or any other name of your choice.
        
    5.  Select ADVANCED and paste the following text:
        
        device.certificates.exists(cert, cert.is\_valid && cert.root\_ca\_fingerprint == "kiLbsQhDpeCsDkM6ox2oHiaxOiQQ45u8FV1AmeQxc9E")
        
    
4.  Assign the new access level to your apps.
    
    1.  Go to [Google Admin ConsoleSecurityAccess and data controlContext-Aware Access](https://admin.google.com/ac/security/context-aware).
        
    2.  Click Assign access levels.
        
    3.  Select one or more apps in the list and click Assign.
        
    4.  Select the newly Prisma Access Browser access level that you created in Step [3](#integrate-prisma-access-browser-with-google-workspace_create-access-level).
        
    
5.  Validate the integration on an endpoint.
    
    1.  Install the Prisma Access Browser on an endpoint.
        
    2.  Wait for the new Google Workspace configuration to complete, usually 5 minutes.
        
    3.  From the Prisma Access Browser, sign in to an assigned app and test the following:
        
        -   Make sure that you can successfully sign in to an application that uses the Google Workspace SSO.
        -   Make sure that you can't sign in to the application from a different browser.
        
        After you complete the validation, and your users will be able to open only the applications that you’ve assigned to the new access level using the Prisma Access Browser.