---
title: "Device Health"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/device-health"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Device Health"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Device Health
Device Health displays the issues with the device and its dependencies.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

The **Device Health view** provides you with immediate visibility into the operational state of individual devices across the organization. This centralized interface consolidates critical diagnostics and posture data, enabling faster investigation and resolution of device-related issues. By streamlining access to key metrics and device status, the view helps reduce downtime and improve overall system reliability and understanding.

## Access the Device Health View

To view the health status of a specific device, follow these steps:

1.  Open the Devices screen.
    
2.  **Search** for the specific device you want to inspect. You can use the filters to help in the search. For more information, see [Manage Prisma Access Browser Devices](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html).
3.  Click the **Device record** to open the **Device Drawer view**.
    
4.  In the top-right corner of the drawer, click the three-dot menu (**⋮**), then select **Device health**.
    
5.  The **Device Health view** will open, displaying detailed information about the selected device.
    

## Dashboard Sections

## Device Details

This section displays basic identification information for the device.

The Device Health dashboard contains the following information in the Device Details section.

-   **Device details** - Displays the basic identification information for the device.
    -   **Hostname** - The name of the device.
    -   **User** - The name of the user registered on the device.
    -   **Status** - the current status of the device (offline, online).
-   **Metadata** - Displays the different identifying information for the device.
-   **Posture details** - This section provides insights into the device’s security posture and configuration. Some entries include an **(ℹ)** icon, indicating that additional information is available when you hover or click.
-   **Diagnostics** - Displays the current status of all monitored services. This section helps identify operational issues quickly.

The following products do not support the Device Health dashboard:

-   Prisma Browser for Mobile
-   Prisma Browser Extension (PABX)

You need to consider these limitations when planning diagnostics.

## Refresh the Display

Use the **Refresh** button located in the top-right corner of the screen to reload the most recently received telemetry data. This feature is especially useful when new metrics are available and you want to ensure the display reflects the latest information.

The **Refresh** button does not request live data from the device or endpoint. Instead, it reloads data that the device already sent based on its preconfigured reporting cycle. If the device has not sent new data, the information on the screen will stay the same.