---
title: "IN Region"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-in"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Browser Prerequisites > IN Region"
updated: "Tue Feb 10 06:48:12 PST 2026"
---

# IN Region
The following domains are for clients in the IN region.

The following domains are for clients in the IN region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   in.api.wildfire.paloaltonetworks.com
-   in.wildfire.paloaltonetworks.com
-   cie-api-proxy.in.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.in.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.in.talon-sec.com
-   users-assets.in.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com