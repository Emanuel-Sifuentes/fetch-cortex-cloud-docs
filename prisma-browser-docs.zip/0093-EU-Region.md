---
title: "EU Region"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-eu"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Browser Prerequisites > EU Region"
updated: "Feb 10, 2026"
---

# EU Region
The following domains are for clients in the EU region.

The following domains are for clients in the EU region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   de.api.wildfire.paloaltonetworks.com
-   de.wildfire.paloaltonetworks.com
-   cie-api-proxy.eu.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.eu.talon-sec.com
-   login.eu.talon-sec.com
-   ext-proxy.eu.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.talon-sec.com
-   auth.eu.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com