---
title: "Manage Prisma Browser Sign-in Rules"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/manage-prisma-access-browser-sign-in-rules"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Manage Prisma Browser Sign-in Rules"
updated: "Thu Mar 12 09:48:16 PDT 2026"
---

# Manage Prisma Browser Sign-in Rules
Learn how to create browser sign-in rules as a first level of securing your Prisma Browser deployment.

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

Use sign-in rules to determine which users and devices have access to Prisma Browser. The Sign-in rules page displays information about existing sign-in rules:

To view the rules:

The last rule on the list is the **Default rule**.

The Default rule is the policy rule that is used when no other policy rule is applicable. Since this rule must be available for any given user or device, only certain controls can be edited.

-   **Priority**—The priority order for rule enforcement.
-   **Mode**—Indicates whether the rule is active or disabled.
-   **Name**—Identifies and describes the rule.
-   **Users**—The users and user groups associated the each rule.
-   **Device groups**—The device group associated the each rule.
-   **Network & Location**—The specific networks and geolocations associated with the rule.
-   **Action**—The action Prisma Browser takes for users and devices matching the rule: Allow, Block, or Prompt the user.
-   **Updated**—Last updated date for the rule; hover to see the full timestamp.

When you create a sign-in rule, you define the scope of the rule. When a user attempts to access Prisma Browser, the browser compares the scope of the rules in order until it finds a rule match for the user or device or network or geolocation, and then it enforces the corresponding access rule. In some cases, you may want the sign-in rules you define to block Prisma Browser if they match the scope of the rule. For example, suppose the scope of the rule is set to match a device group for devices with a specific OS and you don’t want to allow access to devices that are still running that OS. In that case, you would set the sign-in rule to block access for users who match to it. In other cases, you might want to allow users who match the sign-in rule access to Prisma Browser. For example, suppose the scope of the rule allows users in a specific user group and in a device group that only allows devices running a specific OS version, a specific client certificate, and has active endpoint protection. In this case, you might want the matching sign-in rule to allow access to Prisma Browser. The way you create your user groups and device groups (including the corresponding device posture rules you enforce at the device group level) informs how you will want to create your sign-in rules.

When a user attempts to access the browser, Prisma Browser evaluates the sign-in rules in top-down order until it finds a match for the user and device and then it enforces the corresponding sign-in rule. If the user or device don’t match any of the defined sign-in rules, Prisma Browser enforces the Default sign-in rule allow rule.

There are two ways to create sign-in rules: one for managed devices and one for unmanaged devices, as described in the following sections.

## Create a Sign-in Rule

To create a sign in rule for users:

1.  Select ConfigurationPrisma BrowserPolicySign-in Rules and click Add rule.
    
2.  Enter a Name for the rule.
    
3.  Set an Action, which can be Active or Disabled.
    
    You can change the Action at any time. You may want to keep the rule disabled until you're ready to launch the new rule base.
    
4.  Click Next: Scope and then define the match criteria for the rule.
    
    Select one or more values to define the scope of the sign-in rule. You can select one or more of the following options:
    
    -   Users/User groups—Select the [users and user groups](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-users.html) that you want to match this sign-in rule to access Prisma Browser.
    -   Device groups—Select the [device groups](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices.html#manage-prisma-access-browser-devices_task-hns_lt1_gcc) to match this sign-in rule for access to .. The device groups can contain posture attributes that are either positive or negative. For more information, refer to [Device Posture Attributes](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-devices/prisma-access-browser-device-posture-attributes.html).
    -   Networks—Select the public networks the device must be attached to in order to access Prisma Browser. Use one of the following formats to specify the network: 94.45.21.1 or 129.144.9.8/29
    -   **Location** – Select the geolocation from which to enable the Prisma Browser rule. If the OS Location services are not enabled on the device, the PAB will use the GeoIP. For more information, refer to [Location-based Policy](/content/techdocs/en_US/prisma-access-browser/administration/location-based-policy.html)
        
    
5.  Click Next: Action.
    
6.  Set the action for the sign-in rule:
    
    -   Allow—Allow access to Prisma Browser for users and devices that match the defined rule scope.
    -   Block—Block access to Prisma Browser for users and devices that match the defined rule scope.
    -   Prompt—Notify users that match the sign-in rule scope that their Prisma Browser is blocked by default, but allow them to bypass the block and continue to the browser.
        
        While the Prisma Browser for Mobile's Sign-in rules are configured the same way as the Sign-in rules for the Prisma Browser, be aware of the following exception:Starting with _iOS_ browser version 1.4259 and _Android_ browser version 1.4260, the **Prompt** action functions as **Block**. For all earlier versions, it functions as **Allow**.
        
    
7.  Optional) [Create a browser customization rule](/content/techdocs/en_US/prisma-access-browser/administration/manage-prisma-access-browser-policy-rules/manage-prisma-access-browser-customization-rules.html) for the device group.
    
    Provide text in the customization rule to help the user understand the posture errors (on the Security checks tab).
    
8.  Save the rule.