---
title: "Prisma Access Browser Extension Auto Login"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/deployment/deploy-the-prisma-access-browser-extension/prisma-access-browser-extension-auto-login"
depth: 3
breadcrumbs: "Home > Prisma Browser > Deploy the Prisma Browser Extension > Prisma Access Browser Extension Auto Login"
updated: "Feb 10, 2026"
---

# Prisma Access Browser Extension Auto Login
Configure Auto Login for PABX

| Where Can I Use This? | What Do I Need? |
| --- | --- |
| Strata Cloud Manager; Prisma Browser standalone | Prisma Access with Prisma Browser bundle license or Prisma Browser standalone license; Superuser or Prisma Browser [role](https://docs.paloaltonetworks.com/prisma-access-browser/activation-and-onboarding/prisma-access-browser-roles.html) |

The Prisma Browser Extension automatically logs users in without requiring manual sign-ins. This feature works by integrating with supported identity providers (IdP) and using the existing session cookies from those IdPs.

## Prisma Browser Extension Auto-Login

The Prisma Browser Extension provides an auto-login feature that automatically and seamlessly logs users into the system, eliminating the need for manual sign-ins. Prisma Browser Extension achieves this by integrating with supported Identity Providers (IdPs) and leveraging their existing session cookies. This method significantly reduces sign-in effort for users and enhances security by centralizing credential management at the IdP level through single sign-on (SSO).

## How the Prisma Access Browser Extension Works

PABX initiates a login attempt every few minutes or when it detects a change in the existing IdP session cookie. The process includes the following steps:

-   **IdP session Detection**: When a user signs in to a business application (such as a CRM) that integrates with their IdP, the browser receives a session cookie that confirms the active session.
    
-   **Active session Verification**: During each login attempt, Prisma Browser Extension checks for valid session cookies from supported IdPs.
    
-   **Domain Matching**: If Prisma Browser Extension detects an active session, it checks whether the user’s domain (for example, company.com in user@company.com) exists in the PABX loginDomains configuration.
    
-   **Silent Background Login**: If the domain matches, Prisma Browser Extension silently attempts to authenticate in the background by accessing a configured Prisma Browser application that integrates with the IdP. This typically occurs when you set up the Cloud Identity Engine (CIE) during on-boarding.
    
-   **Local Session Establishment**: After successful authentication, Prisma Browser Extension creates a local session and enforces policy rules associated with the logged-in user.

By using single sign-on (SSO), Prisma Browser Extension enables users to access multiple systems through a single login. This reduces sign-in effort and improves security by centralizing credential management at the IdP level.

## Auto-Login Prerequisites

To properly enable the Auto-login feature, you need to ensure the following configurations:

-   **IdP Integration:** Integrate Prisma Browser Extension with one of the currently supported Identity Providers:
    -   Okta
    -   Azure Active Directory
    -   Google Workspace
        
        If your organization uses an IdP not listed above, users must sign in manually. In such cases, you can enforce manual login requirements to prevent users from bypassing policy rule enforcement.
        
-   **Login Domains Configuration:** Accurately configure login domains in Prisma Browser Extension to precisely match your users' IdP domains.
-   **PAB (CIE) Application Setup:** Properly set up the Prisma Browser application (Cloud Identity Engine) within your chosen IdP.

### Login Domains

Prisma Browser Extension automatically retrieves and populates login domains from the integrated IdP. These domains (such as company.com from user@company.com) appear under **Login Domains** on the Prisma Browser Extension onboarding page. Confirm that these automatically populated domains accurately match your users' email domains. If discrepancies exist, update them directly within the onboarding tool.

### Deploying Prisma Browser Extension

To deploy Prisma Browser Extension, follow the detailed instructions provided in the onboarding section of the Prisma Browser management console. You can also refer to the full deployment documentation available directly within the console for more information.