---
title: "Prisma Browser Self-Protection for Windows"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/administration/prisma-browser-self-protection-fpr-windows"
depth: 2
breadcrumbs: "Home > Prisma Browser > Prisma Access Browser Administration > Prisma Browser Self-Protection for Windows"
updated: "Mar 12, 2026"
---

# Prisma Browser Self-Protection for Windows
Self protection for windows

The **Prisma Browser Self-Protection** feature provides advanced runtime protection for Prisma Browser processes on Windows devices. It integrates a **Windows kernel-mode driver** that prevents interference from malicious software or unauthorized system changes.

The self-protection capability delivers kernel-level defense for Windows systems, protecting Prisma Browser’s runtime integrity.

This feature is **available only on Windows 10 22H2 and later** and is **not supported on macOS**

For macOS devices, **System Integrity Protection (SIP)** and existing posture controls continue to serve as the primary mechanisms for protecting the browser environment.

Supported Platforms
| Category | Supported | Not Supported |
| --- | --- | --- |
| Operating System | Windows 10 22H2 and newer (physical or virtual machines) | Windows versions before Windows 10 22H2 |
| Installation Type | Admin level installation | User level installation |

## Use Cases and Risk Profiles

The Self-Protection feature focuses on protecting Prisma Browser in **high-risk environments**, particularly where administrator privileges or unmanaged systems increase the attack surface.

| Device Type | OS User Role | Risk Profile | Driver Requirement |
| --- | --- | --- | --- |
| Unmanageed devices (BYOD / Contractors | Admin | **High risk** (insider threats, malware exposure) | **Driver required** to enforce kernel-level integrity protection |
| **Managed Corporate Devices** | Non-Admin | **Low risk** (centrally managed and policy-secured) | Driver supported, but not critical |

## Installation Modes

Prisma Browser supports both **user-level** and **admin-level** installation modes.

The self-protection driver is only available in the **admin-level** installation.

| Installation Types | Permissions | Driver Component |
| --- | --- | --- |
| User Level | User permissions | Driver **cannot** be installed |
| Admin level | Administrator permissions | Driver protection can be installed and activated |

-   The driver is **not installed by default**.
-   The **administrator must explicitly enable** the self-protection policy before the driver is installed and activated.
-   After installation, Prisma Browser can run under a **non-admin user account**, and the protection driver will remain active under policy control.

## Policy Configuration and Control

A new policy control named **Browser self-protection** is available under browser security policies.

This setting enables administrators to remotely control the activation state of the protection driver.

**Policy characteristics:**

-   Applies only to **Windows** systems where Prisma Browser is **installed as admin**.
-   Disabled by default
-   Managed centrally through enterprise policy distribution.

## Enforcement for Inactive Protection

If Prisma Browser cannot start the protection driver (for example, when installed as a user or running on unsupported ARM hardware), the administrator can define an **enforcement response** using the _Enforcement for Inactive Protection_ setting.

| Enforcement Option | Administrator Action | End-User Impact |
| --- | --- | --- |
| Do not Enforce | Allow browser to run anyway | No message appears |
| Prompt and Proceed anyway | Display warning, and continue the browser session | User sees a warning dialog, but the browser runs normally |
| Block Browser Access | Prevent browser from starting | Browser shuts down and the user sees the warning dialog |

## End User Experience

When self-protection is properly installed and policy-enabled:

-   The protection driver runs silently with **no performance impact**.
-   The browser operates normally; no UI change or notification is shown.
-   The feature automatically activates at runtime under the active Prisma Browser policy.

## Multi-Profile Sessions

Prisma Browser’s **multi-profile policy** ensures consistent protection across all profiles.

If any profile activates the protection driver during a session, the driver remains active and safeguards all profiles for the remainder of that session.

## Device Reporting and Troubleshooting

Device and browser diagnostics display protection information to assist administrators in verifying the feature’s status.

Reported attributes include:

-   Browser installed as admin (Yes / No)
-   OS user is admin (Yes / No)
-   Device architecture
-   Browser self-protection status

| Status | Description |
| --- | --- |
| Protected | Prisma Browser installed as Admin Policy enabled |
| Not Protected | Policy enabled, but driver failed to start |
| Inactive | Policy not set or disabled |
| Unknown | Status undetermined (possible old Prisma Browser version) |

## Deployment Lifecycle

-   **Driver upgrade:** Managed seamlessly during standard Prisma Browser update flow.
-   **Uninstallation:** Removes driver and associated services automatically with Prisma Browser.
-   **Reinstallation guidance:** When reinstalling Prisma Browser to enable driver protection, users should **not delete browsing data**.

## **Compatibility and Limitations**

The following configurations are **unsupported** or have **limited protection**:

| Limitation | Description |
| --- | --- |
| User-Level Installation | Driver not installed; self-protection inactive |
| Windows ARM Architecture | Kernel driver not supported |
| Older Windows Version | Driver not compatible; feature unavailable. |