---
title: "JP Region"
url: "https://docs.paloaltonetworks.com/prisma-access-browser/getting-started/prisma-access-browser-prerequisites/domains-to-allow-jp"
depth: 3
breadcrumbs: "Home > Prisma Browser > Prisma Browser Prerequisites > JP Region"
updated: "Tue Feb 10 06:48:12 PST 2026"
---

# JP Region
The following domains are for clients in the JP region.

The following domains are for clients in the JP region only:

-   \*.talon-sec.com
-   pabrowser.com
-   get.pabrowser.com
-   jp.api.wildfire.paloaltonetworks.com
-   jp.wildfire.paloaltonetworks.com
-   cie-api-proxy.jp.apps.paloaltonetworks.com

Palo Alto Networks highly recommends that \*.talon-sec.com be used as a network requirement. If you need to exclude specific domains, please use the following list:

-   gateway.jp.talon-sec.com
-   classifier-auf.talon-sec.com
-   assets.jp.talon-sec.com
-   users-assets.jp.talon-sec.com
-   installer.talon-sec.com
-   updates.talon-sec.com
-   bfe078e7921507bb.talon-sec.com
-   prod.talon-sec.com
-   releases.talon-sec.com
-   \*.dss.paloaltonetworks.com